var canvas = document.getElementById("canvas")

var c = canvas.getContext("2d");
var img = new Image();

canvas.width = 500;
canvas.height = 350;

var xStart = 0;
var yStart = 0;

var letterPlace_X = 25;
var letterPlace_Y = 35;
var letterPlace_XSave = 25;
var letterPlace_YSave = 35;
var letterNumber = 1;
var letterNum = 1;

var letterColor = "black";

var backspaceX = 0;

var dateFinder = 1;
var dateFinder2 = 0;
const dateNumbers = []
let date = new Date();
date = String(date)
let date2 = date.slice(8, 11);

const xs = [25, 75, 125, 175, 225];
let x1 = 25;
let x2 = 75;
let x3 = 125;
let x4 = 175;
let x5 = 225;

const words = ["anxious", "backing", "welfare", "brother", "publish", "routine", "serious", "central", "strange", "welcome", "serving", "problem", "shortly", "storage", "organic", "private", "routine", "walking", "surplus", "version", "working", "poverty", "nuclear", "smoking", "optical", "society", "qualify", "section", "problem"]

var wordAnswer = String(words.slice(date2 - 1 , date2))

let lettersPutIn = []

let lettersInAnswer = []
var lettersInAnswerHelp = 1;
let lettersInAnswerHelp2 = "";

var lettersTyped = 0;

var mainEnterHelp = "";
var mainEnterHelp2 = 0;
var mainEnterHelp3 = 1;
var coloredRewriteHelp = "";
var coloredRewriteHelp2 = 0;
var coloredRewriteHelp3 = "";
let coloredRewriteHelp4 = "";

console.log("---->>> mt def");
let colorsInRow = []
let colorsInAll = [];

var tries = 0;

var colorEmojisHelp = 0;
let coloredEmojis = []
var colorEmojisHelp2 = "";

var stringTyped = "";
var stringTypedHelp = 0;

var streak = 0;
var gamesPlayed = 0;
var playedToday = date2;

var sendCode = 0;

var streakRead = 0;
var gamesPlayedRead = 0;
var playedTodayRead = 0;

var rowDeleting = 0;

let allWords = ["abalone", "abandon", "abashed", "abating", "abbasid", "abdomen", "abducts", "abelard", "abetted", "abettor", "abiding", "abidjan", "abigail", "abilene", "ability", "abitibi", "abjured", "abolish", "aborted", "abounds", "abraded", "abraham", "abraxas", "abreast", "abridge", "abruzzo", "absalom", "abscess", "abscond", "absence", "absense", "absolut", "absolve", "absorbs", "abstain", "abusers", "abusing", "abusive", "abutted", "abysmal", "abysses", "acacias", "academe", "academy", "acadian", "acceded", "accedes", "accents", "accepts", "acclaim", "accords", "accosts", "account", "accrete", "accross", "accrual", "accrued", "accrues", "accused", "accuser", "accuses", "acerbic", "acetate", "acetone", "acevedo", "acharya", "achieve", "acidify", "acidity", "acolyte", "aconite", "acquire", "acquits", "acreage", "acrobat", "acronym", "acrylic", "actinic", "actions", "actives", "actress", "actuals", "actuary", "actuate", "acuerdo", "acutely", "adamant", "adamson", "adaptec", "adapted", "adapter", "adaptor", "addenda", "addicts", "addison", "address", "adduced", "adeline", "adelman", "adelson", "adenine", "adenoid", "adeptly", "adhered", "adheres", "adipose", "adjoins", "adjourn", "adjudge", "adjunct", "adjusts", "admiral", "admired", "admirer", "admires", "adopted", "adoptee", "adopter", "adoring", "adorned", "adrenal", "adriana", "adriano", "advance", "adverbs", "adverse", "adverts", "advices", "advised", "advisee", "adviser", "advises", "advisor", "aeolian", "aerated", "aerials", "aerobic", "aerosol", "affable", "affaire", "affairs", "affects", "affirms", "affixed", "affixes", "affleck", "afflict", "affords", "affront", "afghani", "afghans", "african", "against", "agaisnt", "agarwal", "ageless", "agencia", "agendas", "agent's", "aggress", "agility", "agitate", "agonies", "agonist", "agonize", "aground", "aguilar", "aguirre", "agustin", "aileron", "ailment", "aimless", "ainsley", "ainslie", "airbags", "airbase", "airboat", "aircrew", "airdrop", "airfare", "airflow", "airfoil", "airhead", "airings", "airless", "airlift", "airline", "airlock", "airmail", "airmass", "airplay", "airport", "airship", "airshow", "airtime", "airwave", "airways", "akerman", "akihiro", "akiyama", "alabama", "aladdin", "alameda", "alanine", "alannah", "alarmed", "alaskan", "albania", "alberta", "alberto", "alberts", "albinos", "albumen", "albumin", "alcatel", "alcazar", "alchemy", "alcohol", "alcoves", "aldrich", "alegria", "aleksei", "aleksey", "alerted", "alertly", "alewife", "alfalfa", "alfonse", "alfonso", "alfredo", "algebra", "algeria", "algiers", "alianza", "aliases", "alights", "aligned", "aliment", "alimony", "alittle", "alkalis", "allaire", "allayed", "alleged", "alleges", "allegra", "allegro", "alleles", "allende", "allergy", "alleyne", "allgood", "alliant", "allianz", "allicin", "allison", "alloted", "allover", "allowed", "alloyed", "allsopp", "allstar", "alluded", "alludes", "allured", "allways", "allying", "allyson", "almaden", "almanac", "almeida", "almonds", "alpacas", "already", "alright", "altered", "althoff", "altmann", "altoona", "alumina", "alumnae", "alumnus", "alvarez", "alveoli", "amabile", "amadeus", "amalgam", "amanita", "amassed", "amasses", "amateur", "amatory", "amazing", "amazons", "ambient", "ambling", "ambrose", "amended", "amenity", "amerada", "america", "amerika", "amerind", "amharic", "amherst", "amiable", "amiably", "ammonia", "ammount", "amnesia", "amnesty", "amoebas", "amoebic", "amongst", "amorous", "amounts", "amperes", "amphora", "amplify", "amputee", "amulets", "amusing", "amyloid", "anaemia", "anaemic", "anagram", "anaheim", "analogs", "analogy", "analyse", "analyst", "analyze", "ananias", "anarchy", "anasazi", "anastas", "anatole", "anatoli", "anatoly", "anatomy", "anchors", "anchovy", "ancient", "andante", "andorra", "andover", "andrade", "andreas", "andrews", "andries", "android", "andrzej", "anemone", "angeles", "angelic", "angelis", "angelus", "angered", "anglers", "anglian", "angling", "angolan", "angrier", "angrily", "anguish", "angular", "aniline", "animals", "animate", "animism", "animist", "aniseed", "anklets", "annabel", "annette", "annexed", "annexes", "annoyed", "annuals", "annuity", "annular", "anodyne", "anoints", "anomaly", "anoraks", "another", "anspach", "answers", "antacid", "antares", "antenna", "anthems", "anthers", "anthill", "anthony", "anthrax", "antigay", "antigen", "antigua", "antioch", "antique", "antiwar", "antlers", "antoine", "antonia", "antonin", "antonio", "antonov", "antonym", "antwerp", "anumber", "anxiety", "anxious", "anybody", "anymore", "anytime", "anyting", "anytown", "anyways", "apaches", "apatite", "apelike", "aphasia", "aphasic", "aplenty", "apology", "apostle", "appalls", "apparat", "apparel", "appeals", "appears", "appease", "appends", "appetit", "applaud", "apple's", "appleby", "applets", "applied", "applies", "appling", "appoint", "apposed", "apprise", "approve", "apricot", "aproach", "apropos", "aptness", "aquatic", "aquavit", "aqueous", "aquifer", "aquinas", "arabian", "arabica", "arabist", "aramaic", "arapaho", "arbiter", "arbutus", "arcades", "arcadia", "arcanum", "archaic", "archers", "archery", "arching", "archive", "archway", "ardmore", "ardsley", "arduous", "argonne", "arguers", "arguing", "ariadne", "arianna", "aridity", "arising", "arizona", "arledge", "armadas", "armando", "armband", "armenia", "armless", "armload", "armoire", "armored", "armours", "armpits", "armrest", "arnault", "arnesen", "arnolds", "aronoff", "aronson", "arousal", "aroused", "arouses", "arpanet", "arrange", "arrayed", "arrears", "arrests", "arriaga", "arrival", "arrived", "arrives", "arrowed", "arsenal", "arsenic", "arsenio", "artemis", "article", "artisan", "artiste", "artists", "artless", "artwork", "arugula", "arundel", "ascends", "ascents", "ascetic", "ascribe", "aseptic", "asexual", "ashamed", "ashanti", "ashburn", "ashbury", "ashdown", "ashford", "ashtray", "ashwood", "asiatic", "asingle", "asinine", "askance", "asocial", "aspects", "asphalt", "aspired", "aspires", "aspirin", "asquith", "assails", "assault", "assayed", "assayer", "assents", "asserts", "asshole", "assigns", "assists", "assizes", "assuage", "assumed", "assumes", "assured", "assures", "assyria", "astaire", "astarte", "asterix", "astoria", "astound", "astride", "asunder", "asylums", "atalaya", "ataturk", "atavism", "atelier", "atheism", "atheist", "athlete", "athough", "athwart", "atlanta", "atlases", "atleast", "atomics", "atomize", "atoning", "atresia", "atrophy", "atsushi", "attaboy", "attache", "attacks", "attains", "attempt", "attends", "attests", "atticus", "attired", "attract", "attuned", "attwood", "atwater", "auberge", "auction", "audible", "audibly", "audited", "auditor", "audubon", "augment", "augured", "augusta", "auguste", "augusto", "aunties", "aurally", "aurelia", "aurelio", "aureole", "auroral", "auroras", "auspice", "aussies", "austere", "austral", "austria", "auteurs", "authors", "autocad", "autopsy", "autumns", "availed", "avarice", "avatars", "avenged", "avenger", "avenges", "avenida", "avenues", "average", "averred", "averted", "aviator", "avidity", "avignon", "avinash", "avionic", "avocado", "avoided", "avraham", "awaited", "awakens", "awaking", "awarded", "awesome", "awfully", "awkward", "awnings", "aylward", "azaleas", "azevedo", "azinger", "babbage", "babbitt", "babbled", "babbler", "babbles", "babcock", "baboons", "babying", "babyish", "babylon", "babysat", "babysit", "bacardi", "bacchus", "bachman", "bacilli", "backend", "backers", "backhoe", "backing", "backlit", "backlog", "backups", "baddest", "baddies", "badgers", "badging", "badness", "baffled", "baffles", "bagasse", "baggage", "baggers", "baggies", "bagging", "baghdad", "bagnall", "bagpipe", "bagwell", "bahadur", "bahamas", "bahrain", "baileys", "bailiff", "bailing", "baillie", "bailout", "baiters", "baiting", "baker's", "baklava", "balance", "balcony", "balding", "baldock", "baldwin", "baleful", "balfour", "balkans", "balking", "ballade", "ballads", "ballard", "ballast", "ballets", "balling", "ballmer", "balloon", "ballots", "baloney", "balsams", "baluchi", "bambino", "bamford", "bananas", "banbury", "bancorp", "bandage", "bandaid", "bandana", "bandied", "banding", "bandits", "bandsaw", "bandura", "baneful", "bangers", "banging", "bangkok", "bangles", "bankers", "banking", "banners", "banning", "bannock", "banquet", "banshee", "bantams", "baptise", "baptism", "baptist", "baptize", "barajas", "barbara", "barbary", "barbell", "barbels", "barbera", "barbero", "barbers", "barbier", "barbies", "barbour", "barboza", "barbuda", "barcelo", "barclay", "barcode", "barents", "barfing", "bargain", "barging", "barings", "barkeep", "barkers", "barking", "barkley", "barlett", "barmaid", "barnaby", "barnard", "barnett", "barneys", "baron's", "baronet", "baroque", "barrack", "barrage", "barrell", "barrels", "barrens", "barrera", "barrett", "barrier", "barring", "barrios", "barritt", "barroom", "barrows", "barstow", "bartell", "bartels", "barters", "barthes", "bartley", "bartolo", "bartram", "barwise", "basalts", "baseman", "basemen", "basenji", "bashers", "bashful", "bashing", "baskets", "basking", "basmati", "basques", "bassets", "bassett", "bassist", "bassoon", "bastard", "basters", "bastian", "basting", "bastion", "batched", "batches", "bateman", "bateson", "bathers", "bathing", "bathtub", "batista", "batiste", "batsman", "batsmen", "batters", "battery", "battier", "batting", "battled", "battler", "battles", "batwing", "baubles", "bauhaus", "baumann", "bauxite", "bavaria", "bawling", "bayliss", "bayonet", "bayonne", "bayside", "bayview", "bazaars", "bazooka", "beacham", "beached", "beaches", "beacons", "beacuse", "beading", "beadles", "beagles", "beakers", "beamers", "beaming", "beamish", "beanbag", "beanery", "beanies", "bearcat", "bearded", "bearers", "bearing", "bearish", "beasley", "beastie", "beastly", "beaters", "beatify", "beating", "beatles", "beatnik", "beatrix", "beattie", "beavers", "becasue", "because", "becerra", "bechtel", "beckett", "beckham", "beckley", "beckman", "beckons", "becomes", "becuase", "bedbugs", "bedding", "bedevil", "bedford", "bedouin", "bedpans", "bedpost", "bedrock", "bedroll", "bedroom", "bedside", "bedsore", "bedtime", "bedwell", "beecham", "beecher", "beeches", "beefier", "beefing", "beehive", "beeline", "beepers", "beeping", "beeswax", "beetles", "befalls", "beggars", "beggary", "begging", "begonia", "beguile", "beguine", "behaved", "behaves", "behinds", "beholds", "behoove", "behoves", "behrens", "beijing", "bejesus", "belabor", "belarus", "belated", "belched", "belcher", "belches", "beleive", "belfast", "belford", "belgian", "belgium", "beliefs", "believe", "belinda", "belknap", "bellamy", "bellboy", "belleek", "bellhop", "bellied", "bellies", "belling", "bellini", "bellman", "bellows", "belmont", "belongs", "beloved", "belting", "beltran", "beltway", "belugas", "belying", "bemoans", "bemused", "benched", "bencher", "benches", "benders", "bending", "beneath", "benefit", "benelux", "benfits", "benford", "bengali", "bengals", "benitez", "bennett", "bennies", "benning", "bentley", "bentsen", "benzene", "benzine", "benzoic", "beowulf", "bequest", "beranek", "berardi", "berated", "berates", "beretta", "bergamo", "bergman", "berjaya", "berkley", "berkman", "berline", "berlioz", "berlitz", "bermuda", "bernama", "bernard", "berners", "bernice", "berried", "berries", "berserk", "berthed", "bertone", "bertoni", "bertram", "bertsch", "berwick", "beseech", "besides", "besiege", "bespeak", "bespoke", "bestial", "besting", "bestows", "betamax", "bethany", "betrays", "betters", "betting", "bettors", "between", "betwixt", "beveled", "beverly", "bewitch", "bewteen", "bhangra", "bianchi", "biasing", "biassed", "bickers", "bicycle", "bidders", "biddies", "bidding", "bidwell", "bierman", "bifocal", "bigelow", "bigfoot", "biggers", "biggest", "biggies", "biggins", "biggish", "bighead", "bighorn", "bigness", "bigoted", "bigotry", "bigshot", "bigtime", "bigwigs", "bikinis", "biliary", "bilious", "bilking", "billard", "billers", "billets", "billies", "billing", "billion", "billows", "billups", "biltong", "bimodal", "binders", "bindery", "binding", "bingham", "binging", "binkley", "binning", "biochem", "biology", "biomass", "biotech", "biotite", "bipedal", "biplane", "bipolar", "bircher", "birches", "birders", "birdied", "birdies", "birding", "birdman", "birthed", "bischof", "biscuit", "bisects", "bishops", "bismark", "bismuth", "bissell", "bissett", "bistros", "bitched", "bitches", "bitmaps", "bitters", "bitting", "bittman", "bittner", "bitumen", "bivalve", "bivouac", "bizarre", "bizarro", "bizzare", "blabbed", "blabber", "blacked", "blacken", "blacker", "blackie", "blackly", "bladder", "blading", "blakely", "blalock", "blaming", "blanche", "blander", "blandly", "blanked", "blanker", "blanket", "blankly", "blanton", "blaring", "blarney", "blasted", "blaster", "blatant", "blather", "blatter", "blazers", "blazing", "bleaker", "bleakly", "bledsoe", "bleeder", "bleeped", "blemish", "blended", "blender", "blessed", "blesses", "blevins", "blewitt", "blights", "blighty", "blinded", "blinder", "blindly", "blinked", "blinker", "blister", "blitzed", "blitzer", "blitzes", "bloated", "blocked", "blocker", "blonder", "blondes", "blondie", "blooded", "bloomed", "bloomer", "blooper", "blosser", "blossom", "blotchy", "blotted", "blotter", "blouses", "blowers", "blowfly", "blowgun", "blowing", "blowout", "blowups", "blubber", "blucher", "bluefin", "blueish", "bluejay", "bluffed", "bluffer", "blunder", "blunted", "blunter", "bluntly", "blurred", "blurted", "blushed", "blushes", "bluster", "boarded", "boarder", "boasted", "boaster", "boaters", "boating", "boatman", "boatmen", "bobbies", "bobbing", "bobbins", "bobbitt", "bobbled", "bobbles", "bobcats", "bobsled", "bobtail", "bockius", "bodegas", "bodices", "boersma", "boffins", "bogeyed", "bogging", "boggled", "boggles", "bohemia", "boileau", "boilers", "boiling", "bolanos", "boldest", "bolding", "boleros", "boletus", "bolivar", "bolivia", "bollard", "bolling", "bologna", "bolster", "bolters", "bolting", "bolzano", "bombard", "bombast", "bombers", "bombing", "bonaire", "bonanza", "bonbons", "bondage", "bonding", "bonelli", "bonfire", "bonilla", "bonjour", "bonkers", "bonking", "bonneau", "bonnell", "bonnets", "bonnier", "bonsall", "bonuses", "boobies", "boogies", "bookend", "bookers", "bookies", "booking", "bookish", "booklet", "bookman", "boolean", "boombox", "boomers", "booming", "boomlet", "boonies", "boorish", "boosted", "booster", "bootees", "booties", "booting", "bootleg", "boozers", "boozing", "boppers", "bopping", "borders", "boredom", "borelli", "borgman", "borings", "borland", "borough", "borrego", "borrows", "borscht", "bosnian", "bossier", "bossing", "boswell", "botanic", "botched", "botches", "bothers", "botting", "bottled", "bottler", "bottles", "bottoms", "boucher", "boudoir", "boulder", "boulter", "boulton", "bounced", "bouncer", "bounces", "bounded", "bounden", "bounder", "bouquet", "bourbon", "bourdon", "bourque", "bourses", "boutros", "bouvier", "bovines", "bowater", "bowhead", "bowlers", "bowline", "bowling", "bowring", "boxcars", "boxwood", "boycott", "boyhood", "boykins", "boynton", "bozeman", "brabant", "bracing", "bracken", "bracket", "bradlee", "bradley", "bragged", "brahman", "brahmin", "braided", "braille", "brained", "brainer", "braised", "braking", "bramble", "bramley", "brammer", "branche", "branded", "brander", "brandis", "brandon", "brannen", "brannon", "branson", "brasher", "brashly", "brasses", "brattle", "bravado", "bravely", "bravery", "bravest", "braving", "bravura", "brawler", "brawley", "brawner", "braxton", "braying", "brayton", "brazier", "brazils", "brazing", "breaded", "breadth", "breaker", "breakup", "breasts", "breathe", "breaths", "breathy", "brecker", "breeden", "breeder", "breezed", "breezes", "bremner", "brendan", "brendel", "brennan", "brenner", "brenton", "brescia", "breslin", "bresnan", "bretons", "bretton", "brevity", "brewers", "brewery", "brewing", "brianna", "bribery", "bribing", "bricked", "bricker", "bridged", "bridger", "bridges", "bridget", "bridled", "bridles", "briefed", "briefer", "briefly", "brigade", "brigand", "brigham", "brights", "brimful", "brimmed", "brimmer", "brindle", "bringer", "brining", "brinker", "brinson", "brioche", "briscoe", "brisker", "brisket", "briskly", "bristle", "bristly", "bristol", "bristow", "britain", "britian", "british", "britons", "brittan", "britten", "brittle", "britton", "broaden", "broader", "broadly", "broadus", "brocade", "brodeur", "brodsky", "brogues", "broiled", "broiler", "brokers", "broking", "bromide", "bromine", "bromley", "broncos", "bronson", "bronwyn", "bronzed", "bronzes", "brooded", "brooked", "brooker", "brookes", "brosnan", "brothel", "brother", "brought", "broward", "browder", "browned", "browner", "brownie", "browsed", "browser", "browses", "brubeck", "bruce's", "bruised", "bruiser", "bruises", "bruited", "brummel", "brummer", "brunell", "brunner", "brunson", "brushed", "brushes", "brusque", "brussel", "brutish", "bubbled", "bubbler", "bubbles", "bubonic", "buckets", "buckeye", "bucking", "buckled", "buckler", "buckles", "buckley", "buckman", "buckner", "bucolic", "buddhas", "buddies", "budding", "budgets", "budging", "buerger", "buffalo", "buffers", "buffets", "buffett", "buffing", "buffoon", "bugaboo", "bugbear", "buggers", "buggies", "bugging", "bugling", "builder", "buildup", "bulbous", "bulding", "bulging", "bulimia", "bulimic", "bulkier", "bulking", "bullard", "bulldog", "bullets", "bullied", "bullies", "bulling", "bullion", "bullish", "bullitt", "bullock", "bullpen", "bulrush", "bulwark", "bumbled", "bumbler", "bumbles", "bumming", "bumpers", "bumping", "bumpkin", "bunched", "bunches", "bundled", "bundles", "bungled", "bungler", "bungles", "bunions", "bunkers", "bunking", "bunnell", "bunnies", "bunning", "bunraku", "bunting", "buoyant", "burbank", "burdens", "burdett", "burdick", "burdock", "bureaus", "bureaux", "burgeon", "burgers", "burgess", "burgher", "burglar", "burgled", "burials", "burkett", "burkina", "burling", "burmese", "burnaby", "burnell", "burners", "burnett", "burnham", "burning", "burnish", "burnout", "burping", "burrell", "burried", "burrill", "burrito", "burritt", "burrows", "burundi", "burying", "busboys", "bushels", "bushido", "bushing", "bushman", "bushmen", "busiest", "buskers", "busking", "busload", "bussell", "bussing", "bustard", "busters", "bustier", "busting", "bustled", "bustles", "busying", "butanol", "butcher", "butlers", "butters", "buttery", "butting", "buttock", "buttons", "butyric", "buyable", "buyback", "buyer's", "buyouts", "buzzard", "buzzers", "buzzing", "buzzsaw", "bygones", "bylined", "bylines", "byronic", "bywater", "cabanas", "cabaret", "cabbage", "cabbies", "cabello", "cabinet", "cabling", "caboose", "caching", "cacique", "cackles", "cadaver", "cadbury", "caddies", "cadence", "cadenza", "cadmium", "cadwell", "caesars", "caesium", "caetano", "cahoots", "caisson", "caitlin", "cajoled", "cajoles", "calabar", "calcite", "calcium", "caldera", "caldron", "calgary", "calhoun", "caliber", "calibre", "caliche", "caliper", "caliphs", "callers", "calling", "callous", "callout", "calmest", "calming", "caloric", "calorie", "calpers", "caltech", "calumet", "calumny", "calvary", "calvert", "calving", "calvino", "calypso", "calzone", "camacho", "camargo", "cambium", "cambria", "camel's", "camelot", "cameras", "cameron", "camilla", "camille", "camorra", "campana", "campers", "camphor", "camping", "campion", "campout", "canales", "canapes", "canards", "canasta", "canavan", "cancels", "cancers", "candace", "candela", "candice", "candida", "candide", "candids", "candied", "candies", "candler", "candles", "canines", "cankers", "canners", "cannery", "cannily", "canning", "cannnot", "cannons", "canonic", "canopus", "cantata", "canteen", "cantina", "canting", "cantons", "cantors", "canucks", "canvass", "canyons", "capable", "capably", "capella", "capelle", "capital", "capitan", "capitol", "cappers", "capping", "caprice", "caprock", "capsize", "capstan", "capsule", "captain", "caption", "captiva", "captive", "captors", "capture", "capulet", "carabao", "caracas", "caramel", "caravan", "caravel", "caraway", "carbide", "carbine", "carbone", "carboni", "carbons", "carboys", "carcass", "cardiac", "cardiff", "carding", "cardona", "cardoso", "cardoza", "cardozo", "careens", "careers", "careful", "cargill", "cargoes", "caribou", "carillo", "carioca", "carissa", "carleen", "carless", "carlile", "carline", "carling", "carload", "carlsen", "carlson", "carlton", "carlyle", "carmine", "carmona", "carnage", "carol's", "carolan", "carolus", "carolyn", "carotid", "carouse", "carpark", "carpets", "carping", "carpool", "carport", "carrack", "carrell", "carrels", "carrera", "carrick", "carried", "carrier", "carries", "carrion", "carroll", "carrots", "carsten", "cartage", "cartels", "carters", "cartier", "carting", "cartons", "cartoon", "carvers", "carving", "carwash", "casares", "cascade", "casella", "caserta", "cashbox", "cashews", "cashier", "cashing", "casimir", "casings", "casinos", "casitas", "caskets", "caspian", "cassady", "cassata", "cassatt", "cassava", "cassell", "cassels", "cassidy", "cassino", "cassius", "cassock", "cassone", "castano", "castell", "castelo", "casters", "castile", "casting", "castles", "castoff", "castrol", "casuals", "caswell", "catalan", "catalog", "catalpa", "catania", "catawba", "catbird", "catched", "catcher", "catches", "catchup", "catered", "caterer", "catfish", "cathode", "cathryn", "cations", "catkins", "catlett", "catlike", "catmint", "cattery", "catting", "catwalk", "caulked", "caulker", "causing", "caustic", "cautery", "caution", "cavallo", "cavalry", "caveats", "caveman", "cavemen", "caverns", "cayenne", "caymans", "ceasing", "cecelia", "cecilia", "ceiling", "celadon", "celebes", "celeron", "celesta", "celeste", "cellars", "cellist", "celsius", "celtics", "cements", "cenacle", "censors", "censure", "centaur", "centavo", "centers", "centime", "central", "centred", "centres", "centrex", "centric", "centrum", "century", "cepheid", "ceramic", "cereals", "certain", "certify", "cesario", "cession", "cesspit", "ceviche", "cezanne", "chablis", "chadian", "chaebol", "chaffed", "chaffee", "chaffin", "chafing", "chagall", "chagrin", "chained", "chaired", "chakras", "chalabi", "chalets", "chalice", "chalked", "chalker", "challis", "chamber", "chambre", "chamois", "chanced", "chancel", "chances", "chancey", "chandra", "changed", "changer", "changes", "changin", "channel", "chanson", "chantal", "chanted", "chanter", "chantry", "chaotic", "chapeau", "chapels", "chaplin", "chapman", "chapped", "chappel", "chappie", "chapple", "chapter", "charade", "charest", "charged", "charger", "charges", "charing", "chariot", "charity", "charles", "charley", "charlie", "charman", "charmed", "charmer", "charnel", "charred", "charron", "charted", "charter", "chasers", "chasing", "chassis", "chasten", "chateau", "chatham", "chatted", "chattel", "chatter", "chaucer", "chayote", "cheadle", "cheapen", "cheaper", "cheaply", "cheated", "cheater", "chechen", "checked", "checker", "checkup", "cheddar", "cheeked", "cheered", "cheerio", "cheesed", "cheeses", "cheetah", "chekhov", "chelsea", "chemins", "chemise", "chemist", "chengdu", "chenier", "cheques", "cherish", "chernin", "cherrie", "cherubs", "chervil", "chesney", "chesser", "chested", "chester", "cheviot", "chevron", "chewers", "chewing", "cheyney", "chianti", "chiapas", "chicago", "chicane", "chicano", "chicken", "chicory", "chiding", "chiefly", "chiffon", "chigger", "chignon", "child's", "chilean", "chilies", "chilled", "chiller", "chilton", "chiluba", "chimera", "chiming", "chimney", "chinese", "chinned", "chinois", "chinook", "chintzy", "chipped", "chipper", "chipset", "chirped", "chisels", "chivers", "chiyoda", "choctaw", "choicer", "choices", "chokers", "choking", "cholera", "choline", "chomped", "chomsky", "chooser", "chooses", "chopped", "chopper", "chorale", "chordal", "chorion", "chorizo", "choroid", "chortle", "chosing", "chowder", "chrissy", "christa", "christi", "christo", "christs", "christy", "chromed", "chronic", "chubais", "chuck's", "chucked", "chuckie", "chuckle", "chuffed", "chugged", "chukchi", "chunked", "chunnel", "churchy", "churned", "chutney", "cicadas", "ciccone", "cichlid", "cienega", "ciliary", "cilicia", "cinched", "cinders", "cinemas", "cinemax", "ciphers", "circled", "circles", "circlet", "circuit", "cirillo", "cistern", "citadel", "citizen", "citrate", "citrine", "citroen", "citrusy", "civilly", "civitas", "claimed", "claimer", "clairol", "clamber", "clamour", "clamped", "clanked", "clapham", "clapped", "clapper", "clapton", "clarets", "clarice", "clarify", "clarins", "clarion", "clarity", "clashed", "clashes", "clasped", "classed", "classen", "classes", "classic", "clatter", "claudia", "claudio", "clausen", "clauses", "clavier", "clawing", "clawson", "claxton", "clayson", "clayton", "cleaned", "cleaner", "cleanly", "cleanse", "cleanup", "cleared", "clearer", "clearly", "cleated", "cleaved", "cleaver", "cleaves", "cleland", "clemens", "clement", "clerics", "clerked", "cliched", "cliches", "clicked", "clicker", "clients", "cliff's", "clifton", "climate", "climbed", "climber", "clinger", "clinics", "clinker", "clinton", "clipart", "clipped", "clipper", "cliques", "cliquey", "cloacal", "cloaked", "clobber", "cloches", "clocked", "clogged", "cloning", "clooney", "closely", "closers", "closest", "closets", "closeup", "closing", "closure", "clothed", "clothes", "clotted", "cloture", "clouded", "clovers", "cloying", "clubbed", "clubber", "clumped", "clunker", "cluster", "clutter", "clyburn", "coached", "coaches", "coakley", "coarser", "coastal", "coasted", "coaster", "coating", "coaxial", "coaxing", "cobbled", "cobbler", "cobbles", "cobwebs", "cocaine", "cochlea", "cochran", "cockade", "cocking", "cockles", "cockney", "cockpit", "coconut", "cocoons", "codding", "coddled", "codeine", "codelco", "codfish", "codices", "codicil", "codings", "codling", "coequal", "coerced", "coerces", "coexist", "coffees", "coffers", "coffins", "coffman", "cofield", "cogency", "coggins", "cognacs", "cognate", "cohabit", "coheres", "cohorts", "coiffed", "coiling", "coinage", "coining", "cojones", "colbert", "colburn", "coldest", "coleman", "colette", "colgate", "colicky", "colitis", "collage", "collard", "collars", "collate", "collect", "colleen", "college", "collett", "collide", "collier", "collies", "colline", "colling", "collins", "colloid", "collude", "collyer", "colobus", "cologne", "colombe", "colombo", "colonel", "colonia", "colonic", "colonus", "colored", "colossi", "colours", "columba", "columbo", "columns", "colwell", "combats", "combine", "combing", "combust", "comcast", "comedic", "comfort", "comfrey", "comical", "cominco", "comings", "command", "commend", "comment", "commies", "comming", "commish", "commits", "commode", "commons", "commune", "commute", "compact", "company", "compare", "compass", "compels", "compete", "compile", "complex", "comport", "compose", "compost", "compote", "compter", "compton", "compusa", "compute", "comrade", "conakry", "concave", "conceal", "concede", "conceit", "concept", "concern", "concert", "concise", "concoct", "concord", "concurs", "condemn", "condoms", "condone", "condors", "conduce", "conduct", "conduit", "confers", "confess", "confide", "confine", "confirm", "conform", "confort", "confuse", "congeal", "congers", "congest", "conical", "conifer", "conjoin", "conjure", "conklin", "connect", "connell", "conners", "connery", "conning", "connive", "connors", "connote", "conover", "conquer", "conrail", "consent", "consign", "consist", "console", "consort", "consuls", "consult", "consume", "contact", "contain", "contant", "contend", "content", "contest", "context", "contort", "contour", "contras", "control", "convene", "convent", "convert", "convery", "conveys", "convict", "convoke", "convoys", "conwell", "conyers", "coochie", "cookers", "cookery", "cookies", "cooking", "cookout", "cooksey", "coolant", "coolers", "coolest", "coolies", "cooling", "coombes", "coopers", "coopted", "copiers", "copilot", "copious", "copland", "coppers", "coppery", "copping", "coppola", "copters", "copycat", "copying", "copyist", "coracle", "coralie", "corazon", "corbeil", "corbett", "cordage", "cordell", "cordial", "cordier", "cording", "cordite", "cordoba", "cordons", "cordova", "corella", "corinna", "corinne", "corinth", "corkage", "corking", "cormier", "corncob", "corneal", "corneas", "cornell", "corners", "cornets", "cornett", "cornice", "corning", "cornish", "corolla", "coronal", "coronas", "coroner", "coronet", "corpora", "corpses", "corrals", "correct", "correll", "corrida", "corrode", "corrupt", "corsage", "corsair", "corsets", "corsica", "cortege", "cortese", "cortina", "cosenza", "cossack", "costain", "costars", "costing", "costume", "coterie", "cotonou", "cottage", "cottons", "cottony", "couched", "couches", "cougars", "coughed", "could't", "couldnt", "coulter", "council", "counsel", "counted", "counter", "country", "coupled", "coupler", "couples", "couplet", "coupons", "courage", "courant", "courier", "coursed", "courser", "courses", "courted", "courter", "courtly", "cousins", "couture", "covered", "coverts", "coverup", "coveted", "cowards", "cowbell", "cowbird", "cowboys", "cowered", "cowgirl", "cowherd", "cowhide", "cowlick", "cowling", "cowpoke", "cowshed", "cowtown", "coxcomb", "coyness", "coyotes", "cozying", "crabbed", "cracked", "cracker", "crackle", "crackly", "cradled", "cradles", "crafted", "crafter", "crammed", "cramped", "crampon", "cranial", "craning", "cranium", "cranked", "crapped", "crapper", "crappie", "crashed", "crasher", "crashes", "crassly", "craters", "crating", "cravats", "cravens", "craving", "crawled", "crawler", "crawley", "crayons", "crazier", "crazies", "crazily", "creaked", "creamed", "creamer", "creased", "creases", "created", "creates", "creator", "credito", "credits", "creek's", "creeper", "cremate", "cremona", "creoles", "cresson", "crested", "cretins", "crevice", "crewcut", "crewing", "crewman", "crewmen", "cribbed", "cricket", "crimean", "crimped", "crimson", "cringed", "cringes", "crinkle", "crinkly", "crippen", "cripple", "crisped", "crispen", "crisper", "crispin", "crisply", "cristal", "critics", "critter", "croaked", "croaker", "croatia", "crochet", "crocked", "crocker", "croesus", "crofton", "cronies", "crooked", "crooned", "crooner", "cropped", "cropper", "croquet", "crosier", "crossed", "crosser", "crosses", "crossly", "crowbar", "crowded", "crowder", "crowell", "crowing", "crowley", "crowned", "croydon", "crozier", "crucial", "crucify", "crudely", "crudest", "crudity", "cruelly", "cruelty", "cruised", "cruiser", "cruises", "crumble", "crumbly", "crumley", "crumple", "crunchy", "crusade", "crushed", "crusher", "crushes", "crustal", "crusted", "crybaby", "cryonic", "cryptic", "crystal", "cubbies", "cubical", "cubicle", "cuckold", "cuckoos", "cuddled", "cuddles", "cudgels", "cuellar", "cuffing", "cuidado", "cuisine", "culling", "culprit", "cultish", "cultist", "culture", "culvert", "cumbria", "cumming", "cummins", "cumulus", "cunning", "cupcake", "cupolas", "cupping", "curable", "curacao", "curated", "curates", "curator", "curbing", "curdled", "curfews", "curious", "curlers", "curling", "curragh", "currant", "current", "curried", "currier", "curries", "cursing", "cursive", "cursors", "cursory", "curtail", "curtain", "curtesy", "curtiss", "curving", "cushing", "cushion", "cushman", "cussing", "custard", "custody", "customs", "cutaway", "cutback", "cuticle", "cutlass", "cutlery", "cutlets", "cutoffs", "cutouts", "cutover", "cutters", "cutting", "cyanide", "cyborgs", "cyclers", "cycling", "cyclist", "cyclone", "cyclops", "cydonia", "cygnets", "cymbals", "cynical", "cynthia", "cyphers", "cypress", "cyprian", "cypriot", "czarina", "czarist", "czeslaw", "dabbing", "dabbled", "dabbler", "dabbles", "dadaism", "dadaist", "daddies", "daemons", "daggers", "daggett", "dahlias", "dahomey", "dailies", "daimler", "dairies", "daisies", "dakotan", "dakotas", "dallied", "daltons", "damaged", "damages", "damaris", "damming", "damning", "dampens", "dampers", "dampier", "damping", "damsels", "danbury", "dancers", "dancing", "dandies", "dangers", "dangled", "dangler", "dangles", "daniela", "daniele", "daniels", "danmark", "danvers", "daphnis", "dappled", "daresay", "darkens", "darkest", "darkies", "darlene", "darling", "darnell", "darning", "darrell", "darters", "darting", "darwish", "daschle", "dashing", "dasilva", "datable", "dataset", "daubert", "daunted", "dauphin", "davidow", "davison", "dawdled", "dawkins", "dawning", "daycare", "daylong", "daystar", "daytime", "daytona", "dazzled", "dazzler", "dazzles", "deacons", "deadend", "deadens", "deadeye", "deadman", "deadpan", "deakins", "dealers", "dealing", "dearest", "dearman", "deathly", "debacle", "debased", "debated", "debater", "debates", "debauch", "debited", "deborah", "debrief", "debtors", "debunks", "debussy", "debuted", "decadal", "decades", "decamps", "decatur", "decayed", "decease", "deceits", "deceive", "decency", "decibel", "decided", "decider", "decides", "decimal", "deckers", "decking", "declaim", "declare", "decline", "decoded", "decoder", "decodes", "decorum", "decreed", "decrees", "decried", "decries", "decrypt", "decsion", "deduced", "deduces", "deducts", "deejays", "deeming", "deepens", "deepest", "deering", "defaced", "defacto", "defamed", "default", "defazio", "defeats", "defects", "defence", "defends", "defense", "defiant", "deficit", "defiled", "defiles", "defined", "definer", "defines", "deflate", "deflect", "deforms", "defraud", "defrost", "defunct", "defused", "defuses", "defying", "deglaze", "degrade", "degrees", "degress", "deicide", "deicing", "deified", "deigned", "deirdre", "deities", "delaney", "delayed", "delbert", "deleted", "deletes", "delgado", "delight", "delilah", "delimit", "deliver", "delmont", "delores", "delphic", "deltoid", "deluded", "deludes", "deluged", "deluges", "delving", "demands", "demarco", "demeans", "demerit", "demerol", "demeter", "demigod", "demille", "demised", "demonic", "demoted", "demotes", "demotic", "dempsey", "denials", "deniers", "denison", "denizen", "denmark", "dennehy", "dennett", "denning", "denoted", "denotes", "densely", "densest", "density", "denting", "dentist", "denture", "denuded", "denying", "departs", "depeche", "depends", "depicts", "deplane", "deplete", "deplore", "deploys", "deports", "deposed", "deposit", "depress", "deprive", "deputed", "derails", "derbies", "derided", "derides", "derived", "derives", "dernier", "derrick", "derring", "dervish", "descant", "descend", "descent", "deseret", "deserts", "deserve", "desexed", "designs", "desired", "desiree", "desires", "deskjet", "desktop", "desmond", "despair", "despise", "despite", "despoil", "despond", "despots", "dessert", "destiny", "destroy", "details", "detains", "detects", "detente", "detests", "detours", "detract", "detroit", "detuned", "deutsch", "devalue", "devaney", "develop", "deviant", "deviate", "devices", "devil's", "deville", "devious", "devised", "devises", "devolve", "devoted", "devotee", "devotes", "devours", "devries", "dewdrop", "dextran", "dhahran", "diabolo", "diagram", "dialect", "dialers", "dialing", "dialled", "dialogs", "diamant", "diamine", "diamond", "diapers", "diaries", "diarist", "diatoms", "dickens", "dickies", "dickson", "dictate", "diction", "dictums", "diddled", "diddley", "dieback", "diebold", "diehard", "diesels", "dietary", "dieters", "diether", "diethyl", "dieting", "dietmar", "differs", "diffuse", "digests", "diggers", "digging", "digital", "dignify", "dignity", "digoxin", "digress", "diktats", "dilated", "dilator", "dilemma", "dillard", "dilling", "diluted", "dilutes", "dimitri", "dimitry", "dimmers", "dimmest", "dimming", "dimness", "dimpled", "dimples", "dimwits", "dinette", "dingbat", "dingell", "dinging", "dingman", "dingoes", "dinkins", "dinners", "dinning", "diocese", "diorama", "dioxide", "dioxins", "diploma", "dippers", "dipping", "diptych", "directs", "directv", "dirhams", "dirksen", "dirtied", "dirtier", "dirties", "disable", "disarms", "disavow", "disband", "discard", "discern", "discman", "discord", "discuss", "disdain", "disease", "disgust", "dishing", "dishpan", "dislike", "dismays", "dismiss", "disobey", "disowns", "dispell", "dispels", "display", "dispose", "dispute", "disrobe", "disrupt", "dissect", "dissent", "dissing", "distaff", "distant", "distend", "distill", "distort", "disturb", "disused", "ditched", "ditches", "dithers", "ditties", "diurnal", "diverge", "diverse", "diverts", "divests", "divided", "divider", "divides", "divined", "diviner", "divines", "divison", "divisor", "divorce", "divulge", "divvied", "dizzily", "dobbins", "docents", "dockers", "dockery", "dockets", "docking", "doctors", "dodgers", "dodging", "doesn't", "doffing", "dogfish", "dogfood", "doggett", "doggies", "dogging", "doggone", "doglike", "dogmeat", "dogsled", "dogwood", "doherty", "doilies", "doleful", "dollars", "dollies", "dollops", "dolores", "dolphin", "domaine", "domains", "domingo", "dominic", "dominos", "dominus", "donahoe", "donahue", "donated", "donates", "donavan", "donegan", "donkeys", "donnell", "donning", "donohoe", "donohue", "donovan", "doodads", "doodled", "doodles", "dooling", "dooming", "doorman", "doormat", "doormen", "doorway", "doozies", "doppler", "dorfman", "dorking", "dormant", "dormers", "dornier", "dorothy", "dorsett", "dosages", "dossett", "dossier", "dotting", "doubled", "doubler", "doubles", "doublet", "doubted", "doubter", "douches", "dougall", "doughty", "douglas", "doulton", "dousing", "dowager", "dowling", "downers", "downing", "dowries", "dowsing", "doyenne", "drabble", "drachma", "dracula", "draeger", "drafted", "draftee", "drafter", "dragged", "dragnet", "dragons", "dragoon", "drained", "drainer", "drapeau", "drapers", "drapery", "draping", "drastic", "draught", "drawers", "drawing", "drawled", "drayton", "dreaded", "dreamed", "dreamer", "dredged", "dredger", "dredges", "drennan", "dresden", "dresner", "dressed", "dresser", "dresses", "drexler", "dreyfus", "dribble", "drifted", "drifter", "drilled", "driller", "drinker", "dripped", "drivers", "driving", "drizzle", "drizzly", "droning", "drooled", "drooped", "droplet", "dropoff", "dropout", "dropped", "dropper", "drought", "drovers", "drowned", "drubbed", "drucker", "drugged", "druidic", "drummed", "drummer", "drunken", "drunker", "drydock", "dryland", "dryness", "drywall", "dualism", "dualist", "duality", "dubbing", "dubious", "duchess", "duchies", "duckett", "duckies", "ducking", "ductile", "ducting", "dudgeon", "dueling", "duelist", "duffers", "dugongs", "dugouts", "dukakis", "dukedom", "dullard", "dullest", "dulling", "dumbest", "dumbing", "dummies", "dumpers", "dumping", "dunaway", "dunedin", "dungeon", "dunhill", "dunking", "dunkirk", "dunning", "dunstan", "dunster", "dunston", "duopoly", "durable", "durably", "durango", "durante", "durning", "durrant", "dustbin", "dusters", "dusting", "dustman", "dustpan", "dutiful", "dwarfed", "dwarves", "dwelled", "dweller", "dwindle", "dworkin", "dynamic", "dynamos", "dynasty", "eagerly", "earache", "eardrum", "earhart", "earings", "earldom", "earlene", "earlier", "earlobe", "earmark", "earners", "earnest", "earning", "earplug", "earring", "earshot", "earthen", "earthly", "earwigs", "earworm", "easiest", "eastern", "eastham", "eastman", "eatable", "ebonics", "ebonite", "echelon", "echidna", "echoing", "eclipse", "ecology", "economy", "ecstacy", "ecstasy", "ectopic", "ecuador", "edelman", "edibles", "edifice", "edified", "edinger", "editing", "edition", "editors", "edmonds", "edmunds", "eduardo", "educate", "edwards", "effaced", "effects", "effendi", "efforts", "egerton", "egghead", "eggroll", "egoists", "egotism", "egotist", "ehrlich", "eight's", "eighths", "einhorn", "ejected", "ejector", "elapsed", "elapses", "elastic", "elastin", "elation", "elbowed", "elderly", "eleanor", "elected", "electic", "elector", "electra", "electro", "elegant", "elegiac", "elegies", "elektra", "element", "elevate", "elevens", "elicits", "eliezer", "eliot's", "elision", "elitism", "elitist", "elixirs", "elkhorn", "elledge", "elliman", "elliott", "ellipse", "ellison", "ellwood", "elmwood", "eloping", "elspeth", "eluding", "elusive", "elysees", "elysian", "elysium", "emailed", "emanate", "emanuel", "embargo", "embarks", "embassy", "emblems", "embolus", "embrace", "embroil", "embryos", "emerald", "emerged", "emerges", "emerick", "emerson", "emigres", "eminent", "emirate", "emitted", "emitter", "emoting", "emotion", "emotive", "empathy", "emperor", "empires", "empiric", "employe", "employs", "emporia", "empower", "empresa", "empress", "emptied", "emptier", "empties", "emption", "emptive", "emulate", "enabled", "enabler", "enables", "enacted", "enactor", "enamels", "encarta", "encased", "encases", "enchant", "encinas", "enclave", "enclose", "encoded", "encoder", "encodes", "encores", "encrust", "encrypt", "endears", "endemic", "enderle", "endgame", "endings", "endless", "endnote", "endorse", "endowed", "endured", "endures", "enemies", "energia", "enfield", "enfolds", "enforce", "engaged", "engages", "engdahl", "engined", "engines", "england", "englert", "english", "engrave", "engulfs", "enhance", "enigmas", "enjoins", "enjoyed", "enjoyer", "enlarge", "enlists", "enliven", "ennoble", "enought", "enquire", "enquiry", "enraged", "enrages", "enright", "enrique", "enrolls", "enroute", "ensigns", "enslave", "ensnare", "ensuing", "ensuite", "ensured", "ensures", "entails", "entente", "entered", "entergy", "enteric", "enthuse", "enticed", "entices", "entires", "entitle", "entrada", "entrain", "entrant", "entreat", "entrees", "entries", "entropy", "entrust", "entwine", "envelop", "envious", "environ", "envying", "enzymes", "ephedra", "ephesus", "ephraim", "epicure", "epigram", "episode", "epistle", "epitaph", "epithet", "epitome", "epitope", "epochal", "epoxies", "epsilon", "epstein", "equable", "equaled", "equally", "equated", "equates", "equator", "equifax", "equines", "equinox", "equiped", "erasers", "erasing", "erasmus", "erastus", "erasure", "erected", "erector", "ericson", "eriksen", "erikson", "eritrea", "ernesto", "eroding", "erosion", "erosive", "erotica", "errands", "erratic", "erskine", "erudite", "erupted", "escaped", "escapee", "escapes", "eschews", "escorts", "escuela", "eskimos", "espanol", "espouse", "esquire", "essayed", "essence", "essense", "estates", "esteban", "esteems", "estefan", "estella", "estelle", "estonia", "estrada", "estrich", "estrous", "estuary", "etching", "eternal", "ethanol", "ethical", "ethnics", "etienne", "etruria", "eubanks", "eugenia", "eugenic", "eugenie", "eugenio", "eunuchs", "euphony", "eurasia", "eustace", "evacuee", "evaders", "evading", "evangel", "evasion", "evasive", "evelina", "eveline", "evening", "event's", "everage", "everard", "everday", "everest", "everett", "everson", "everton", "evicted", "evident", "evinced", "evinces", "evoking", "evolved", "evolves", "exabyte", "exacted", "exactly", "exalted", "examine", "examing", "example", "exceeds", "excepts", "excerpt", "excimer", "excised", "excises", "excited", "exciter", "excites", "exclaim", "exclude", "excreta", "excrete", "excused", "excuses", "execute", "exempts", "exerted", "exhaled", "exhales", "exhange", "exhaust", "exhibit", "exhorts", "exhumed", "exigent", "exiling", "existed", "exiting", "exotica", "exotics", "expands", "expanse", "expects", "expends", "expense", "experts", "expiate", "expired", "expires", "explain", "explode", "exploit", "explore", "exports", "exposed", "exposes", "expound", "express", "expunge", "extends", "extents", "extinct", "extract", "extreme", "extrude", "exuding", "exulted", "exurban", "eyeball", "eyebrow", "eyelash", "eyeless", "eyelets", "eyelids", "eyesore", "eyewash", "eyewear", "ezekiel", "fabiano", "fabrice", "fabrics", "facades", "faceted", "facials", "facings", "faction", "factoid", "factors", "factory", "factual", "faculty", "faddish", "fadeout", "faggots", "faience", "failing", "failure", "fainted", "fainter", "faintly", "fairest", "fairfax", "fairies", "fairing", "fairley", "fairway", "fajardo", "fajitas", "falafel", "falcone", "falconi", "falcons", "falkner", "fallacy", "fallers", "falling", "falloff", "fallout", "fallows", "falsely", "falsify", "falsity", "falters", "falwell", "familar", "familiy", "famines", "fanatic", "fancied", "fancier", "fancies", "fanfare", "fangled", "fanning", "fantail", "fantasy", "fanzine", "faraday", "faraway", "farmboy", "farmers", "farming", "farnham", "farrago", "farrand", "farrant", "farrell", "farrier", "farther", "farting", "farwell", "fascias", "fascism", "fascist", "fashion", "fastens", "fastest", "fasting", "fatally", "fatback", "fateful", "fathead", "fathers", "fathoms", "fatigue", "fatness", "fattens", "fattest", "fatties", "fatuous", "faucets", "faulted", "fauvism", "favelas", "favored", "favours", "fawcett", "fawning", "fayette", "fearful", "fearing", "feasted", "feaster", "feather", "feature", "febrile", "febuary", "federal", "fedoras", "feeders", "feeding", "feedlot", "feelers",  "feelies", "feeling", "feigned", "feldman", "felicia", "felines", "fellers", "felling", "fellows", "feltman", "females", "femoral", "fencers", "fencing", "fenders", "fending", "fenelon", "fenland", "fenster", "fenwick", "fermata", "ferment", "fernand", "ferrara", "ferrari", "ferraro", "ferrell", "ferrets", "ferried", "ferrier", "ferries", "ferrite", "ferrous", "fertile", "fervent", "fervour", "festers", "festive", "festoon", "fetched", "fetches", "fetters", "fetuses", "feuding", "fevered", "fiancee", "fiascos", "fibbing", "fibroid", "fibrous", "fiction", "fictive", "fiddled", "fiddler", "fiddles", "fidgets", "fidgety", "fiedler", "fiefdom", "fielded", "fielder", "fiercer", "fiestas", "fifteen", "fifthly", "fifties", "fighter", "figment", "figural", "figured", "figures", "fijians", "filbert", "filched", "filenet", "filings", "filippi", "filippo", "fillers", "fillets", "fillies", "filling", "filming", "filofax", "filters", "finagle", "finales", "finally", "finance", "finches", "finders", "finding", "findlay", "findley", "fineman", "finesse", "fingers", "finials", "finicky", "finland", "finnair", "finning", "finnish", "firearm", "firebox", "firebug", "firefly", "firefox", "fireman", "firemen", "firings", "firkins", "firmest", "firming", "firstly", "fischer", "fishers", "fishery", "fisheye", "fishing", "fishman", "fishnet", "fissile", "fission", "fissure", "fistful", "fisting", "fistula", "fitness", "fitters", "fittest", "fitting", "fixable", "fixated", "fixates", "fixedly", "fixings", "fixture", "fizzing", "fizzled", "fizzles", "flaccid", "flagged", "flagger", "flagler", "flagman", "flailed", "flaking", "flamers", "flaming", "flanged", "flanges", "flanked", "flanker", "flannel", "flapped", "flapper", "flaring", "flashed", "flasher", "flashes", "flatbed", "flatten", "flatter", "flaunts", "flavell", "flavors", "flavour", "flaying", "flecked", "fledged", "fleeced", "fleeces", "fleeing", "fleming", "flemish", "fleshed", "flesher", "fleshes", "fleshly", "flexing", "flexion", "flicked", "flicker", "flights", "flighty", "flipped", "flipper", "flippin", "flirted", "flitted", "flitter", "floated", "floater", "flocked", "flogged", "flogger", "flooded", "floored", "flopped", "florals", "florets", "florian", "florida", "florins", "florist", "flossie", "flotsam", "flounce", "floured", "flouted", "flowers", "flowery", "flowing", "flubbed", "fluency", "fluffed", "fluidly", "flunked", "flushed", "flushes", "fluster", "fluting", "flutist", "flutter", "fluvial", "flyable", "flyaway", "flyleaf", "flyover", "flytrap", "flyways", "foaling", "foaming", "focused", "focuses", "fogarty", "fogging", "foghorn", "foibles", "foiling", "foisted", "folders", "folding", "foldout", "foliage", "foliate", "folkish", "folkman", "follett", "follies", "follows", "fomento", "fondest", "fondled", "fondles", "fonseca", "fontana", "fontina", "foolery", "fooling", "foolish", "footage", "footers", "footing", "footman", "footmen", "footsie", "foppish", "foraged", "forages", "foramen", "forbade", "forbear", "forbids", "forcast", "force's", "forceps", "forcing", "fordham", "fording", "forearm", "foreign", "foreleg", "foreman", "foremen", "foresaw", "foresee", "forests", "forever", "forfeit", "forfend", "forgave", "forgers", "forgery", "forgets", "forging", "forgive", "forgoes", "forgone", "forints", "forking", "forlorn", "formals", "formant", "formate", "formats", "formers", "formica", "forming", "formosa", "formula", "forrest", "forsake", "forseen", "forsman", "forsook", "forster", "forsyth", "fortier", "forties", "fortify", "fortran", "fortuna", "fortune", "forum's", "forward", "fossils", "fosters", "foulest", "fouling", "foulkes", "founded", "founder", "foundry", "fourier", "fourths", "foxboro", "foxfire", "foxhole", "foxtail", "foxtrot", "fractal", "fragged", "fragile", "frailty", "framers", "framing", "frances", "francia", "francie", "francis", "franked", "frankel", "frankie", "frankly", "frannie", "frantic", "frasier", "fraught", "fraying", "frazier", "frazzle", "freaked", "freckle", "freddie", "fredrik", "freebie", "freedom", "freeing", "freeman", "freemen", "freesia", "freeway", "freezed", "freezer", "freezes", "freight", "freitag", "freitas", "frelimo", "fremont", "frenchy", "frenkel", "frescos", "freshen", "fresher", "freshly", "fresnel", "fretful", "fretted", "fretter", "freytag", "friable", "friberg", "fricker", "fridays", "fridges", "friends", "friesen", "friezes", "frigate", "frights", "frilled", "fringed", "fringes", "frisbee", "frisian", "frisked", "frisson", "fritter", "frizzle", "frogged", "frogger", "frogman", "frolics", "fromage", "frommer", "fromthe", "frontal", "fronted", "frosted", "froward", "frowned", "fruited", "frumkin", "fuchsia", "fucking", "fudging", "fuehrer", "fueling", "fuelled", "fuentes", "fujitsu", "fukuoka", "fulcher", "fulcrum", "fulfill", "fulfils", "fulford", "fullers", "fullest", "fulsome", "fumbled", "fumbles", "funders", "funding", "funeral", "funkier", "funnels", "funnest", "funnier", "funnies", "funnily", "furious", "furling", "furlong", "furnace", "furness", "furnish", "furniss", "furrier", "furrows", "furtado", "further", "furtive", "fusebox", "fusilli", "fusions", "fussell", "fussing", "futures", "futzing", "fuzzier", "fuzzies", "fuzzily", "fuzzing", "gabbard", "gabbing", "gabriel", "gadgets", "gadsden", "gaetano", "gaffers", "gaffney", "gagarin", "gagging", "gainers", "gainful", "gaining", "gainsay", "gaiters", "galahad", "galante", "galatea", "galeria", "galerie", "galette", "galiano", "galicia", "galilee", "galilei", "galileo", "galindo", "gallant", "gallego", "galleon", "gallery", "galleys", "galling", "gallium", "gallons", "gallops", "gallows", "gambian", "gambits", "gambled", "gambler", "gambles", "gambrel", "gameboy", "gamelan", "gametes", "gammons", "gandalf", "ganging", "ganglia", "gangsta", "gangway", "gannets", "gannett", "gantlet", "gapping", "garaged", "garages", "garbage", "garbled", "gardens", "gardner", "gargled", "gargles", "garland", "garlick", "garment", "garners", "garnets", "garnett", "garnish", "garrard", "garratt", "garrets", "garrett", "garrick", "garrido", "garrity", "garside", "garters", "gartner", "garwood", "gaseous", "gaskets", "gaskill", "gaskins", "gasohol", "gaspard", "gasping", "gassing", "gastric", "gateway", "gathers", "gatling", "gatwick", "gaucher", "gauchos", "gaughan", "gauging", "gauguin", "gautier", "gavotte", "gawkers", "gawking", "gaylord", "gayness", "gazebos", "gazelle", "gazette", "gazprom", "gearbox", "gearing", "geezers", "gefilte", "geishas", "gelatin", "gelding", "gellert", "gelling", "gemayel", "geminis", "gemmell", "gemsbok", "genders", "general", "generic", "genesee", "genesis", "genetic", "genghis", "genital", "gennaro", "genoese", "genomes", "genomic", "genteel", "gentian", "gentile", "gentler", "gentles", "genuine", "genzyme", "geodesy", "geology", "geordie", "georges", "georgia", "georgie", "geraldo", "gerardo", "gerbera", "gerbils", "gerhard", "gerhart", "gerlach", "germain", "germane", "germano", "germans", "germany", "gerrard", "gershon", "gertler", "gerunds", "gervais", "gervase", "gestalt", "gestapo", "gestate", "gestion", "gesture", "getaway", "getters", "getting", "gewgaws", "geysers", "ghastly", "ghettos", "ghosted", "ghostly", "giacomo", "giant's", "giardia", "gibbins", "gibbons", "giblets", "gibsons", "giddily", "giessen", "gifford", "gifting", "gigabit", "gigante", "gigging", "giggled", "giggles", "gigolos", "gilbert", "gilding", "gillett", "gilliam", "gillian", "gillies", "gillman", "gilmore", "gilmour", "gimbals", "gimmick", "ginevra", "gingers", "gingery", "gingham", "ginning", "ginseng", "giorgio", "giraffe", "girardi", "girders", "girding", "girdled", "girdles", "girlies", "girlish", "giselle", "gizzard", "glacial", "glacier", "gladden", "gladwin", "glamour", "glanced", "glances", "glaring", "glasgow", "glassed", "glasser", "glasses", "glauber", "glazers", "glazier", "glazing", "gleamed", "gleaned", "gleaner", "gleason", "gleeful", "gleeson", "glennie", "glidden", "gliders", "gliding", "glimmer", "glimpse", "glinted", "gliomas", "glisten", "glitter", "gloated", "globals", "glommed", "gloried", "glories", "glorify", "glossed", "glosses", "gloster", "glottal", "glowing", "glucose", "glueing", "gluteus", "glutted", "glutton", "glycine", "glycols", "gnarled", "gnawing", "gnocchi", "gnomish", "gnostic", "goading", "goalies", "gobbled", "gobbler", "gobbles", "goblets", "goblins", "godbold", "goddamn", "goddard", "goddess", "godfrey", "godhead", "godhood", "godless", "godlike", "godowns", "godsend", "godward", "goering", "goggled", "goggles", "golding", "goldman", "goldwyn", "golfers", "golfing", "goliath", "gondola", "gonzalo", "goobers", "goodall", "goodbye", "goodell", "gooders", "goodies", "gooding", "goodman", "goodson", "goodwin", "goofing", "goonies", "gophers", "gordian", "gorging", "gorgons", "gorilla", "gormley", "gorrell", "goshawk", "gosling", "gosnell", "gospels", "gosport", "gossard", "gossett", "gossips", "gossipy", "gotchas", "gothard", "gouache", "gouging", "goulash", "gourmet", "gouveia", "governs", "grabbed", "grabber", "gracias", "gracile", "gracing", "grackle", "graders", "grading", "gradual", "grafted", "grahams", "grained", "grammar", "grammer", "grammes", "grammys", "granada", "granado", "granary", "grandad", "grandee", "grander", "grandes", "grandly", "grandma", "grandpa", "granger", "granges", "granita", "granite", "grannie", "granola", "granted", "grantee", "granter", "grantor", "granule", "graphed", "graphic", "grapple", "grasped", "grassed", "grasser", "grasses", "graters", "gratify", "grating", "gratton", "gravels", "gravely", "gravest", "gravies", "graving", "gravity", "gravure", "graydon", "graying", "grayish", "grayson", "grazers", "grazier", "grazing", "greased", "greaser", "greases", "greater", "greatly", "greaves", "grecian", "greeley", "greener", "greenly", "greenup", "greeted", "greeter", "gregory", "gregson", "greisen", "gremlin", "grenada", "grenade", "grenier", "gresham", "greying", "greyish", "gribben", "gribble", "gridded", "griddle", "gridley", "grieved", "griever", "grieves", "griffen", "griffin", "griffon", "grifter", "grigsby", "grilled", "griller", "grilles", "grimace", "grimley", "grimmer", "grinded", "grinder", "grindle", "gringos", "grinned", "griping", "gripped", "gripper", "grisham", "grissom", "gristle", "gritted", "grizzle", "grizzly", "groaned", "grocers", "grocery", "groomed", "groomer", "grooved", "groover", "grooves", "groping", "grossed", "grosser", "grosses", "grossly", "grottos", "groucho", "grouchy", "grounds", "grouped", "grouper", "groupie", "groused", "grouses", "grovers", "growers", "growing", "growled", "growler", "grownup", "growths", "grubber", "grudges", "gruffly", "grumble", "grumman", "grunion", "grunted", "grunter", "gruyere", "gryphon", "guanaco", "guangxi", "guanine", "guarana", "guarani", "guarded", "guardia", "guarino", "gubbins", "gudgeon", "guenter", "guessed", "guesser", "guesses", "guested", "guevara", "guffaws", "guiding", "guilder", "guillot", "guinean", "guineas", "guiness", "guitars", "gujarat", "gullets", "gullies", "gulping", "gumming", "gumshoe", "gunboat", "gunfire", "gunnels", "gunners", "gunnery", "gunning", "gunplay", "gunship", "gunshot", "gunther", "gunwale", "guppies", "gurgles", "gurneys", "gushers", "gushing", "gussets", "gussied", "gustave", "gustavo", "gusting", "guthrie", "gutless", "gutmann", "gutters", "gutting", "guttman", "guzzler", "guzzles", "gymnast", "gypsies", "gyrated", "habitat", "hackers", "hackett", "hacking", "hackles", "hackman", "hackney", "hacksaw", "hadaway", "haddock", "hadrian", "hageman", "hagerty", "hagfish", "haggard", "haggled", "hailing", "haircut", "hairdos", "hairier", "hairpin", "haitian", "halbert", "halcyon", "halfway", "halfwit", "halibut", "halides", "halifax", "halling", "hallman", "hallock", "hallows", "hallway", "halogen", "halpern", "halprin", "halters", "halting", "halving", "halyard", "hamblin", "hambone", "hamburg", "hamlets", "hammers", "hammill", "hamming", "hammock", "hammond", "hammons", "hampers", "hampson", "hampton", "hamster", "hanauer", "hanbury", "hancock", "handbag", "handers", "handful", "handgun", "handier", "handily", "handing", "handled", "handler", "handles", "handley", "handoff", "handout", "handsaw", "handset", "hanford", "hangars", "hangdog", "hangers", "hangin'", "hanging", "hangman", "hangmen", "hangout", "hangups", "hankies", "hankins", "hanover", "hansard", "hanssen", "hansson", "hanuman", "hapless", "haploid", "happens", "happier", "happily", "haptics", "harbert", "harbors", "harbour", "hardens", "hardest", "hardhat", "hardier", "harding", "hardman", "hardtop", "haricot", "harkens", "harking", "harkins", "harland", "harleys", "harling", "harlots", "harmful", "harming", "harmony", "harness", "harpers", "harpies", "harping", "harpist", "harpoon", "harrell", "harried", "harrier", "harries", "harriet", "harrods", "harrows", "harsher", "harshly", "harting", "hartley", "hartman", "hartson", "hartwig", "harvard", "harvest", "harwell", "harwich", "harwood", "haryana", "hashing", "hashish", "hasidic", "hasidim", "haskell", "haskins", "haslett", "hassell", "hassett", "hassled", "hassler", "hassles", "hastens", "hastily", "hasting", "haswell", "hatched", "hatcher", "hatches", "hatchet", "hateful", "hatless", "hatreds", "hatters", "hattery", "haughey", "haughty", "haulage", "haulers", "hauling", "haunted", "hausman", "hauteur", "haven't", "hawkers", "hawkeye", "hawking", "hawkins", "hawkish", "haworth", "hayashi", "haycock", "haydock", "hayloft", "hayride", "hayseed", "hayward", "haywire", "haywood", "hazards", "hazzard", "headers", "heading", "headley", "headman", "headset", "headway", "healers", "healing", "healthy", "heaping", "hearers", "hearing", "hearken", "hearsay", "hearses", "hearted", "hearten", "hearths", "heaters", "heathen", "heather", "heating", "heavens", "heavier", "heavies", "heavily", "heaving", "hebraic", "hebrews", "heckled", "heckler", "heckman", "heckuva", "hectare", "hedgers", "hedging", "hedonic", "hedrick", "heeding", "heeling", "heffner", "heftier", "hefting", "hegemon", "heifers", "heights", "heimann", "heinous", "heiress", "heisman", "helical", "helicon", "helipad", "hellcat", "hellion", "hellish", "hellman", "helluva", "helmets", "helming", "helpers", "helpful", "helping", "hemline", "hemlock", "hemming", "hemsley", "hendler", "hendren", "hendrik", "hendrix", "henning", "henshaw", "hensley", "henwood", "heparin", "hepatic", "hepburn", "heralds", "herbage", "herbals", "herbert", "herders", "herding", "herdman", "heredia", "heretic", "hermann", "hermans", "hermits", "herndon", "hernias", "heroics", "heroine", "heroism", "herrera", "herrick", "herring", "herself", "hershey", "hertzog", "hesketh", "hessian", "hessler", "hewlett", "hexagon", "heydays", "heyward", "hialeah", "hibachi", "hibbard", "hibberd", "hiccups", "hickman", "hickory", "hickson", "hidalgo", "hideous", "hideout", "hiebert", "higashi", "higgins", "highest", "highway", "hijacks", "hijinks", "hilbert", "hillard", "hillary", "hillier", "hillman", "hillock", "hilltop", "himself", "hinchey", "hinders", "hinging", "hinkley", "hinshaw", "hinting", "hipbone", "hipness", "hippest", "hippies", "hipster", "hirings", "hiroshi", "hirsute", "hispano", "hisself", "hissing", "history", "hitachi", "hitched", "hitches", "hitless", "hitoshi", "hitters", "hitting", "hittite", "hoarded", "hoarder", "hoaxers", "hobbies", "hobbits", "hobbled", "hobbles", "hobnail", "hoboken", "hockett", "hocking", "hockley", "hockney", "hodgins", "hodgkin", "hodgson", "hoedown", "hoffman", "hofmann", "hogging", "hogtied", "hogwash", "hoisted", "holcomb", "holdall", "holders", "holding", "holdout", "holdups", "holgate", "holiday", "holiest", "holland", "hollers", "hollies", "hollins", "hollows", "holmium", "holster", "holston", "holyoke", "homages", "hombres", "homburg", "homeboy", "homered", "homeric", "homerun", "hominem", "hominid", "hommage", "homonym", "honchos", "honesty", "honeyed", "honiara", "honkers", "honking", "honored", "honoree", "honours", "hoochie", "hooding", "hoodlum", "hoofers", "hookahs", "hookers", "hooking", "hookups", "hoopers", "hoosier", "hooters", "hooting", "hoovers", "hopeful", "hopkins", "hoppers", "hopping", "hopwood", "horatio", "hording", "horizon", "hormone", "hornets", "horning", "hornsby", "hornung", "horrify", "horrors", "horsham", "horsing", "horvath", "hosanna", "hosiery", "hoskins", "hospice", "hossain", "hostage", "hostels", "hostess", "hostile", "hosting", "hostler", "hotbeds", "hotdogs", "hotfoot", "hothead", "hotline", "hotness", "hotshot", "hotspot", "hotspur", "hottest", "hotting", "hotwire", "houdini", "houlton", "hounded", "housing", "housley", "houston", "hovered", "howards", "howarth", "howells", "however", "howlers", "howlett", "howling", "hubbard", "hubbell", "hubcaps", "huddled", "huddles", "huertas", "huffing", "huffman", "huggers", "hugging", "huggins", "hulbert", "hulking", "humanly", "humbert", "humbled", "humbler", "humbles", "humbugs", "humdrum", "humerus", "humidor", "humming", "hummock", "humoral", "humored", "humours", "humphry", "humping", "humvees", "hunched", "hunches", "hundred", "hungary", "hungers", "hunters", "hunting", "huntley", "hurdled", "hurdler", "hurdles", "hurlers", "hurling", "hurried", "hurries", "hurston", "hurtful", "hurting", "hurtled", "hurtles", "hurwitz", "husband", "hushing", "huskers", "huskies", "husking", "hussain", "hussars", "hussein", "hustled", "hustler", "hustles", "hutches", "hyannis", "hybrids", "hydrant", "hydrate", "hydride", "hydroxy", "hygiene", "hymnals", "hyndman", "hyphens", "hypoxia", "hypoxic", "hyundai", "ibaraki", "iberian", "ibrahim", "iceberg", "icecaps", "iceland", "icepick", "icicles", "ideally", "idiotic", "idolize", "idyllic", "iglesia", "ignacio", "igneous", "ignited", "igniter", "ignites", "ignitor", "ignoble", "ignored", "ignores", "iguanas", "ikebana", "illegal", "illicit", "illness", "illogic", "imagery", "imagine", "imaging", "imamura", "imbibed", "imbuing", "imitate", "immense", "immerse", "immoral", "impacts", "impairs", "impalas", "impaled", "impaler", "imparts", "impasse", "impasto", "impeach", "impeded", "impedes", "imperia", "imperil", "impetus", "impiety", "impinge", "impious", "implant", "implied", "implies", "implode", "implore", "imports", "imposed", "imposes", "imposts", "impound", "impress", "imprint", "improve", "impulse", "imputed", "imputes", "inanely", "inanity", "inboard", "inbound", "inbreed", "inbuilt", "incense", "inching", "incised", "incisor", "incited", "incites", "incline", "include", "incomes", "incubus", "indents", "indepth", "index's", "indexed", "indexer", "indexes", "indiana", "indians", "indices", "indicia", "indicts", "indoors", "induced", "inducer", "induces", "indulge", "industy", "ineptly", "inertia", "inexact", "infancy", "infanta", "infante", "infants", "infects", "inferno", "infests", "infidel", "infield", "inflame", "inflate", "inflect", "inflict", "inflows", "infonet", "informa", "informs", "infused", "infuses", "ingalls", "ingenue", "ingests", "inglese", "ingrain", "ingrate", "ingress", "ingrown", "inhabit", "inhaled", "inhaler", "inhales", "inherit", "inhibit", "inhouse", "inhuman", "initial", "injects", "injured", "injures", "inkblot", "inkling", "inkwell", "inmates", "innards", "innings", "inquest", "inquire", "inquiry", "inroads", "inscape", "insects", "inserts", "inshore", "insider", "insides", "insight", "insipid", "insists", "insofar", "insoles", "inspect", "inspire", "install", "instant", "instate", "instead", "instill", "instore", "insular", "insulin", "insults", "insured", "insurer", "insures", "intakes", "integer", "integra", "intends", "intense", "intents", "interes", "interim", "interns", "interop", "interst", "intoned", "intones", "intouch", "intrude", "invaded", "invader", "invades", "invalid", "inveigh", "invents", "inverse", "inverts", "invesco", "invests", "invited", "invitee", "invites", "invoice", "invoked", "invokes", "involed", "involve", "inwards", "iodides", "ionized", "ipanema", "ipswich", "iranian", "ireland", "iridium", "irksome", "irkutsk", "ironies", "ironing", "ironman", "isabell", "ishmael", "isidore", "islamic", "islands", "isolate", "isomers", "isotope", "israeli", "issuers", "issuing", "isthmus", "italian", "italics", "itching", "itemize", "iterate", "ivanhoe", "iversen", "iverson", "ivorian", "ivories", "iwasaki", "ization", "jabbing", "jacinto", "jackals", "jackass", "jackets", "jacking", "jacklin", "jackman", "jackpot", "jackson", "jacobin", "jacobus", "jacques", "jacquet", "jacuzzi", "jadeite", "jaegers", "jaffray", "jaffrey", "jagdish", "jaggers", "jaguars", "jailers", "jailing", "jainism", "jakarta", "jalisco", "jamaica", "jameson", "jamison", "jammers", "jamming", "janaury", "janeiro", "janelle", "janette", "jangled", "janitor", "janssen", "jansson", "jantzen", "january", "janvier", "japheth", "jardine", "jargons", "jarrell", "jarrett", "jarring", "jasmine", "jaspers", "javelin", "jawbone", "jawline", "jayhawk", "jazzers", "jazzier", "jazzman", "jazzmen", "jealous", "jeanine", "jeannie", "jeepers", "jeepney", "jeering", "jeffers", "jeffery", "jeffrey", "jehovah", "jellied", "jellies", "jelling", "jemison", "jenifer", "jenkins", "jenny's", "jenssen", "jericho", "jerkily", "jerking", "jerkins", "jerrold", "jerseys", "jessica", "jesters", "jesting", "jesuits", "jetties", "jetting", "jeweler", "jewelry", "jezebel", "jiangsu", "jiggers", "jigging", "jiggles", "jigsaws", "jillian", "jillion", "jilting", "jimenez", "jingles", "jitneys", "jitters", "jittery", "joachim", "joaquin", "jobbers", "jobbing", "jobless", "jocasta", "jocelyn", "jockeys", "jocular", "jodhpur", "joggers", "jogging", "johanna", "johnnie", "johnsen", "johnson", "joinder", "joiners", "joinery", "joining", "jointed", "jointer", "jointly", "jollies", "jollity", "jolting", "joneses", "jordans", "jornada", "josephs", "josette", "joshing", "jostled", "jostles", "jotting", "joubert", "journal", "journey", "joycean", "joyless", "joyride", "juanita", "jubilee", "judaism", "judging", "juergen", "juggled", "juggler", "juggles", "jughead", "jugular", "juicier", "jujitsu", "jukebox", "juliana", "jumbled", "jumbles", "jumpers", "jumping", "jungian", "jungles", "juniors", "juniper", "junkers", "junkets", "junkies", "junking", "jupiter", "jurgens", "jurists", "justice", "justify", "justina", "justine", "jutland", "jutting", "juvenal", "kachina", "kaddish", "kaftans", "kaisers", "kalimba", "kallman", "kaminer", "kampala", "kampong", "kannada", "kansans", "kantian", "karachi", "karaoke", "karcher", "karelia", "karlson", "karolyi", "karsten", "karting", "kashmir", "kashrut", "kathryn", "katrina", "kaufman", "kayaked", "kazakhs", "kearney", "keating", "keebler", "keeling", "keenest", "keening", "keepers", "keeping", "keillor", "keister", "kellett", "kellner", "kellogg", "kelowna", "kempner", "kempton", "kendall", "kenmore", "kennard", "kennedy", "kennels", "kenneth", "kennett", "kenning", "kenwood", "kenyans", "keohane", "keratin", "kernels", "kerning", "kerouac", "kershaw", "kersten", "kessler", "kestrel", "keswick", "ketchup", "ketosis", "kettler", "kettles", "keycorp", "keyhole", "keyless", "keynote", "keypads", "keyword", "khalifa", "khanate", "khatami", "kibbles", "kibbutz", "kickers", "kicking", "kickoff", "kiddies", "kidding", "kidnaps", "kidneys", "kieffer", "kiernan", "kilduff", "kilgore", "killeen", "killers", "killian", "killick", "killing", "killjoy", "kilobit", "kimball", "kimonos", "kimpton", "kincaid", "kindest", "kindled", "kindler", "kindles", "kindred", "kinetic", "kinfolk", "kingdom", "kingdon", "kingman", "kingpin", "kinkier", "kinking", "kinnear", "kinnick", "kinship", "kinsley", "kinsman", "kinsmen", "kippers", "kirkman", "kirsten", "kirstie", "kissell", "kissers", "kissing", "kistler", "kitchen", "kitchin", "kitschy", "kittens", "kitties", "kitting", "kiwanis", "kiyoshi", "kleenex", "kleiman", "kleiner", "klepper", "klezmer", "klinger", "klingon", "kloster", "knapper", "knavery", "knavish", "kneaded", "kneecap", "kneeing", "kneeled", "kneeler", "knesset", "knicker", "knievel", "knifing", "knights", "knitted", "knitter", "knobbed", "knocked", "knocker", "knossos", "knotted", "knowhow", "knowing", "knowles", "knuckle", "knudsen", "knutson", "koblenz", "koehler", "koerner", "koizumi", "komatsu", "konkani", "konopka", "koranic", "koreans", "kothari", "kowloon", "kravitz", "kremlin", "kreuger", "krieger", "krishna", "kristen", "kristie", "kristin", "kristof", "kristol", "krueger", "krugman", "krypton", "krystal", "kuantan", "kubrick", "kumquat", "kurdish", "kushner", "kuwaiti", "kwanzaa", "kwazulu", "kyocera", "labeled", "labelle", "labonte", "laborde", "labored", "laborer", "labours", "lachlan", "lachman", "lackeys", "lacking", "laconia", "laconic", "lacoste", "lacquer", "lacroix", "lactase", "lactate", "lactose", "lacunae", "ladders", "ladies'", "ladybug", "lafarge", "lafitte", "lafleur", "laggard", "lagging", "lagoons", "lagunas", "laidlaw", "laissez", "lakshmi", "lalande", "lalique", "lalonde", "lambast", "lambeau", "lambent", "lambert", "lambeth", "lambing", "laments", "laminar", "lammers", "lamping", "lampkin", "lampoon", "lamprey", "lampson", "lampung", "lancers", "lancets", "lancing", "lancome", "landers", "landing", "landman", "landrum", "landsat", "langage", "langdon", "langham", "langley", "languid", "languor", "lanigan", "lanolin", "lansing", "lantana", "lantern", "lanyard", "lanzhou", "laotian", "lapdogs", "lapland", "laporte", "lapping", "lapsing", "lapsley", "laptops", "laramie", "larceny", "lardner", "largely", "largent", "largess", "largest", "largish", "larissa", "laroche", "laroque", "lasagna", "lasagne", "lasalle", "lasered", "lashing", "lashley", "lassies", "lassoed", "lastest", "lasting", "latched", "latches", "latency", "lateral", "lathers", "lathrop", "latimer", "latinos", "latrine", "latrobe", "lattice", "latvian", "lauding", "laughed", "laugher", "launder", "laundry", "laurels", "laurens", "laurent", "lavelle", "laverne", "laverty", "lavigne", "lavinia", "lawless", "lawsuit", "lawyers", "laxness", "layaway", "layback", "laydown", "layered", "layoffs", "layouts", "layover", "lazarus", "laziest", "lazzaro", "leached", "leaches", "leaders", "leading", "leadoff", "leafing", "leaflet", "leaguer", "leagues", "leakage", "leakers", "leaking", "leander", "leandro", "leanest", "leaning", "leapers", "leaping", "learjet", "learned", "learner", "leashed", "leashes", "leasing", "leather", "leavell", "leavens", "leavers", "leaving", "leavitt", "lebanon", "leblanc", "lechery", "leclerc", "lectern", "lecture", "lederer", "ledesma", "ledgers", "ledyard", "leeched", "leeches", "leering", "leeuwen", "leeward", "lefever", "lefevre", "lefties", "leftish", "leftism", "leftist", "legally", "legates", "legends", "leggett", "legging", "leghorn", "legible", "legibly", "legions", "legless", "legrand", "legroom", "legumes", "legwork", "lehmann", "lehrman", "leibniz", "leilani", "leipzig", "leisure", "leitner", "lejeune", "lemming", "lemoine", "lenders", "lending", "lenghty", "lengths", "lengthy", "lenient", "lensing", "lentils", "lentini", "leonard", "leonine", "leonora", "leonore", "leopard", "leopold", "leotard", "leppard", "leppert", "leprosy", "leprous", "leptons", "lesbian", "lesions", "lesotho", "lessard", "lessees", "lessens", "lessons", "lessors", "letdown", "leticia", "letitia", "letizia", "letters", "lettice", "letting", "lettuce", "leveled", "levered", "levison", "levitan", "levying", "lexical", "lexicon", "lexmark", "leyland", "liaison", "liasing", "libbing", "libeled", "liberal", "liberia", "liberty", "libidos", "library", "libyans", "licence", "license", "lichens", "licking", "liddell", "liebman", "lifters", "lifting", "liftoff", "ligands", "liggett", "lighted", "lighten", "lighter", "lightly", "lignite", "likable", "likened", "liliana", "lillian", "lilting", "limburg", "limited", "limiter", "limoges", "limpets", "limping", "linares", "lincoln", "lindahl", "lindane", "lindell", "lindens", "lindley", "lindner", "lindsay", "lindsey", "lineage", "linehan", "lineman", "linemen", "lineups", "lingers", "lingual", "linhart", "linings", "linkage", "linkers", "linking", "linnean", "linnell", "linseed", "lintels", "linwood", "lioness", "lippert", "liquefy", "liqueur", "liquide", "liquids", "liquors", "lisette", "lisping", "listens", "listers", "listing", "literal", "lithium", "litters", "littler", "littles", "liturgy", "livable", "livened", "livings", "livonia", "livorno", "lizards", "llorens", "lloyd's", "loaders", "loading", "loafers", "loafing", "loaning", "loathed", "loathes", "lobbied", "lobbies", "lobbing", "lobelia", "lobster", "locales", "locally", "located", "locater", "locates", "locator", "lockbox", "lockers", "lockets", "lockett", "locking", "lockjaw", "lockman", "lockout", "lockyer", "locusts", "lodgers", "lodging", "loftier", "loftily", "lofting", "logbook", "loggers", "logging", "logical", "logjams", "logsdon", "lohmann", "lolitas", "lolling", "lombard", "londres", "longbow", "longest", "longing", "longish", "longley", "longman", "lookers", "looking", "lookout", "looming", "loonies", "loopers", "looping", "loosely", "loosens", "loosest", "loosing", "looters", "looting", "loppers", "lopping", "loraine", "lording", "lorelei", "lorenzo", "loretta", "lorimer", "lorries", "lothian", "lothrop", "lotions", "lottery", "loudest", "louella", "lounged", "lounger", "lounges", "lourdes", "lousing", "loutish", "louvain", "louvres", "lovable", "lovejoy", "lowball", "lowbrow", "lowdown", "lowered", "lowland", "lowlife", "lowndes", "lowness", "lowther", "loyally", "loyalty", "lozenge", "lubbers", "lubbock", "lucerne", "luciano", "lucidly", "lucifer", "lucille", "lucinda", "luckier", "luckily", "lucking", "luddite", "ludmila", "ludwick", "luggage", "lugging", "lullaby", "lulling", "lumbago", "lumbers", "lumping", "lumpkin", "lunatic", "lunched", "lunches", "lunging", "lurched", "lurches", "luridly", "lurkers", "lurking", "lustful", "lustily", "lusting", "luthier", "lybrand", "lynched", "lynette", "lyrical", "lysaght", "maarten", "macabre", "macadam", "macaque", "macbeth", "macchia", "macedon", "machado", "machete", "machina", "machine", "macklin", "maclean", "macleod", "macphee", "macrame", "macular", "maddens", "maddest", "madding", "maddock", "madeira", "madelyn", "madison", "madness", "madonna", "madrone", "maestas", "maestri", "maestro", "mafiosi", "mafioso", "magadan", "magdala", "magenta", "maggots", "magical", "maginot", "magnate", "magness", "magneto", "magnets", "magnify", "magnums", "magpies", "maguire", "mahajan", "mahatma", "mahjong", "mahmood", "mahmoud", "mahomet", "mahoney", "mahonia", "maidens", "mailbag", "mailbox", "mailers", "mailing", "maillot", "mailman", "mailmen", "maiming", "majesty", "majeure", "majorca", "majored", "majorly", "makeups", "makings", "maktoum", "malabar", "malacca", "malachi", "malaika", "malaise", "malanga", "malaria", "malarky", "malayan", "malcolm", "mallard", "mallets", "mallett", "mallory", "mallows", "maloney", "maltese", "malthus", "malting", "maltose", "malvern", "mammals", "mammary", "mammoth", "managed", "manager", "manages", "managua", "manatee", "manchus", "mancini", "mandala", "mandate", "mandela", "mandell", "manders", "mandola", "manford", "manfred", "mangels", "mangers", "mangled", "mangler", "mangles", "mangoes", "mangold", "manhole", "manhood", "manhunt", "maniacs", "manikin", "manilla", "manipur", "manitou", "mankind", "manlike", "manlove", "manmade", "manners", "manning", "mannino", "mannish", "manohar", "mansard", "manship", "mansion", "mansour", "mantels", "mantles", "mantras", "manuals", "manures", "manzano", "maoists", "mappers", "mapping", "marabou", "maracas", "marathi", "marbach", "marbled", "marbles", "marbury", "marceau", "marcelo", "marched", "marcher", "marches", "marconi", "marcoux", "margate", "margaux", "margery", "margins", "margret", "mariana", "mariani", "mariano", "marilyn", "marimba", "marinas", "mariner", "marines", "marissa", "marital", "marjory", "markers", "markets", "markham", "marking", "markley", "markman", "markoff", "markups", "marland", "marlena", "marlene", "marlins", "marlowe", "marmara", "marmion", "marmite", "marmots", "marnell", "maroons", "marquee", "marques", "marquez", "marquis", "married", "marries", "marring", "marriot", "marsala", "marsden", "marshal", "marshes", "marston", "martell", "martens", "martial", "martian", "martina", "martine", "marting", "martini", "martino", "martins", "martyrs", "marvell", "marvels", "marwick", "marxian", "marxism", "marxist", "maryann", "masaaki", "mascara", "mascots", "mashing", "maskell", "masking", "masonic", "masonry", "massage", "massaro", "masseur", "massimo", "massing", "massive", "masters", "mastery", "mastiff", "matador", "matalin", "matched", "matches", "matchup", "mathers", "mathews", "mathias", "matilda", "matinee", "matings", "matisse", "matlock", "matrons", "matsuri", "matters", "matthew", "matthey", "mattias", "matting", "mattock", "mattson", "matured", "maturer", "matures", "maudlin", "maulana", "mauldin", "mauling", "maunder", "maureen", "maurice", "maurine", "mawkish", "maxilla", "maximal", "maximum", "maximus", "maxwell", "maycock", "mayfair", "maynard", "mayoral", "mayotte", "maypole", "mazurka", "mazzone", "mcallen", "mcbride", "mccarty", "mcclane", "mcclean", "mccloud", "mcclure", "mccombs", "mccourt", "mccrory", "mccully", "mccurdy", "mccurry", "mcelroy", "mcenroe", "mcgarry", "mcginty", "mcglade", "mcglynn", "mcgough", "mcgowan", "mcgowen", "mcgrady", "mcgrane", "mcgrath", "mcgrory", "mcguinn", "mcguire", "mcgwire", "mchenry", "mcinnes", "mckenna", "mclaren", "mclarty", "mcleish", "mcmahon", "mcmanus", "mcmoran", "mcnally", "mcnamee", "mcnealy", "mcneese", "mcneill", "mcnulty", "mcphail", "mcquade", "mcquaid", "mcqueen", "mcshane", "mcveigh", "meadows", "meagher", "meander", "meanest", "meanies", "meaning", "measles", "measure", "meatier", "meddled", "meddler", "meddles", "medians", "mediate", "medical", "medicos", "medicus", "mediums", "medleys", "medlock", "medulla", "meeting", "megabit", "megaton", "mehlman", "meisner", "meissen", "meister", "melamed", "melange", "melanie", "melanin", "melcher", "melding", "melinda", "melissa", "melling", "mellows", "melnick", "melodic", "melrose", "melting", "meltzer", "members", "memento", "memoirs", "memorex", "memphis", "menaced", "menaces", "mencken", "mending", "mendoza", "menezes", "menfolk", "menorah", "menthol", "mention", "mentors", "menzies", "meowing", "mercado", "mercier", "mercies", "mercury", "mergers", "merging", "merited", "merlins", "mermaid", "merrell", "merriam", "merrick", "merrier", "merrill", "merrily", "merritt", "meshing", "message", "messiah", "messier", "messily", "messina", "messing", "mestizo", "metcalf", "meteors", "metered", "methane", "metheny", "methode", "methods", "metlife", "metrics", "metzger", "metzler", "meunier", "mewling", "mexican", "mezuzah", "micahel", "michael", "michaud", "michaux", "micheal", "michela", "michele", "michels", "mickeys", "microbe", "microns", "middies", "middles", "mideast", "midgets", "midgley", "midland", "midlife", "midline", "midnite", "midriff", "midship", "midsize", "midterm", "midtown", "midweek", "midwest", "midwife", "midyear", "mifflin", "mignons", "migrant", "migrate", "mikhail", "milagro", "milbank", "milburn", "mildest", "mildred", "mileage", "milfoil", "milford", "miliary", "milieus", "militia", "milkers", "milking", "milkman", "milkmen", "millage", "millard", "millers", "millets", "millett", "milling", "million", "millman", "mimesis", "mimetic", "mimicry", "mimimum", "mimosas", "minaret", "mincing", "minders", "mindful", "minding", "mindset", "mineola", "mineral", "minerva", "minette", "mingled", "mingles", "minibar", "minibus", "minicar", "minimal", "minimis", "minimum", "minimus", "mininum", "minions", "minivan", "miniver", "minkoff", "minnich", "minnick", "minnows", "minolta", "minorca", "minored", "minster", "mintage", "minting", "mintues", "minuets", "minuses", "minuted", "minutes", "minutia", "miocene", "miracle", "mirages", "miramar", "miramax", "miranda", "mirrors", "miscast", "miscues", "misdeed", "miserly", "misfire", "misfits", "mishaps", "mishear", "mislaid", "mislead", "misread", "misrule", "missile", "missing", "mission", "missive", "misstep", "mistake", "misters", "misting", "mistook", "mistral", "misused", "misuses", "mitcham", "mitchel", "mitchum", "mittens", "mitzvah", "mixture", "mizrahi", "moakley", "moaning", "mobbing", "mobiles", "mobster", "mockery", "mocking", "mockups", "model's", "modeled", "modeler", "moderne", "moderns", "modesto", "modesty", "modicum", "modular", "modules", "modulus", "moeller", "moffatt", "moffett", "mohamad", "mohamed", "mohawks", "mohican", "moisten", "moister", "molders", "molding", "moldova", "molests", "moliere", "mollify", "mollusk", "molokai", "molotov", "molting", "momenta", "momento", "moments", "mommies", "monahan", "monarch", "mondale", "mondavi", "mondays", "mondial", "moneyed", "mongers", "mongols", "mongrel", "moniker", "monique", "monitor", "monkeys", "monkish", "monocle", "monomer", "monreal", "monsoon", "monster", "montage", "montagu", "montana", "montane", "montego", "montero", "month's", "monthly", "montiel", "montini", "montoya", "moocher", "moodier", "moodily", "moonies", "mooning", "moonlit", "mooring", "moorish", "moorman", "mooting", "mopping", "moraine", "morales", "morally", "mordant", "moreira", "morella", "morello", "morelos", "moretti", "morever", "morford", "morgans", "morgues", "morioka", "mormons", "morning", "morocco", "moroney", "moronic", "morphic", "morrell", "morsels", "mortals", "mortars", "mortier", "mortify", "mortise", "mosaics", "moscato", "moscoso", "moseley", "moselle", "moslems", "mosques", "mostafa", "mothers", "motions", "motives", "motored", "mottled", "mottoes", "moulded", "moulder", "moulton", "mounded", "mounted", "mounter", "mountie", "mourned", "mourner", "mousing", "mouthed", "movable", "movie's", "mowbray", "muammar", "mubarak", "mucking", "mucosal", "muddied", "muddier", "muddies", "muddled", "muddles", "mueller", "muezzin", "muffins", "muffled", "muffler", "muffles", "muggers", "mugging", "mugshot", "mujahid", "mujeres", "mukhtar", "mulatto", "mulcahy", "mulched", "mulches", "mulford", "mulhern", "mullahs", "mullens", "mullets", "mulling", "mullins", "mumbled", "mumbles", "mumford", "mummers", "mummies", "mummify", "munched", "muncher", "munches", "mundane", "munster", "muntjac", "muppets", "murders", "murdoch", "murdock", "murillo", "murkier", "murmurs", "murphys", "murrell", "murtagh", "muscled", "muscles", "muscovy", "musette", "museums", "mushers", "mushing", "musical", "musings", "musique", "muskets", "muskrat", "muslims", "muslins", "mussels", "must've", "mustafa", "mustang", "mustard", "musters", "mustn't", "mutable", "mutagen", "mutants", "mutated", "mutates", "mutters", "mutuals", "muzzled", "muzzles", "myanmar", "myeloid", "myeloma", "myerson", "mykonos", "myriads", "myrtles", "mystere", "mystery", "mystics", "mystify", "nabbing", "nabisco", "nabokov", "nacelle", "nagging", "nahuatl", "nailing", "nairobi", "naively", "naivete", "naivety", "nakedly", "nametag", "namibia", "nanette", "nanjing", "nanking", "nannies", "nanning", "nanyang", "naphtha", "napkins", "nappies", "napping", "narayan", "narrate", "narrows", "narthex", "narwhal", "nasally", "nascent", "nastier", "nasties", "nastily", "natalia", "natalie", "natasha", "natchez", "nations", "natives", "natural", "natured", "natures", "natwest", "naughty", "naumann", "nauseam", "nauseum", "nautica", "navajos", "navarra", "navarre", "navarro", "naziism", "nearest", "nearing", "neatest", "nebulae", "necking", "necktie", "nectars", "needful", "needham", "needing", "needled", "needler", "needles", "needn't", "negated", "negates", "neglect", "negress", "negroes", "negroid", "neilsen", "neilson", "neither", "nelsons", "nemesis", "nemours", "nephews", "neptune", "nervosa", "nervous", "nesbitt", "nesmith", "nesters", "nesting", "nestled", "nestler", "nestles", "netsuke", "netting", "nettled", "nettles", "netware", "network", "neuhaus", "neumann", "neurone", "neurons", "neutral", "neutron", "nevadan", "neville", "newberg", "newbies", "newbold", "newborn", "newburg", "newbury", "newcomb", "newgate", "newline", "newmark", "newmont", "newness", "newport", "newsboy", "newsday", "newsies", "newsman", "newsmen", "newsome", "newtons", "newtown", "neyland", "niagara", "nibbled", "nibbler", "nibbles", "niccolo", "nichola", "nichols", "nickell", "nickels", "nicking", "nickles", "nickson", "nicolai", "nicolas", "nicolay", "nicolle", "nicosia", "nielsen", "nielson", "niemann", "niether", "nigella", "nigeria", "niggers", "niggles", "nighter", "nightie", "nightly", "niklaus", "nikolai", "nikolay", "nimbler", "nimrods", "nineveh", "ninnies", "niobium", "nippers", "nipping", "nipples", "nirvana", "nitpick", "nitrate", "nitride", "nitrite", "nitrous", "nitwits", "noblest", "nodding", "nodular", "nodules", "nogales", "noisier", "noisily", "noisome", "nomadic", "nominal", "nominee", "noncash", "noncore", "nonfarm", "nonfood", "nonstop", "nonzero", "noodles", "noonday", "noranda", "norbert", "norbury", "nordics", "nordisk", "norfolk", "norilsk", "norland", "normals", "normand", "normans", "northam", "northen", "norther", "norwalk", "norwest", "norwich", "norwood", "nosegay", "nostril", "nostrum", "notable", "notably", "notated", "notched", "notches", "notepad", "nothern", "nothin'", "nothing", "noticed", "notices", "notions", "noughts", "nourish", "nouveau", "novella", "novelle", "novelty", "novices", "novotny", "nowhere", "nowicki", "noxious", "nozzles", "nuanced", "nuances", "nuclear", "nucleic", "nucleus", "nudging", "nudists", "nuestra", "nuggets", "nullify", "nullity", "numbers", "numbing", "numeral", "numeric", "nunnery", "nuptial", "nureyev", "nursery", "nursing", "nurture", "nusbaum", "nutcase", "nutmegs", "nutting", "nymphet", "nyquist", "o'brian", "o'brien", "o'clock", "o'grady", "o'keefe", "o'leary", "o'neill", "o'toole", "oakdale", "oakland", "oakleaf", "oakmont", "oakwood", "oarlock", "oarsman", "oarsmen", "oatmeal", "obadiah", "obelisk", "oberlin", "obesity", "obeying", "objects", "oblasts", "obliged", "obliges", "obligor", "oblique", "oblongs", "obloquy", "obscene", "obscura", "obscure", "observe", "obtains", "obverse", "obviate", "obvious", "occured", "oceania", "oceanic", "oceanus", "ocelots", "octagon", "octaves", "octavia", "octavio", "october", "octopus", "ocurred", "oddball", "oddness", "odorant", "odorous", "odyssey", "oedipal", "oedipus", "oeuvres", "offbeat", "offence", "offends", "offense", "offered", "offeree", "offerer", "offeror", "offhand", "offical", "officer", "offices", "officio", "offline", "offload", "offramp", "offsets", "offside", "offsite", "oftener", "ohioans", "oilseed", "oilwell", "okamoto", "okinawa", "oktober", "olefins", "olivier", "olivine", "olympia", "olympic", "olympus", "omelets", "omicron", "ominous", "omitted", "omnibus", "onboard", "oneness", "onerous", "oneself", "onetime", "ongoing", "onshore", "onstage", "ontario", "onwards", "oocytes", "opacity", "opaline", "openers", "opening", "opera's", "operant", "operate", "ophelia", "opiates", "opining", "opinion", "opossum", "opposed", "opposes", "oppress", "optical", "optimal", "optimum", "options", "opulent", "oracles", "oranges", "orangey", "oration", "orators", "oratory", "orbital", "orbited", "orbiter", "orchard", "orchids", "ordains", "ordeals", "ordered", "orderly", "oregano", "orestes", "organic", "organon", "organum", "organza", "orgasms", "orginal", "oriente", "orients", "orifice", "origami", "origins", "orignal", "orinoco", "orioles", "orlando", "orleans", "orphans", "orpheum", "orpheus", "orville", "osborne", "oshkosh", "osmosis", "osmotic", "ospreys", "ossetia", "ossuary", "ostrich", "othello", "other's", "others'", "ottoman", "ourself", "ousting", "outages", "outback", "outcast", "outcome", "outcrop", "outdoes", "outdone", "outdoor", "outfall", "outfits", "outflow", "outgrew", "outgrow", "outings", "outland", "outlast", "outlaws", "outlays", "outlets", "outlier", "outline", "outlive", "outlook", "outmost", "outpace", "outplay", "outpost", "outputs", "outrage", "outrank", "outruns", "outsell", "outshot", "outside", "outsize", "outsold", "outtake", "outward", "outwits", "outwork", "ovarian", "ovaries", "ovation", "overact", "overage", "overall", "overbid", "overdid", "overdub", "overdue", "overeat", "overfed", "overfly", "overlap", "overlay", "overman", "overpay", "overran", "overrun", "oversaw", "oversea", "oversee", "overtax", "overtly", "overton", "overuse", "ovulate", "oxfords", "oxidant", "oxidase", "oxidize", "oxonian", "oysters", "pabulum", "pacheco", "pacific", "package", "packard", "packers", "packets", "packing", "paddies", "padding", "paddled", "paddler", "paddles", "paddock", "padilla", "padlock", "paducah", "pageant", "pageboy", "pagodas", "pahlavi", "painful", "painted", "painter", "pairing", "paisley", "pajamas", "palabra", "palaces", "palacio", "paladin", "palates", "palaver", "palawan", "palazzi", "palazzo", "palermo", "palette", "palfrey", "pallets", "pallone", "palmeri", "palmers", "palming", "palmtop", "palmyra", "palomar", "palumbo", "pampers", "panacea", "panache", "pancake", "panders", "pandora", "paneled", "panetta", "pangaea", "panicky", "panjabi", "panmure", "pannier", "panning", "panoply", "pansies", "pantano", "panther", "panties", "panting", "panzers", "papayas", "papeete", "paper's", "papered", "papoose", "paprika", "papuans", "papyrus", "parable", "paraded", "parades", "paradis", "paradox", "paragon", "parapet", "parasol", "parboil", "parcels", "parched", "pardner", "pardons", "parente", "parents", "parfait", "pariahs", "paribas", "parkers", "parking", "parkins", "parkway", "parleys", "parlors", "parlour", "parlous", "parnell", "parodic", "paroled", "parolee", "paroles", "parotid", "parquet", "parried", "parries", "parrish", "parrots", "parrott", "parsers", "parsing", "parsley", "parsnip", "parsons", "partake", "parters", "partial", "partida", "partied", "parties", "parting", "partita", "partner", "partook", "partway", "party's", "parvenu", "paschal", "pascual", "pashtun", "passage", "passant", "passers", "passing", "passion", "passive", "passkey", "passman", "pastels", "pasteur", "pasties", "pastime", "pasting", "pastora", "pastore", "pastors", "pasture", "patched", "patches", "patella", "patents", "paterno", "pathans", "pathway", "patient", "patrice", "patrick", "patriot", "patrols", "patrons", "patsies", "pattern", "patters", "patties", "patting", "paucity", "paulina", "pauline", "pauling", "paulino", "paulsen", "paulson", "paunchy", "paupers", "pausing", "pawning", "payable", "payback", "paydays", "payless", "payload", "payment", "payoffs", "payouts", "payroll", "peabody", "peaches", "peacock", "peafowl", "peaking", "pealing", "peanuts", "pearman", "pearson", "peasant", "pebbled", "pebbles", "peckham", "pecking", "pedaled", "pedants", "peddled", "peddler", "peddles", "pedicab", "pedraza", "peebles", "peeking", "peelers", "peeling", "peepers", "peeping", "peerage", "peering", "peevish", "pegasus", "pegging", "pelagic", "pelerin", "pelican", "pellets", "peloton", "peltier", "pelting", "penalty", "penance", "pencils", "pendant", "pending", "penfold", "penguin", "penises", "pennant", "pennell", "pennies", "penning", "pension", "pensive", "pentium", "peonage", "peonies", "peopled", "peoples", "peppers", "peppery", "pepsico", "peptide", "percent", "perched", "perches", "pereira", "perella", "perfect", "perfidy", "perform", "perfume", "pergola", "perhaps", "peridot", "periods", "perjure", "perjury", "perking", "perkins", "perlite", "perlman", "permian", "permits", "pernell", "perplex", "perrier", "perrone", "persaud", "perseus", "persian", "persist", "persona", "persons", "perspex", "persson", "pertain", "perturb", "perugia", "perusal", "perused", "peruses", "pervade", "pervert", "pesetas", "pestles", "peter's", "petered", "petites", "petrels", "petrify", "petting", "petunia", "peugeot", "pfeffer", "pfennig", "pfleger", "phaeton", "phalanx", "phallic", "phallus", "phantom", "pharaoh", "pharynx", "phasers", "phasing", "phenols", "phenoms", "philbin", "philipp", "philips", "phillip", "phillis", "phineas", "phobias", "phoebus", "phoenix", "phoneme", "phonics", "phonies", "phoning", "photons", "phrasal", "phrased", "phrases", "phrygia", "phyllis", "physics", "pianist", "pianola", "piazzas", "picador", "picasso", "piccolo", "pickard", "pickens", "pickers", "pickets", "pickett", "pickier", "picking", "pickled", "pickler", "pickles", "pickney", "pickoff", "pickups", "picnics", "picture", "pidgeon", "piebald", "piecing", "pierced", "pierces", "pierrot", "pierson", "pieties", "pigeons", "piggery", "piggies", "pigging", "piggish", "piglets", "pigment", "pigskin", "pigtail", "pilcher", "pilgrim", "pilings", "pillage", "pillars", "pillbox", "pilling", "pillion", "pillory", "pillows", "piloted", "pilsner", "pimento", "pimlico", "pimping", "pimples", "pinatas", "pinball", "pincers", "pinched", "pincher", "pinches", "pinging", "pinhead", "pinhole", "pinions", "pinkett", "pinkies", "pinking", "pinkish", "pinkney", "pinning", "pinnock", "pintail", "pioneer", "piously", "pipette", "pipkins", "pipping", "pippins", "piquant", "piranha", "pirated", "pirates", "pirelli", "pirogue", "piscine", "pissing", "pistils", "pistols", "pistons", "pitched", "pitcher", "pitches", "piteous", "pitfall", "pithily", "pitiful", "pitstop", "pitting", "pittman", "pitying", "pivotal", "pivoted", "pizzazz", "placard", "placate", "placebo", "placers", "placido", "placing", "placket", "plagued", "plagues", "plainer", "plaines", "plainly", "plaints", "plaisir", "plaited", "planers", "planets", "planing", "planked", "planned", "planner", "plantar", "planted", "planter", "plaques", "plasmas", "plasmid", "plaster", "plastic", "plateau", "plating", "platoon", "platten", "platter", "playboy", "players", "playful", "playing", "playoff", "playpen", "playtex", "pleaded", "pleader", "pleased", "pleaser", "pleases", "pleated", "plebian", "pledged", "pledger", "pledges", "plenary", "pleural", "pliable", "plights", "plinths", "plodded", "plodder", "plonked", "plopped", "plotted", "plotter", "ploughs", "plovers", "plowing", "plowman", "plucked", "plucker", "plugged", "plugger", "plumage", "plumbed", "plumber", "plumley", "plummer", "plummet", "plumped", "plumper", "plunder", "plunged", "plunger", "plunges", "plunked", "plurals", "plusses", "plywood", "poached", "poacher", "pockets", "podesta", "podiums", "poetess", "poetics", "pogroms", "pointed", "pointer", "poirier", "poising", "poisons", "poisson", "pokorny", "polaris", "polecat", "polemic", "polenta", "policed", "polices", "politic", "politik", "pollack", "polland", "pollard", "pollens", "polling", "pollitt", "pollock", "pollute", "polygon", "polymer", "pomeroy", "pomfret", "pompano", "pompeii", "pompoms", "pompons", "pompous", "ponchos", "ponders", "pontiac", "pontiff", "pontius", "pontoon", "pooches", "poodles", "pooling", "poopers", "pooping", "poorest", "poorman", "popcorn", "popeyes", "poplars", "popovic", "poppers", "poppies", "popping", "popular", "porches", "porcine", "porcini", "porkers", "porkpie", "porsche", "portage", "portals", "portend", "portent", "porters", "portico", "porting", "portion", "portman", "portray", "posadas", "poseurs", "poshest", "posible", "posited", "positon", "possess", "possums", "postage", "postdoc", "posters", "posting", "postion", "postive", "postman", "postmen", "posture", "postwar", "potable", "potency", "pothole", "potions", "potluck", "potomac", "potrero", "potsdam", "potshot", "pottage", "potters", "pottery", "potties", "potting", "pouched", "pouches", "poulenc", "poulsen", "poulson", "poulter", "poultry", "pounced", "pounces", "pounded", "pounder", "pouring", "poussin", "pouting", "poverty", "powders", "powdery", "powered", "powerpc", "poynter", "pradesh", "praetor", "prairie", "praised", "praises", "prakash", "praline", "pranced", "prancer", "prances", "prather", "pratice", "prattle", "prayers", "praying", "preachy", "prebble", "precast", "precede", "precept", "precess", "precise", "predate", "predawn", "predict", "preempt", "preened", "prefabs", "preface", "prefect", "prefers", "preform", "pregame", "preheat", "prejean", "prelate", "prelims", "prelude", "premier", "premise", "premium", "prepaid", "prepare", "prepped", "preppie", "prequel", "presage", "presale", "present", "presets", "preside", "presley", "pressed", "presser", "presses", "pressly", "preston", "presume", "preteen", "pretend", "preterm", "pretest", "pretext", "pretzel", "prevail", "prevent", "preview", "prevost", "preying", "pricier", "pricing", "pricked", "prickly", "priding", "priests", "primacy", "primary", "primate", "primers", "priming", "primula", "princes", "pringle", "printed", "printer", "prising", "prisons", "privacy", "private", "privies", "privity", "prizing", "probaby", "probaly", "probate", "probert", "probing", "probity", "problem", "proceed", "proceso", "process", "procter", "proctor", "procure", "prodded", "prodigy", "produce", "product", "profane", "profess", "proffer", "profile", "profits", "profitt", "profuse", "progeny", "progess", "program", "project", "projets", "proline", "prolong", "promise", "promote", "prompts", "pronged", "pronoun", "proofed", "propane", "propels", "prophet", "propose", "propped", "propper", "prorate", "prosaic", "prosody", "prosper", "prosser", "protean", "protect", "protege", "protein", "protest", "proteus", "protons", "prouder", "proudly", "proverb", "provide", "proving", "proviso", "provoke", "provost", "prowess", "prowled", "prowler", "proxies", "proxima", "prudent", "prudery", "prudhoe", "prudish", "pruning", "prussia", "psalter", "psyched", "psyches", "psychic", "psychos", "ptolemy", "puberty", "publico", "publics", "publish", "puccini", "pucelle", "puckett", "puckish", "pudding", "puddled", "puddles", "pueblos", "puerile", "puffers", "puffery", "puffing", "puffins", "pulaski", "pullers", "pulleys", "pulliam", "pulling", "pullman", "pullout", "pulping", "pulpits", "pulsars", "pulsate", "pulsing", "pummels", "pumpers", "pumping", "pumpkin", "punched", "puncher", "punches", "pundits", "pungent", "punjabi", "punkish", "punning", "punters", "punting", "puppets", "puppies", "purcell", "purging", "purists", "puritan", "purling", "purloin", "purnell", "purples", "purport", "purpose", "purpura", "purring", "pursing", "pursued", "pursuer", "pursues", "pursuit", "purview", "puryear", "pushers", "pushing", "pushkin", "pushrod", "pushups", "putdown", "putters", "putting", "puzzled", "puzzler", "puzzles", "pygmies", "pyramid", "pyrites", "pyrrhic", "pythons", "qingdao", "quakers", "quaking", "qualify", "quality", "quandry", "quantum", "quarles", "quarrel", "quarter", "quartet", "quasars", "quashed", "quashes", "quattro", "quavers", "quechua", "queen's", "queenie", "queenly", "quelled", "quentin", "querida", "queried", "queries", "quesada", "quested", "quester", "questor", "quetzal", "queuing", "quevedo", "quezada", "quibble", "quicken", "quicker", "quickie", "quickly", "quieted", "quieten", "quieter", "quietly", "quigley", "quilted", "quilter", "quinine", "quinlan", "quintal", "quintet", "quintin", "quinton", "quintus", "quipped", "quiroga", "quitter", "quivers", "quixote", "quizzed", "quizzes", "quonset", "quoting", "rabbani", "rabbits", "rabbitt", "rabidly", "raccoon", "raceway", "rachael", "racicot", "racists", "rackers", "rackets", "racking", "racoons", "racquet", "radford", "radials", "radiant", "radiate", "radical", "radioed", "raffish", "raffled", "raffles", "rafters", "rafting", "raggedy", "ragging", "ragland", "ragtime", "ragweed", "raiders", "raiding", "railcar", "railing", "railway", "raiment", "rainbow", "rainier", "raining", "rainout", "raisers", "raising", "raisins", "raleigh", "rallied", "rallies", "ralphie", "ralston", "ramadan", "rambled", "rambler", "rambles", "ramirez", "ramming", "rampage", "rampant", "rampart", "ramping", "rancher", "ranches", "randall", "randell", "rangers", "ranging", "rangoon", "rankine", "ranking", "rankled", "rankles", "ransack", "ransoms", "ranting", "raphael", "rapidly", "rapists", "rappers", "rapping", "rapport", "raptors", "rapture", "rarebit", "rascals", "rasheed", "rasping", "ratchet", "rathole", "ratings", "rations", "ratites", "ratliff", "ratting", "rattled", "rattler", "rattles", "raucous", "raunchy", "ravaged", "ravages", "ravenna", "ravines", "ravings", "ravioli", "rawhide", "rawlins", "rawness", "rayburn", "raymond", "reached", "reaches", "reacted", "reactor", "readers", "readied", "readier", "readies", "readily", "reading", "readmit", "readout", "reagent", "realign", "realise", "realism", "realist", "reality", "realize", "realtor", "reaming", "reapers", "reaping", "reapply", "reardon", "rearing", "rearmed", "reasons", "rebated", "rebates", "rebecca", "rebekah", "rebirth", "reboard", "reboots", "rebound", "rebuffs", "rebuild", "rebuilt", "rebuked", "rebukes", "recalls", "recasts", "receded", "recedes", "receipt", "receive", "recency", "recheck", "recieve", "recipes", "recital", "recited", "reciter", "recites", "recived", "reckitt", "reckons", "reclaim", "recline", "recluse", "recoded", "recoils", "records", "recount", "recoups", "recover", "recross", "recruit", "rectify", "rectors", "rectory", "recurve", "recusal", "recused", "recycle", "redback", "redbird", "redbone", "redbook", "redcoat", "reddest", "reddick", "redding", "reddish", "redeems", "redfern", "redfish", "redford", "redhead", "redland", "redline", "redmond", "redneck", "redness", "redoing", "redondo", "redoubt", "redound", "redpath", "redraft", "redrawn", "redraws", "redress", "redskin", "reduced", "reducer", "reduces", "redwing", "redwood", "reefers", "reeking", "reelect", "reeling", "reenact", "reenter", "reentry", "refered", "referee", "refiled", "refills", "refined", "refiner", "refines", "reflect", "refloat", "refocus", "reforma", "reforms", "refound", "refract", "refrain", "reframe", "refresh", "refried", "refugee", "refuges", "refunds", "refusal", "refused", "refuses", "refuted", "refutes", "regains", "regaled", "regales", "regalia", "regally", "regards", "regatta", "regency", "regents", "regimen", "regimes", "regions", "regnant", "regnier", "regrade", "regress", "regrets", "regroup", "regrown", "regular", "regulus", "rehired", "reicher", "reified", "reigned", "reining", "reisner", "reissue", "reitman", "rejects", "rejoice", "rejoins", "relabel", "relapse", "related", "relates", "relator", "relaxed", "relaxer", "relaxes", "relayed", "relearn", "release", "relents", "reliant", "reliefs", "relieve", "relight", "relined", "relived", "relives", "reloads", "relying", "remains", "remakes", "remands", "remarks", "remarry", "rematch", "reminds", "remixed", "remixes", "remnant", "remodel", "remorse", "remoter", "remotes", "removal", "removed", "remover", "removes", "renaldo", "renamed", "renames", "renault", "renders", "rending", "reneged", "reneges", "renewal", "renewed", "renfrew", "rentals", "renters", "renting", "renwick", "reoccur", "reopens", "reorder", "repaint", "repairs", "repaved", "repeals", "repeats", "repents", "repetto", "replace", "replant", "replays", "replete", "replica", "replied", "replies", "reponse", "reports", "reposed", "repress", "reprice", "reprint", "reprise", "reproof", "reprove", "reptile", "repulse", "reputed", "request", "requiem", "require", "rereads", "reroute", "resales", "rescind", "rescued", "rescuer", "rescues", "reseach", "resells", "resende", "resents", "reserve", "reshape", "reshoot", "resided", "resides", "residue", "resigns", "resists", "resized", "resnick", "resolve", "resorts", "resound", "respect", "respite", "respond", "restage", "restart", "restate", "restful", "resting", "restive", "restock", "restore", "restudy", "restyle", "results", "resumed", "resumes", "retails", "retains", "retaken", "retakes", "retards", "retells", "retests", "rethink", "retinal", "retinas", "retinol", "retinue", "retired", "retiree", "retires", "retitle", "retorts", "retouch", "retrace", "retract", "retrain", "retread", "retreat", "retrial", "retried", "retuned", "returns", "retyped", "reubens", "reunify", "reunion", "reunite", "reusing", "reuters", "revalue", "revamps", "reveals", "reveled", "revelry", "revenge", "revenue", "revered", "reveres", "reverie", "reverse", "reverts", "reviews", "reviled", "revised", "revises", "revisit", "revival", "revived", "revives", "revoked", "revokes", "revolts", "revolve", "revving", "rewards", "rewinds", "rewired", "reworks", "rewound", "rewrite", "rewrote", "rexford", "reynard", "reynaud", "reynold", "reynosa", "rezoned", "rhizome", "rhodium", "rhubarb", "rhyming", "rhythms", "ribbing", "ribbons", "ribcage", "ribeiro", "ricardo", "richard", "richest", "richman", "richter", "rickard", "rickert", "rickets", "rickety", "rickman", "ricotta", "riddell", "ridding", "riddled", "riddler", "riddles", "ridings", "riemann", "riffing", "riffles", "rifkind", "riflery", "rifling", "riggers", "rigging", "riggins", "righted", "righter", "rightly", "rigidly", "rigueur", "rimless", "rimming", "ringers", "ringgit", "ringing", "rinsing", "riordan", "rioters", "rioting", "riotous", "ripcord", "ripened", "ripoffs", "riposte", "rippers", "ripping", "rippled", "ripples", "riptide", "riserva", "risible", "riskier", "risking", "risotto", "ritalin", "ritchey", "ritchie", "rituals", "rivaled", "rivalry", "riveted", "riveter", "riviera", "riviere", "rivulet", "roaches", "roadbed", "roadmap", "roadway", "roamers", "roaming", "roanoke", "roaring", "roasted", "roaster", "robarts", "robbers", "robbery", "robbing", "robbins", "roberta", "roberto", "roberts", "robeson", "robin's", "robison", "robotic", "robusta", "rockers", "rockets", "rockett", "rockier", "rockies", "rocking", "rockman", "rockoff", "roddick", "rodding", "rodents", "rodgers", "rodolfo", "rodrigo", "roebuck", "rogelio", "roguish", "roiling", "rolando", "rollers", "rolling", "rollins", "rollout", "rolltop", "rolodex", "romaine", "romance", "romania", "romanov", "romping", "romulus", "rondeau", "roofers", "roofing", "rooftop", "rookery", "rookies", "roomful", "roomier", "roomies", "rooming", "roosted", "rooster", "rooters", "rooting", "rosacea", "rosales", "rosalia", "rosalie", "rosalyn", "rosanna", "rosanne", "rosario", "roseate", "rosebud", "rosella", "rosetta", "rosette", "rosetti", "rossini", "rosslyn", "rosters", "rostock", "rostrum", "roswell", "rotated", "rotates", "rotator", "rothman", "rotting", "rotunda", "roughed", "rougher", "roughly", "roulade", "rounded", "rounder", "roundly", "roundup", "rousers", "rousing", "rousted", "routers", "routine", "routing", "rowboat", "rowdies", "rowland", "roxanna", "roxanne", "roxbury", "royally", "royalty", "royster", "royston", "rozelle", "rubbers", "rubbery", "rubbing", "rubbish", "rubdown", "rubella", "rubicam", "rubicon", "rubrics", "ruckman", "rudders", "ruddock", "rudiger", "rudolph", "rudyard", "ruffian", "ruffled", "ruffles", "ruffner", "ruggles", "ruining", "ruinous", "rulings", "rumania", "rumbled", "rumbles", "rumford", "rummage", "rumored", "rumours", "rumpled", "runaway", "rundown", "runnels", "runners", "runneth", "running", "runoffs", "runtime", "runways", "rupiahs", "ruppert", "rupture", "rushdie", "rushers", "rushing", "rushton", "russell", "russian", "rusting", "rustled", "rustler", "rustles", "rutgers", "ruthven", "rutland", "rutting", "rwandan", "ryanair", "ryerson", "ryutaro", "saatchi", "sabbath", "sabella", "sabrina", "sachets", "sackett", "sacking", "saddens", "saddest", "saddled", "saddler", "saddles", "sadists", "sadness", "saenger", "safaris", "safeway", "safford", "saffron", "sagging", "saguaro", "saharan", "sailers", "sailing", "sailors", "sainted", "saintly", "saitama", "sakurai", "salable", "saladin", "salamis", "salamon", "salazar", "salerno", "salient", "salinas", "sallied", "sallies", "salmons", "salomon", "saloons", "salsify", "salters", "saltier", "saltine", "salting", "saltman", "saluted", "salutes", "salvage", "salzman", "samaras", "samaria", "sambuca", "samford", "samoans", "samovar", "samoyed", "sampled", "sampler", "samples", "sampson", "samsara", "samsung", "samuels", "samurai", "sanborn", "sanches", "sanchez", "sanctum", "sandals", "sandbag", "sandbar", "sandbox", "sandeep", "sandell", "sanders", "sanding", "sandler", "sandlot", "sandman", "sanford", "sangria", "sanibel", "santana", "santoro", "santosh", "sapiens", "sapient", "sapling", "saponin", "sappers", "sapphic", "sapping", "sapporo", "saracen", "sarasin", "saratov", "sarawak", "sarcasm", "sarcoma", "sardine", "sargent", "sarongs", "sartain", "sashimi", "satanic", "satchel", "satiate", "satiety", "satires", "satiric", "satisfy", "satoshi", "satsuma", "sattler", "saucers", "saucier", "saunter", "saurian", "sausage", "sauteed", "sauvage", "savaged", "savages", "savanna", "savants", "saville", "savimbi", "savings", "saviors", "saviour", "savored", "sawdust", "sawmill", "sawyers", "sayings", "scabbed", "scabies", "scalded", "scalers", "scaling", "scallop", "scalped", "scalpel", "scalper", "scammed", "scamper", "scandal", "scandia", "scanlon", "scanned", "scanner", "scapula", "scarabs", "scarcer", "scarfed", "scarier", "scarily", "scaring", "scarlet", "scarred", "scarves", "scatter", "scenery", "scented", "sceptre", "schacht", "schafer", "scheidt", "schemas", "schemed", "schemer", "schemes", "scherer", "scherzo", "scheuer", "schisms", "schlepp", "schlock", "schloss", "schmidt", "schmitt", "schmitz", "schmuck", "schnell", "scholar", "scholes", "scholtz", "schools", "schramm", "schrank", "schreck", "schrock", "schtick", "schuler", "schulte", "schultz", "schulze", "schumer", "schutte", "schwarz", "schwing", "sciatic", "science", "scissor", "scoffed", "scolded", "sconces", "scooped", "scooper", "scooted", "scooter", "scoping", "scorers", "scoring", "scorned", "scorpio", "scottie", "scotton", "scoured", "scourge", "scouted", "scowled", "scraped", "scraper", "scrapes", "scrapie", "scrappy", "scratch", "scrawls", "scrawny", "screams", "screech", "screeds", "screens", "screwed", "screwup", "scribal", "scribed", "scribes", "scripps", "scripts", "scriven", "scrolls", "scrooge", "scrotal", "scrotum", "scrubby", "scruffy", "scrunch", "scruple", "scruton", "scudder", "scuffed", "scuffle", "sculley", "sculpin", "sculpts", "scumbag", "scupper", "scuttle", "scythes", "seabird", "seabury", "seafood", "seagate", "seagram", "seagull", "seahawk", "sealand", "sealant", "sealers", "sealing", "seaming", "seances", "seaport", "searing", "searles", "seasick", "seaside", "seasons", "seaters", "seating", "seattle", "seawall", "seaward", "seaweed", "seawolf", "sebring", "seceded", "secedes", "seclude", "seconds", "secrecy", "secrest", "secrete", "secreto", "secrets", "section", "sectors", "secular", "secunda", "secured", "secures", "sedated", "seduced", "seducer", "seduces", "seedbed", "seeders", "seedier", "seeding", "seekers", "seeking", "seeling", "seeming", "seepage", "seeping", "seethed", "seethes", "segment", "segundo", "seibert", "seidman", "seifert", "seismic", "seizing", "seizure", "selects", "selfish", "selkirk", "sellars", "sellers", "selling", "selloff", "sellout", "seltzer", "selvage", "seminal", "seminar", "semipro", "semites", "semitic", "senates", "senator", "senders", "sending", "sendoff", "senegal", "seniors", "sennett", "sensing", "sensors", "sensory", "sensual", "sequels", "sequent", "sequins", "sequoia", "serbian", "serfdom", "sergius", "serials", "serious", "sermons", "serpent", "serrano", "serried", "servant", "servers", "service", "servile", "serving", "session", "setback", "settees", "setters", "setting", "settled", "settler", "settles", "seven's", "seventh", "seventy", "several", "severed", "severer", "severin", "severly", "sevilla", "seville", "sexiest", "sexists", "sexless", "sextant", "seybold", "seymour", "shaanxi", "shacked", "shackle", "shadier", "shading", "shadows", "shadowy", "shaffer", "shafted", "shafter", "shagged", "shaheed", "shaheen", "shaitan", "shakers", "shakeup", "shakier", "shakily", "shaking", "shalala", "shallot", "shallow", "shalwar", "shamans", "shaming", "shampoo", "shangri", "shanked", "shanker", "shanley", "shannon", "shapely", "shapers", "shaping", "shapira", "shapiro", "shareef", "sharers", "sharing", "sharkey", "sharman", "sharpen", "sharper", "sharpie", "sharply", "sharron", "shastri", "shatner", "shatter", "shavers", "shaving", "shawnee", "sheahan", "sheared", "shearer", "sheathe", "sheaths", "sheaves", "shebang", "sheehan", "sheered", "sheerly", "sheeted", "sheikhs", "shekels", "shelden", "sheldon", "shellac", "shelled", "sheller", "shelley", "shelter", "sheltie", "shelton", "shelved", "shelves", "shepard", "sherbet", "sheriff", "sherman", "sherpas", "sherrie", "sherrin", "sherrod", "shiatsu", "shields", "shifted", "shifter", "shigeru", "shiites", "shikoku", "shiller", "shimada", "shimbun", "shimizu", "shimmer", "shindig", "shiners", "shingle", "shinier", "shining", "shinned", "shipley", "shipman", "shipped", "shipper", "shirked", "shirley", "shively", "shivers", "shocked", "shocker", "shoebox", "shoeing", "shoguns", "shooing", "shooter", "shopped", "shopper", "shoppes", "shoring", "shorted", "shorten", "shorter", "shortie", "shortly", "shotgun", "shoulda", "shouted", "shouter", "shovels", "shoving", "showbiz", "showers", "showing", "showman", "showmen", "showoff", "shrieks", "shrikes", "shrilly", "shrimps", "shrines", "shrinks", "shrivel", "shriver", "shrouds", "shrubby", "shucked", "shudder", "shuffle", "shugart", "shulman", "shunned", "shunted", "shushed", "shutoff", "shutout", "shutter", "shuttle", "shylock", "shyness", "shyster", "siamese", "siberia", "sibling", "sichuan", "sickbed", "sickens", "sickest", "sicking", "sickles", "siddiqi", "sidearm", "sidebar", "sidecar", "sideman", "sidemen", "sidings", "sidwell", "siebert", "siemens", "sierras", "siestas", "sievert", "sieving", "sifting", "sighing", "sighted", "sightly", "sigmund", "signage", "signals", "signers", "signify", "signing", "signoff", "signore", "signups", "sikhism", "silence", "silents", "silesia", "silicon", "sillier", "silting", "silvana", "silvera", "silvers", "silvery", "simeone", "simians", "similar", "similes", "simmers", "simmons", "simpler", "simples", "simplex", "simpson", "sinatra", "sincere", "singers", "singing", "singled", "singles", "singlet", "sinkers", "sinking", "sinless", "sinners", "sinning", "sinuous", "sinuses", "siobhan", "siphons", "sipping", "sirloin", "sirocco", "sissies", "sistema", "sisters", "sistine", "sitcoms", "sitdown", "sitters", "sitting", "situate", "sixfold", "sixteen", "sixties", "sizable", "sizzled", "sizzler", "sizzles", "skadden", "skagway", "skanska", "skaters", "skating", "skeeter", "skelter", "skelton", "skeptic", "sketchy", "skewers", "skewing", "skiable", "skidded", "skilled", "skillet", "skimmed", "skimmer", "skimped", "skinned", "skinner", "skipped", "skipper", "skirted", "skitter", "skittle", "skousen", "skydive", "skyhook", "skylark", "skyline", "skyward", "skyways", "slacked", "slacken", "slacker", "slaking", "slammed", "slammer", "slander", "slanted", "slapped", "slapper", "slashed", "slasher", "slashes", "slaters", "slather", "slating", "slatkin", "slatted", "slavers", "slavery", "slaving", "slavish", "slayers", "slaying", "sledges", "sleeker", "sleekly", "sleeper", "sleeved", "sleeves", "sleighs", "sleight", "slender", "sleuths", "slicers", "slicing", "slicked", "slicker", "slickly", "sliders", "sliding", "slights", "slighty", "sliming", "slimmed", "slimmer", "slinger", "slipped", "slipper", "slipway", "slither", "slivers", "slobber", "slogans", "slogged", "sloping", "slopped", "sloshed", "slotted", "sloughs", "slovaks", "slovene", "slowest", "slowing", "slugged", "slugger", "sluices", "slumber", "slumped", "slurped", "slurred", "slutsky", "slyness", "smacked", "smacker", "smaller", "smalley", "smarted", "smarten", "smarter", "smartly", "smashed", "smasher", "smashes", "smeared", "smedley", "smelled", "smelted", "smelter", "smetana", "smidgen", "smileys", "smiling", "smirked", "smitten", "smocked", "smokers", "smokies", "smoking", "smolder", "smoothe", "smooths", "smother", "smudged", "smudges", "smuggle", "smurfit", "snagged", "snail's", "snaking", "snapped", "snapper", "snaring", "snarled", "sneaked", "sneaker", "sneered", "sneezed", "sneezes", "snelson", "snicker", "snidely", "sniffed", "sniffer", "sniffle", "snifter", "snigger", "snipers", "sniping", "snipped", "snippet", "snively", "snooker", "snooped", "snooper", "snoozed", "snoring", "snorkel", "snorted", "snowden", "snowdon", "snowing", "snowman", "snowmen", "snubbed", "snuffed", "snuffle", "snuggle", "snuggly", "soakers", "soaking", "soapbox", "soaping", "soaring", "sobbing", "sobered", "soberly", "sobotka", "socials", "societe", "society", "sockets", "sockeye", "socking", "sodding", "soffits", "sofitel", "softens", "softest", "softies", "soiling", "soirees", "sojourn", "sokolov", "sokolow", "solaris", "solberg", "soldano", "solders", "soldier", "soledad", "solheim", "solicit", "solider", "solidly", "soliman", "soliton", "soloing", "soloist", "soloman", "solomon", "soluble", "solvent", "solvers", "solving", "somalia", "somalis", "somatic", "someday", "somehow", "someone", "someway", "sommers", "sonatas", "sonesta", "sonnets", "sonntag", "sooners", "soonest", "soonish", "soothed", "soothes", "sophism", "sopping", "soprano", "sorcery", "sorghum", "sorrell", "sorrels", "sorrier", "sorrows", "sorters", "sorties", "sorting", "souffle", "soulful", "sounded", "sounder", "soundly", "sourced", "sources", "souring", "souther", "soviets", "soybean", "spacers", "spacial", "spacing", "spading", "spammed", "spandex", "spangle", "spaniel", "spanish", "spanked", "spanned", "spanner", "sparing", "sparked", "sparkle", "sparkly", "sparred", "sparrow", "sparser", "spartan", "spastic", "spatial", "spatter", "spatula", "spawned", "spaying", "speaker", "speared", "special", "species", "specify", "speckle", "specter", "spector", "spectra", "spectre", "speeded", "speeder", "speedup", "speight", "spelled", "speller", "spelman", "spencer", "spender", "spenser", "spewing", "spheres", "spicier", "spicing", "spiders", "spidery", "spiegel", "spiffed", "spigots", "spiking", "spilled", "spiller", "spinach", "spindle", "spindly", "spinner", "spinney", "spinoff", "spinout", "spirals", "spirits", "spittle", "spitzer", "splashy", "splayed", "spleens", "spliced", "splices", "splints", "splotch", "splurge", "spoiled", "spoiler", "spokane", "spoleto", "sponged", "sponges", "sponsor", "spoofed", "spooked", "spooled", "spooned", "spooner", "sported", "spotted", "spotter", "spousal", "spouses", "spouted", "sprague", "sprains", "sprawls", "sprayed", "sprayer", "spreads", "spriggs", "springs", "springy", "sprints", "sprites", "sprouts", "spruced", "spruces", "spurned", "spurred", "spurted", "sputnik", "sputter", "squalid", "squalls", "squally", "squalor", "squared", "squarer", "squares", "squashy", "squawks", "squeaks", "squeaky", "squeals", "squeeze", "squelch", "squints", "squinty", "squires", "squirms", "squirmy", "squirts", "squishy", "stabbed", "stabile", "stabled", "stabler", "stables", "stacked", "stacker", "stadion", "stadium", "stadler", "staffed", "staffer", "stagers", "stagger", "staging", "stained", "stainer", "staking", "stalked", "stalker", "stalled", "staller", "stamens", "stamina", "stammer", "stamped", "stamper", "stances", "standby", "stander", "standup", "stanger", "stanley", "stanton", "stanzas", "stapled", "stapler", "staples", "stapley", "starchy", "stardom", "staring", "starker", "starkey", "starkly", "starlet", "starlit", "starnes", "starred", "started", "starter", "startle", "startup", "starved", "starves", "stashed", "stashes", "state's", "stategy", "stately", "staters", "statics", "stating", "station", "statism", "statist", "statoil", "statues", "stature", "statute", "staunch", "staving", "stavros", "stayers", "staying", "stealer", "stealth", "steamed", "steamer", "stearic", "stearns", "steckel", "stedman", "steeled", "steeler", "steeped", "steepen", "steeper", "steeple", "steeply", "steered", "steerer", "stefani", "stefano", "steffan", "steffen", "steffie", "steiger", "steiner", "stellar", "steller", "stemmed", "stempel", "stencil", "stengel", "stennis", "stentor", "stepdad", "stephan", "stephen", "stepney", "stepped", "stepper", "steppes", "stepson", "steptoe", "stereos", "sterile", "sterner", "sternly", "sternum", "steroid", "stetson", "steuart", "steuben", "stevens", "steward", "stewart", "stewing", "stewpot", "stiched", "sticked", "stickel", "sticker", "stickle", "stiffed", "stiffen", "stiffer", "stiffly", "stifled", "stifles", "stigmas", "stilled", "stiller", "stilted", "stilton", "stimuli", "stinger", "stinker", "stinson", "stipend", "stirred", "stirrer", "stirrup", "stivers", "stocked", "stocker", "stoffel", "stogies", "stoical", "stokely", "stokers", "stoking", "stollen", "stoller", "stomach", "stomata", "stomped", "stomper", "stoning", "stooges", "stooped", "stopgap", "stoping", "stopped", "stopper", "storage", "storied", "stories", "storing", "stormed", "stormer", "stouter", "stoutly", "stowage", "stowing", "strader", "strafed", "strahan", "strains", "straits", "strands", "strange", "stratas", "stratum", "stratus", "strauss", "strayed", "streaks", "streaky", "streams", "streets", "strenth", "stretch", "strewed", "strider", "strides", "striker", "strikes", "strings", "stringy", "striped", "striper", "stripes", "strived", "striven", "strives", "strobes", "stroked", "stroker", "strokes", "strolls", "stromal", "stroock", "strudel", "stryker", "stuarts", "stubbed", "stubble", "stubbly", "stuckey", "studded", "student", "studied", "studies", "studios", "stuffed", "stuffer", "stumble", "stumped", "stumper", "stunned", "stunner", "stunted", "sturges", "sturgis", "stutter", "stygian", "styling", "stylish", "stylist", "stylize", "stymied", "stymies", "styrene", "suasion", "subbing", "subdued", "subdues", "subhead", "subject", "sublets", "sublime", "submits", "subnets", "subpart", "subplot", "subsets", "subside", "subsidy", "subsist", "subsoil", "subsume", "subtext", "subtler", "subtype", "subunit", "suburbs", "subvert", "subways", "subzero", "succeed", "success", "succour", "succumb", "suckers", "sucking", "suckled", "suckles", "sucrose", "suction", "sudbury", "suffers", "suffice", "suffolk", "suffuse", "sugared", "suggest", "suharto", "suicide", "suiting", "suitors", "sukhumi", "sulfate", "sulfide", "sulfite", "sulking", "sullied", "sulphur", "sultana", "sultans", "sumatra", "summary", "summers", "summery", "summing", "summits", "summons", "sumpter", "sunbeam", "sunbelt", "sunbird", "sunburn", "sundaes", "sundays", "sundeck", "sundial", "sundown", "sunfish", "sungard", "sunland", "sunless", "sunnier", "sunning", "sunrise", "sunroof", "sunroom", "sunsets", "sunspot", "sunward", "suppers", "support", "suppose", "supreme", "supremo", "suprise", "surface", "surfeit", "surfers", "surfing", "surgeon", "surgery", "surging", "surinam", "surmise", "surname", "surpass", "surplus", "surreal", "surveil", "surveys", "survive", "susan's", "susanna", "susanne", "suspect", "suspend", "sussman", "sustain", "suttles", "sutured", "sutures", "suzanna", "suzanne", "suzette", "svenson", "sverige", "swabbed", "swabian", "swagger", "swahili", "swallow", "swamped", "swanson", "swanton", "swapped", "swarmed", "swarthy", "swathed", "swathes", "swatted", "swatter", "swaying", "sweated", "sweater", "swedish", "sweeney", "sweeper", "sweeten", "sweeter", "sweetie", "sweetly", "swelled", "swelter", "swenson", "swerved", "swerves", "swifter", "swiftly", "swimmer", "swindle", "swindon", "swinger", "swingle", "swinney", "swinton", "swiping", "swirled", "swished", "swisher", "swishes", "switzer", "swivels", "swizzle", "swollen", "swooned", "swooped", "sybille", "symbols", "symonds", "symptom", "synapse", "synched", "synchro", "syncing", "syncope", "synergy", "synfuel", "synonym", "syrians", "syringe", "systems", "systran", "tabacco", "tabasco", "tabbies", "tabbing", "tabitha", "tableau", "tablets", "tabling", "tabloid", "tabular", "tachyon", "tacitly", "tacking", "tackled", "tackler", "tackles", "tactful", "tactics", "tactile", "tadashi", "tadpole", "taffeta", "tagalog", "taggart", "taggers", "tagging", "tagline", "tailing", "tailors", "tainted", "taiyuan", "takashi", "takeoff", "takeout", "takeshi", "takings", "talbots", "talbott", "talcott", "talents", "taliban", "talkers", "talkies", "talkin'", "talking", "tallest", "tallied", "tallies", "tallman", "tamales", "tamarin", "tammany", "tampere", "tampers", "tamping", "tampons", "tanager", "tandems", "tangent", "tangier", "tangled", "tangles", "tangram", "tankage", "tankard", "tankers", "tanking", "tanners", "tannery", "tanning", "tannins", "tantric", "tantrum", "taoists", "tapered", "tapings", "tapioca", "tappers", "tapping", "taproom", "taproot", "taranto", "tardily", "tardive", "targets", "tarheel", "tariffs", "tarnish", "tarpley", "tarrant", "tarried", "tarring", "tartans", "tartare", "tartars", "tasking", "tassels", "tasters", "tastier", "tasting", "tatiana", "tatters", "tattler", "tattoos", "taubman", "taunted", "taunton", "taurean", "taurine", "tavares", "taverna", "taverns", "taxable", "taxicab", "taxiing", "taxiway", "taylors", "tbilisi", "teabags", "teacher", "teaches", "teacups", "teamers", "teaming", "teapots", "tearful", "teargas", "tearing", "tearoom", "teasers", "teasing", "teatime", "techies", "technic", "teddies", "tedesco", "tedious", "teeming", "teenage", "teepees", "teeters", "teheran", "teicher", "telamon", "telecom", "telefon", "telekom", "telenet", "telesis", "telexes", "telford", "tellabs", "tellers", "telling", "telstra", "temblor", "tempera", "tempers", "tempest", "templar", "temples", "tempore", "tempted", "tempter", "tempura", "tenable", "tenancy", "tenants", "tenders", "tending", "tendons", "tenfold", "tennant", "tenneco", "tensely", "tensile", "tensing", "tension", "tenting", "tenuous", "tenured", "tenures", "teodoro", "tequila", "terence", "termine", "terming", "termini", "termite", "terpene", "terrace", "terrain", "terrell", "terrier", "terrify", "terrill", "terroir", "terrors", "tersely", "tertius", "tessier", "testbed", "testers", "testify", "testily", "testing", "tetanus", "tethers", "teutons", "textile", "textron", "textual", "texture", "thacker", "thanked", "that'll", "thawing", "theater", "theatre", "theming", "theorem", "therapy", "there'd", "there's", "thereby", "therein", "thereof", "thereon", "theresa", "therese", "thereto", "thermal", "thermos", "theroux", "theseus", "they'll", "they're", "they've", "thiamin", "thicken", "thicker", "thicket", "thickly", "thierry", "thieves", "thighed", "thigpen", "thimble", "thingie", "thinker", "thinned", "thinner", "thiokol", "thirdly", "thirsts", "thirsty", "thistle", "thither", "thomsen", "thomson", "thoreau", "thorium", "thorton", "thorugh", "thought", "threads", "threats", "three's", "thrifts", "thrifty", "thrills", "thrived", "thrives", "throats", "throaty", "thrones", "throngs", "through", "throwed", "thrower", "thrusts", "thruway", "thumbed", "thumped", "thumper", "thunder", "thurber", "thurman", "thwarts", "thymine", "thyroid", "thyself", "thyssen", "tianjin", "tibetan", "tiburon", "tickers", "tickets", "ticking", "tickled", "tickler", "tickles", "tidbits", "tidings", "tidwell", "tidying", "tiemann", "tiering", "tiernan", "tierney", "tiffany", "tighten", "tighter", "tightly", "tigress", "tijuana", "tilapia", "tilbury", "tillage", "tillers", "tillett", "tilling", "tillman", "tilting", "timbers", "timbres", "timeout", "timidly", "timings", "timmins", "timmons", "timothy", "timpani", "tindall", "tinfoil", "tingler", "tingles", "tiniest", "tinkers", "tinkled", "tinkler", "tinning", "tinsley", "tinting", "tintype", "tippers", "tippett", "tipping", "tipster", "tiptoed", "tiptoes", "tirades", "tiredly", "tisdale", "tissues", "titania", "titanic", "titbits", "tithing", "titling", "titmice", "titters", "titular", "tlingit", "toadies", "toasted", "toaster", "tobacco", "toccata", "today's", "toddler", "toehold", "toenail", "toffler", "toggled", "toggles", "togther", "toilets", "toiling", "tolbert", "tolkien", "tolling", "tollway", "tolstoy", "toluene", "tomcats", "tomkins", "tonally", "tongued", "tongues", "tonight", "tonnage", "tonsils", "tontine", "toolbar", "toolbox", "tooling", "toolkit", "toolset", "toothed", "tooting", "tootsie", "topanga", "topcoat", "topiary", "topical", "topknot", "topless", "topline", "topmost", "toppers", "topping", "toppled", "topples", "topsail", "topside", "topsoil", "topspin", "torched", "torches", "torment", "tornado", "toronto", "torpedo", "torques", "torrens", "torrent", "torsion", "torture", "toscano", "toshiba", "tossers", "tossing", "tostada", "totaled", "totally", "totemic", "totters", "totting", "tottori", "toucans", "touched", "toucher", "touches", "toughed", "toughen", "tougher", "toughie", "toupees", "touring", "tourism", "tourist", "tourney", "tousled", "touting", "towards", "towboat", "towered", "towline", "towners", "townies", "townson", "towpath", "toxemia", "toyland", "toyotas", "trabajo", "tracers", "tracery", "trachea", "tracing", "tracked", "tracker", "tractor", "traders", "trading", "traduce", "traffic", "tragedy", "trailed", "trailer", "trained", "trainee", "trainer", "trainor", "traipse", "traitor", "trammel", "tramped", "trample", "tramway", "trances", "tranche", "tranfer", "transco", "transit", "transom", "tranter", "trapani", "trapeze", "trapped", "trapper", "trashed", "trashes", "traumas", "travail", "travels", "travers", "trawled", "trawler", "traylor", "traynor", "treacle", "treaded", "treadle", "treason", "treated", "treater", "trebled", "trebles", "treetop", "trefoil", "trekked", "trekker", "trellis", "tremble", "tremens", "tremolo", "tremors", "trended", "trenton", "tressel", "tresses", "trestle", "trevino", "treviso", "triaged", "trianon", "tribals", "tribble", "tribeca", "tribune", "tribute", "triceps", "trichet", "tricked", "tricker", "trickle", "tricorn", "trident", "trieste", "trifled", "trifles", "trigger", "trilled", "trilogy", "trimble", "trimmed", "trimmer", "trinity", "trinket", "tripled", "triples", "triplet", "triplex", "tripods", "tripoli", "tripped", "tripper", "tripple", "trisomy", "tristan", "tristar", "tritium", "triumph", "trivial", "trodden", "trojans", "trolled", "trolley", "trooped", "trooper", "trophic", "tropics", "tropism", "trotman", "trotsky", "trotted", "trotter", "trouble", "troughs", "trounce", "trouper", "troupes", "trouser", "trovato", "trowels", "truancy", "truants", "trucked", "trucker", "trudeau", "trudged", "trudges", "trueman", "truffle", "truisms", "trumped", "trumpet", "trundle", "trunked", "trussed", "trusses", "trusted", "trustee", "tryouts", "tsarist", "tsukuba", "tsunami", "tsutomu", "tubular", "tuchman", "tuckers", "tucking", "tucuman", "tuesday", "tugboat", "tugging", "tuition", "tumbled", "tumbler", "tumbles", "tummies", "tumulus", "tunable", "tundras", "tuneful", "tunings", "tunisia", "tunnell", "tunnels", "turbans", "turbine", "turenne", "turismo", "turkeys", "turkish", "turkmen", "turmoil", "turners", "turning", "turnips", "turnkey", "turnoff", "turnout", "turrell", "turrets", "turtles", "tuscany", "tussled", "tussles", "tussock", "tuthill", "tutored", "tutting", "tuxedos", "twaddle", "tweaked", "tweedle", "tweeter", "tweezer", "twelfth", "twelves", "twiddle", "twigged", "twinges", "twining", "twinkie", "twinkle", "twinned", "twirled", "twirler", "twisted", "twister", "twitchy", "twofold", "twombly", "twosome", "tycoons", "tylenol", "tympani", "tyndall", "typeset", "typhoid", "typhoon", "typical", "typists", "tyranny", "tyrants", "ugandan", "ugliest", "ukelele", "ukraine", "ukulele", "ullmann", "ulyanov", "ulysses", "umberto", "umbrage", "umbrian", "umlauts", "umpires", "umpteen", "unaided", "unaired", "unarmed", "unasked", "unaware", "unbaked", "unblock", "unbound", "unbowed", "unboxed", "unbuilt", "unburnt", "uncanny", "unchain", "uncheck", "uncivil", "uncle's", "unclean", "unclear", "uncoded", "uncouth", "uncover", "unction", "uncured", "undated", "undergo", "underly", "undoing", "undrawn", "undress", "undying", "unearth", "uneaten", "unequal", "unfazed", "unfiled", "unfired", "unfixed", "unfolds", "unfound", "unfunny", "unfurls", "unfussy", "unglued", "ungodly", "unhappy", "unheard", "unhinge", "unhuman", "unicode", "unicorn", "unified", "unifier", "unifies", "uniform", "union's", "unitary", "uniting", "unkempt", "unknown", "unlatch", "unlearn", "unleash", "unlevel", "unlined", "unloads", "unlocks", "unloved", "unlucky", "unmanly", "unmasks", "unmixed", "unmoved", "unnamed", "unnerve", "unnoted", "unpacks", "unpaved", "unquiet", "unquote", "unrated", "unravel", "unready", "unrolls", "unsaved", "unscrew", "unsound", "unspent", "unstuck", "unsworn", "untamed", "untaxed", "untried", "untruth", "untwist", "untying", "untyped", "unusual", "unveils", "unwinds", "unwired", "unwound", "unwraps", "upbraid", "upchuck", "updated", "updates", "updraft", "upended", "upfield", "upfront", "upgrade", "upholds", "uplands", "uplifts", "uplinks", "uploads", "upright", "upriver", "upscale", "upshift", "upsides", "upsilon", "upslope", "upstage", "upstart", "upstate", "upsurge", "upswept", "upswing", "uptempo", "uptight", "uptrend", "upturns", "upwards", "uranium", "urchins", "urethra", "urgency", "urgings", "urinals", "urinary", "urinate", "urology", "uruguay", "useable", "useless", "ushered", "usually", "usurped", "usurper", "utensil", "uterine", "utilise", "utility", "utilize", "utopian", "utopias", "utrecht", "uttered", "utterly", "vacancy", "vacated", "vacates", "vaccine", "vaccuum", "vacuity", "vacuous", "vacuums", "vaginal", "vaginas", "vagrant", "vaguely", "vaguest", "valance", "valence", "valenti", "valeria", "valerie", "valiant", "validly", "vallejo", "valleys", "vallone", "valmont", "valorem", "valuers", "valuing", "valving", "vamping", "vampire", "vandals", "vandyke", "vanessa", "vanilla", "vantage", "vanuatu", "variant", "variety", "various", "varmint", "varnish", "varsity", "varying", "vasquez", "vassals", "vatican", "vaughan", "vaulted", "vaulter", "vaunted", "vazquez", "vecchio", "vectors", "veering", "vegetal", "veggies", "vehicle", "veiling", "veining", "velarde", "velasco", "velvets", "velvety", "venable", "venders", "vending", "vendors", "veneers", "venezia", "venison", "ventana", "venters", "venting", "ventral", "ventura", "venture", "venturi", "veranda", "verbena", "verbose", "verdant", "verdict", "verdugo", "verdure", "vergara", "verging", "veritas", "vermeer", "vermeil", "vermont", "vernier", "versace", "version", "vertigo", "vespers", "vessels", "vestige", "vesting", "veteran", "vetoing", "vetting", "viaduct", "vibrant", "vibrate", "vibrato", "vicente", "viceroy", "vicious", "vickers", "vickery", "vicomte", "victims", "victors", "victory", "vidalia", "vietnam", "viewers", "viewing", "vikings", "village", "villain", "villers", "vilnius", "vincent", "vinegar", "vintage", "vintner", "violate", "violent", "violets", "violins", "violist", "virgins", "virtual", "virtues", "viruses", "visages", "visayan", "viscera", "viscose", "viscous", "visible", "visibly", "visions", "visited", "visitor", "vista's", "visuals", "vitally", "vitamin", "vitesse", "vitrine", "vitriol", "vittles", "vivendi", "viviana", "vividly", "vizcaya", "vocally", "vocoder", "voelker", "voicing", "voiding", "volante", "volcano", "volcker", "volleys", "voltage", "voluble", "volumes", "vomited", "vouched", "voucher", "vouches", "voyaged", "voyager", "voyages", "voyeurs", "vuitton", "vulgate", "vulpine", "vulture", "wackier", "waddell", "wadding", "waddled", "waddles", "waffled", "waffles", "wafting", "wagered", "wagging", "wagoner", "wahhabi", "waikiki", "wailers", "wailing", "waisted", "waiters", "waiting", "waivers", "waiving", "wakeful", "wakeman", "wakened", "waldeck", "waldman", "waldner", "waldorf", "waldron", "walkers", "walking", "walkman", "walkout", "walkway", "wallaby", "wallace", "wallach", "wallets", "walleye", "walling", "wallman", "walloon", "wallops", "wallows", "walmart", "walnuts", "walpole", "walters", "waltham", "walther", "waltzed", "waltzer", "waltzes", "wanders", "wangled", "wannabe", "wanting", "warbled", "warbler", "warbles", "warburg", "wardell", "wardens", "warding", "warfare", "warhead", "warlike", "warlock", "warlord", "warmers", "warmest", "warming", "warmish", "warmups", "warners", "warning", "warnock", "warpath", "warping", "warrant", "warrens", "warrick", "warring", "warrior", "warshaw", "warship", "warthog", "wartime", "warwick", "wasatch", "washers", "washing", "washout", "washtub", "waspish", "wassail", "wastage", "wasters", "wasting", "wastrel", "watched", "watcher", "watches", "watered", "watkins", "wattage", "watters", "wattles", "wavelet", "wavered", "waverly", "waxwork", "waybill", "waylaid", "wayland", "wayside", "wayward", "weakens", "weakest", "weakley", "wealthy", "weaning", "weapons", "wearers", "wearied", "wearies", "wearily", "wearing", "weasels", "weather", "weavers", "weaving", "webbing", "website", "webster", "wedding", "wedging", "wedlock", "weeding", "weekday", "weekend", "weekley", "weenies", "weeping", "weevils", "weighed", "weights", "weighty", "weiland", "weinman", "weirder", "weirdly", "weirdos", "weirton", "weisman", "weisser", "welcher", "welches", "welcome", "welders", "welding", "welfare", "welland", "welling", "wellman", "wembley", "wenches", "wendell", "wending", "wentzel", "weren't", "wessels", "western", "westies", "westlaw", "westley", "westpac", "wetback", "wetland", "wetness", "wetsuit", "wettest", "wetting", "wexford", "whacked", "whacker", "whaddya", "whalers", "whaling", "whalley", "whampoa", "wharton", "wharves", "what'll", "what're", "whatcha", "whatnot", "wheaten", "wheaton", "wheedle", "wheeled", "wheeler", "wheelie", "wheezes", "whelmed", "where'd", "where's", "whereas", "whereat", "whereby", "wherein", "whereof", "whether", "whetted", "whicker", "whiffed", "whiling", "whimper", "whiners", "whining", "whipped", "whipper", "whippet", "whipple", "whipsaw", "whirled", "whisked", "whisker", "whiskey", "whisper", "whistle", "whitely", "whitest", "whither", "whities", "whiting", "whitish", "whitley", "whitlow", "whitman", "whitney", "whitten", "whittle", "whitton", "whizzed", "whizzes", "whoever", "wholely", "whooped", "whoopee", "whooper", "whopper", "whoring", "wichita", "wickets", "wickham", "wicking", "widened", "widener", "widgets", "widowed", "widower", "wiegand", "wieland", "wielded", "wielder", "wieners", "wiggins", "wiggled", "wiggler", "wiggles", "wilbert", "wilburn", "wilczek", "wildcat", "wildest", "wilding", "wildman", "wilford", "wilfred", "wilfrid", "wilhelm", "wilkens", "wilkins", "willard", "willets", "willett", "willful", "william", "willies", "willing", "willner", "willows", "willowy", "willson", "wilting", "winched", "winches", "wincing", "windbag", "winders", "windham", "windier", "winding", "windows", "windsor", "winfree", "winfrey", "wingate", "wingers", "winging", "wingman", "wingtip", "winking", "winkler", "winkles", "winless", "winners", "winnick", "winning", "winokur", "winship", "winslow", "winsome", "winston", "winters", "wintery", "winther", "wipeout", "wiretap", "wisdoms", "wiseguy", "wiseman", "wishers", "wishful", "wishing", "wistful", "witcher", "witches", "witheld", "withers", "withing", "withold", "without", "witless", "witness", "wittier", "wittily", "witting", "wittman", "wizards", "wizened", "wobbled", "wobbler", "wobbles", "wofford", "wolfing", "wolfman", "wolfram", "wolfson", "wolters", "woman's", "womanly", "wombats", "women's", "wonders", "wontons", "woodard", "woodcut", "woodies", "wooding", "woodley", "woodman", "woodrow", "woofers", "woolard", "woolens", "woolies", "woollen", "woolley", "woolman", "woolsey", "wooster", "wordier", "wording", "workday", "workers", "working", "workman", "workmen", "workout", "world's", "worldly", "worming", "worrall", "worrell", "worried", "worrier", "worries", "worsens", "worship", "worsted", "wortham", "worthen", "wouldnt", "wounded", "wouters", "wozniak", "wracked", "wraiths", "wrangle", "wrapped", "wrapper", "wreaked", "wreaths", "wrecked", "wrecker", "wrested", "wrestle", "wriggle", "wrights", "wrigley", "wringer", "wrinkle", "wrinkly", "wristed", "writers", "writeup", "writhed", "writhes", "writing", "written", "wroclaw", "wronged", "wrongly", "wrought", "wycliff", "wyndham", "wyoming", "xeroxed", "yangtze", "yankees", "yanking", "yapping", "yardage", "yardley", "yasushi", "yawning", "yearned", "yelling", "yellows", "yellowy", "yelping", "yeltsin", "yerevan", "yeshiva", "yevgeny", "yiddish", "yielded", "yitzhak", "yoghurt", "yogurts", "yolanda", "yomiuri", "yonkers", "yorkers", "yorkton", "yoshida", "younger", "youself", "youssef", "yowling", "yttrium", "yucatan", "yuppies", "zachary", "zagging", "zairian", "zaleski", "zambezi", "zambian", "zanders", "zapping", "zealand", "zealots", "zealous", "zeeland", "zeigler", "zeitung", "zelnick", "zenaida", "zenobia", "zeolite", "zephyrs", "zeroing", "zestful", "zhivago", "ziegler", "zigzags", "zillion", "zingers", "zinnias", "zionism", "zionist", "zippers", "zipping", "zoeller", "zombies", "zoology", "zooming"];

function deleteRow1() {
  xStart = 0;
  yStart = 0;

    // console.log(xStart)
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    // console.log(xStart)
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)

    letterPlace_Y += 70;

    mainEnter();
}

function deleteRow2() {
  xStart = 0;
  yStart = 70;

    // console.log(xStart)
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    // console.log(xStart)
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    letterPlace_Y += 70;

    mainEnter();
}

function deleteRow3() {
  xStart = 0;
  yStart = 140;

    // console.log(xStart)
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    // console.log(xStart)
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    letterPlace_Y += 70;
    mainEnter();
}

function deleteRow4() {
  xStart = 0;
  yStart = 210;

    // console.log(xStart)
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    // console.log(xStart)
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    letterPlace_Y += 70;

    mainEnter();
}

function deleteRow5() {
  xStart = 0;
  yStart = 280;

    // console.log(xStart)
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    // console.log(xStart)
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    letterPlace_Y += 70;

    mainEnter();
}


function getLettersInAnswer() {
  do {
    lettersInAnswerHelp2 = wordAnswer.slice(lettersInAnswerHelp - 1, lettersInAnswerHelp)
    lettersInAnswer.push(lettersInAnswerHelp2)
    lettersInAnswerHelp += 1;
  }
  while (lettersInAnswerHelp < 8)

}


getLettersInAnswer();


function squares() {

  do {

    xStart = 0;

    // console.log(xStart)
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    yStart += 70;

  }
  while (yStart < 350);
}

squares();


// console.log(letterPlace_X)

function x_place() {
  // console.log(letterNum)
  letterNum += 1;
  if (letterNum == 1) {
    letterPlace_X = 25;
    // console.log(letterPlace_X);

  }
  else if (letterNum == 2) {
    letterPlace_X = 85;
  }
  else if (letterNum == 3) {
    letterPlace_X = 145;
  }
  else if (letterNum == 4) {
    letterPlace_X = 205;
  }
  else if (letterNum == 5) {
    letterPlace_X = 265;
  }else if (letterNum == 6) {
    letterPlace_X = 325;
  }else if (letterNum == 7) {
    letterPlace_X = 385;
  }
  // console.log(letterPlace_X);
  lettersTyped += 1;
}

function x_placeBackspace() {
  if (letterNum == 1) {
    letterPlace_X = 25;
    // console.log(letterPlace_X);

  }
  else if (letterNum == 2) {
    letterPlace_X = 85;
  }
  else if (letterNum == 3) {
    letterPlace_X = 145;
  }
  else if (letterNum == 4) {
    letterPlace_X = 205;
  }
  else if (letterNum == 5) {
    letterPlace_X = 265;
  }else if (letterNum == 6) {
    letterPlace_X = 325;
  }else if (letterNum == 7) {
    letterPlace_X = 385;
  }
  // console.log(letterPlace_X);
}

function findDate() {
  do{
      dateNumbers.push(date.charAt(dateFinder))
      dateFinder += 1;
  }
  while (dateFinder < 11)
}

function mainEnter() {
  mainEnterHelp = "";
  mainEnterHelp2 = 0;
  mainEnterHelp3 = 1;
  stringTypedHelp = 0;
  // console.log("mainEnter")
  stringTyped = lettersPutIn.join("");
  if (allWords.includes(stringTyped)) {

    do {
        // console.log("mainEnter")
        mainEnterHelp = lettersPutIn[mainEnterHelp2];
      if (lettersInAnswer.includes(mainEnterHelp)){
        if (lettersPutIn[mainEnterHelp2] == lettersInAnswer[mainEnterHelp2]){
          colorsInRow.push("green")
        } else {
          colorsInRow.push("yellow")
        }
      }else {
        colorsInRow.push("red")
      }
      mainEnterHelp2 += 1;
    }
    while (mainEnterHelp2 < 7)
    coloredRewrite();
  } else {
    error();
    letterNum = 1;
    lettersTyped = 0;
    letterPlace_X = 25;
    lettersPutIn = [];
    console.log("---->>> mt");
    colorsInRow = [];
    letterPlace_Y -= 70;
  }
}

function coloredRewrite() {
  tries += 1;
  coloredRewriteHelp2 = 0;
  coloredRewriteHelp = "";
  coloredRewriteHelp3 = "";
  coloredRewriteHelp4 = "";
  letterPlace_XSave = 25;
  do {
    coloredRewriteHelp = colorsInRow[coloredRewriteHelp2];
    coloredRewriteHelp3 = lettersPutIn[coloredRewriteHelp2];
    coloredRewriteHelp4 = coloredRewriteHelp3.toUpperCase();
    c.font = "30px Arial";
    c.fillStyle = coloredRewriteHelp;
    c.textAlign = "center";
    c.fillText(coloredRewriteHelp4, letterPlace_XSave, letterPlace_YSave);
    coloredRewriteHelp2 += 1;
    letterPlace_XSave += 60;
    colorsInAll.push(coloredRewriteHelp)
  }
  while(coloredRewriteHelp2 < 7);

  gameFinished();
}

function popUpf() {
  var popup = document.getElementById("myPopup");
  popup.classList.toggle("show");
}

function nextRow() {
  letterNum = 1;
  lettersTyped = 0;
  letterPlace_X = 25;
  lettersPutIn = [];
  console.log("---->>> mt nextrow");
  colorsInRow = [];
  // console.log("next_row");
}

function gameFinished() {
  if(colorsInRow.includes("red")) {
    nextRow();
    if (tries == 5) {
      youLost();
    }
  }else if (colorsInRow.includes("yellow")) {
    nextRow();
    if (tries == 5) {
      youLost();
    }
  } else {
    clearCanvas();
  }
  
}

function youWin() {
  playedToday = date2;
  streak += 1;
  gamesPlayed += 1;
  c.fillStyle = "gainsboro";
  c.fillRect(25, 0, 250, 300)
  c.font = "35px Arial";
  c.fillStyle = "green";
  c.textAlign = "center";
  c.fillText("You Win", 150, 35);
  c.font = "15px Arial";
  c.fillStyle = "black";
  c.textAlign = "center";
  c.fillText("Number of tries: " + tries, 100, 75);
  c.fillText("Scroll All The Way Down To Share", 150, 150);
  c.fillText("Streak: " + streak, 75, 100);
  c.fillText("Games Played: " + gamesPlayed, 100, 125);
  setCookie("hardstreak", streak, 365);
  setCookie("hardgamesplayed", gamesPlayed, 365);
  setCookie("hardplayedtoday", playedToday, 365);
}

function youLost() {
  c.fillStyle = "gainsboro";
  c.fillRect(0, 0, 400, 400)
  c.font = "35px Arial";
  c.fillStyle = "red";
  c.textAlign = "center";
  c.fillText("You Lost", 150, 35);
  c.font = "15px Arial";
  c.fillStyle = "black";
  c.textAlign = "center";
  c.fillText("Number of tries: " + tries, 100, 75);
  c.fillText("Scroll All The Way Down To Share", 150, 150);
  playedToday = date2;
  streak = 0;
  gamesPlayed += 1;
  setCookie("hardstreak", streak, 365);
  setCookie("hardgamesplayed", gamesPlayed, 365);
  setCookie("hardplayedtoday", playedToday, 365);
}

function clearCanvas() {
  window.setTimeout(nothing, 2500)
  c.fillStyle = "white";
  c.fillRect(0, 0, 500, 500)
  youWin();
}

function share() {
  colorEmojis();
  // console.log('--->>> share blah');
}

function addStr(str, index, stringToAdd){
  return str.substring(0, index) + stringToAdd + str.substring(index, str.length);
}

function colorEmojis() {
  colorEmojisHelp = 0;
  resultString = "";
  do {
    var nextChar = "";
    if (colorsInAll[colorEmojisHelp] == "green"){
      nextChar = "🟩";
    } else if (colorsInAll[colorEmojisHelp] == "yellow") {
      nextChar = "🟨";
    } else{
      nextChar = "🟥";
    }
    if (colorEmojisHelp % 7 == 0) {
      resultString += "\n";
    } else {
      resultString += " ";
    }
    resultString += nextChar;
    colorEmojisHelp += 1;
  } while (colorEmojisHelp < (tries * 7))
  colorEmojisHelp = 0;
  navigator.clipboard.writeText("I won on hard mode: \n" + resultString + "\n https://iamibrahim510.repl.co/hard.html \n Tries: " + tries + "/5" + "\n Wordier")
  alert("Copied to Clipboard");
}

function alreadyPlayed() {
  c.fillStyle = "gainsboro";
    c.fillRect(0, 0, 400, 400)
    c.font = "25px Quicksand";
    c.fillStyle = "green";
    c.textAlign = "center";
    c.fillText("You've already played today", 200, 35);
    c.font = "20px Quicksand";
    c.fillStyle = "black";
    c.textAlign = "center";
    // localStorage.setItem("try", tries); 
    c.fillText("Everyday there is a new word,", 150, 250);
    c.fillText("check in daily", 150, 280);
}


// keyboard:

function q() {
  if (lettersTyped < 7){  
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("Q", letterPlace_X, letterPlace_Y);
    x_place();
    lettersPutIn.push("q")
    // console.log("534")
  }  
}

function w() {
  if (lettersTyped < 7){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("W", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("w")
  }
}

function e() {
  if (lettersTyped < 7){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("E", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("e")
  }
}

function r() {
  if (lettersTyped < 7){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("R", letterPlace_X, letterPlace_Y);
    x_place();  
   lettersPutIn.push("r")
  }
}

function t() {
  if (lettersTyped < 7){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("T", letterPlace_X, letterPlace_Y);
    // console.log("t")
    x_place(); 
    lettersPutIn.push("t")
  }
}

function y() {
  if (lettersTyped < 7){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("Y", letterPlace_X, letterPlace_Y);
    x_place();  
    lettersPutIn.push("y")
  }
}

function u() {
  if (lettersTyped < 7){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("U", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("u")
  }
}

function i() {
  if (lettersTyped < 7){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("I", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("i")
  }
}

function o() {
  if (lettersTyped < 7){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("O", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("o")
  }
}

function p() {
  if (lettersTyped < 7){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("P", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("p")
  }
}

function a() {
  if (lettersTyped < 7){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("A", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("a");
  }
}

function s() {
  if (lettersTyped < 7){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("S", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("s")
  }
}

function d() {
  if (lettersTyped < 7){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("D", letterPlace_X, letterPlace_Y);
      x_place();   
    lettersPutIn.push("d")
  }
}

function f() {
  if (lettersTyped < 7){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("F", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("f")
  }
}

function g() {
  if (lettersTyped < 7){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("G", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("g")
  }
}

function h() {
  if (lettersTyped < 7){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("H", letterPlace_X, letterPlace_Y);
      x_place();   
      lettersPutIn.push("h")
  }
}


function j() {
  if (lettersTyped < 7){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("J", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("j")
  }
}


function k() {
  if (lettersTyped < 7){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("K", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("k")
  }
}


function l() {
  if (lettersTyped < 7){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("L", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("l")
  }
}

function backspace() {
  console.log (lettersTyped)
  if (lettersTyped >= 1) {
    backspaceX = ((letterNum * 60) - 120)
    c.fillStyle = "gainsboro";
    c.fillRect(backspaceX, letterPlace_Y - 35, 50, 50);
    lettersPutIn.pop();
    letterNum = letterNum - 1;
    lettersTyped -= 1;
    x_placeBackspace();
  }
}


function z() {
  if (lettersTyped < 7){     
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("Z", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("z")
  }
}


function x() {
  if (lettersTyped < 7){     
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("X", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("x")
  }
}


function cT() {
  if (lettersTyped < 7){     
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("C", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("c")
  }
}


function v() {
  if (lettersTyped < 7){     
    c.globalCompositeOperation = 'source-over';  
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("V", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("v")
  }
}


function b() {
  if (lettersTyped < 7){     
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("B", letterPlace_X, letterPlace_Y);
      x_place();   
      lettersPutIn.push("b")
  }
}


function n() {
  if (lettersTyped < 7){     
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("N", letterPlace_X, letterPlace_Y);
      x_place();   
      lettersPutIn.push("n")
  }
}


function m() {
  if (lettersTyped < 7){     
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("M", letterPlace_X, letterPlace_Y);
      x_place();   
      lettersPutIn.push("m")
  }
}

function enter() {
  if (lettersTyped != 7) {
    error();
  } else {
      letterPlace_XSave = letterPlace_X;
      letterPlace_YSave = letterPlace_Y;
      if (letterPlace_Y == 35){
          deleteRow1();
      } else if (letterPlace_Y == 105) {
          deleteRow2();
      } else if (letterPlace_Y == 175) {
          deleteRow3();
      } else if (letterPlace_Y == 245) {
          deleteRow4();
      } else if (letterPlace_Y == 315) {
          deleteRow5();
        }
  }
}

function error() {   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = 'red';
    c.textAlign = "center";
    c.fillText("Error", 450, 175);  
    window.setTimeout(eraseError, 2500);
}

function eraseError() {
    c.fillStyle = "white";
    c.fillRect(418, 100, 150, 150)
}

function nothing() {
  
}



// cookie Junk:


function setCookie(name, value, days) {
    var expires = "";
    if (days) {
        var date5 = new Date();
        date5.setTime(date5.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date5.toUTCString();
    }
    document.cookie = name + "=" + (value || "") + expires + "; path=/";
}

function getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' '){ c = c.substring(1, c.length);}
        if (c.indexOf(nameEQ) == 0) {return c.substring(nameEQ.length, c.length);}
    }
    return "";
}

function checkCookie() {
  let checkCode = getCookie("hardstreak");
  let checkCode2 = getCookie("hardgamesPlayed");
  let checkCode3 = getCookie("hardplayedtoday");
  if (getCookie("hardstreak") === "") {
      console.log(checkCode)
      // alert("new")
      streak = 0;
      // setCookie("streak", "0", 365);
  } else {
    // reading the cookie
    streak = parseInt(checkCode);
  }
  if (getCookie("hardgamesplayed") === "") {
    
    console.log(checkCode2)
    // alert("new")
    gamesPlayed = 0;
    window.setTimeout(popUpf, 1000)
    // setCookie("gamesplayed", 0, 365);
  } else {
    // reading the cookie
    checkCode2 = getCookie("hardgamesplayed");
    console.log(checkCode2);
    gamesPlayed = parseInt(checkCode2);
  }
  if (getCookie("hardplayedtoday") === "") {
    
    console.log(checkCode3)
    // alert("new")
    gamesPlayed = 0;
    // setCookie("playedtoday", "0", 365);
  } else {
    // reading the cookie
    checkCode3 = getCookie("hardplayedtoday");
    console.log(checkCode3)
    playedToday = parseInt(checkCode3);
  }
  if (parseInt(getCookie("hardplayedtoday")) == date2) {
    alreadyPlayed();
    lettersTyped = 7;
  }
}

checkCookie();
// var code = getCookie("code");



