var canvas = document.getElementById("canvas")

var c = canvas.getContext("2d");
var img = new Image();

canvas.width = 400;
canvas.height = 350;

var xStart = 0;
var yStart = 0;

var letterPlace_X = 25;
var letterPlace_Y = 35;
var letterPlace_XSave = 25;
var letterPlace_YSave = 35;
var letterNumber = 1;
var letterNum = 1;

var letterColor = "black";

var backspaceX = 0;

var dateFinder = 1;
var dateFinder2 = 0;
const dateNumbers = []
let date = new Date();
date = String(date)
let date2 = date.slice(8, 11);

const xs = [25, 75, 125, 175, 225];
let x1 = 25;
let x2 = 75;
let x3 = 125;
let x4 = 175;
let x5 = 225;

const words = ["anger", "jokes", "block", "beach", "birth", "drink", "dream", "hotel", "house", "image", "index", "input", "judge", "knife", "lunch", "major", "march", "music", "night", "noise", "owner", "panel", "prize", "radio", "range", "share", "scale", "scary", "table", "their", "uncle"]

var wordAnswer = String(words.slice(date2 - 1, date2))

let lettersPutIn = []

let lettersInAnswer = []
var lettersInAnswerHelp = 1;
let lettersInAnswerHelp2 = "";

var lettersTyped = 0;

var mainEnterHelp = "";
var mainEnterHelp2 = 0;
var mainEnterHelp3 = 1;
var coloredRewriteHelp = "";
var coloredRewriteHelp2 = 0;
var coloredRewriteHelp3 = "";
let coloredRewriteHelp4 = "";

let colorsInRow = []
let colorsInAll = [];

var tries = 0;

var colorEmojisHelp = 0;
let coloredEmojis = []
var colorEmojisHelp2 = "";

var stringTyped = "";
var stringTypedHelp = 0;


var aButtonColor = "white";
var bButtonColor = "white";
var cButtonColor = "white";
var dButtonColor = "white";
var eButtonColor = "white";
var fButtonColor = "white";
var gButtonColor = "white";
var hButtonColor = "white";
var iButtonColor = "white";
var jButtonColor = "white";
var kButtonColor = "white";
var lButtonColor = "white";
var mButtonColor = "white";
var nButtonColor = "white";
var oButtonColor = "white";
var pButtonColor = "white";
var qButtonColor = "white";
var rButtonColor = "white";
var sButtonColor = "white";
var tButtonColor = "white";
var uButtonColor = "white";
var vButtonColor = "white";
var wButtonColor = "white";
var xButtonColor = "white";
var yButtonColor = "white";
var zButtonColor = "white";

var streak = 0;
var gamesPlayed = 0;
var playedToday = date2;

var sendCode = 0;

var streakRead = 0;
var gamesPlayedRead = 0;
var playedTodayRead = 0;

var rowDeleting = 0;

let allWords = ["about", "above", "abuse", "actor", "adapt", "admit", "adult", "again", "agent", "agree", "ahead", "aisle", "alarm", "album", "alert", "alien", "alley", "allow", "alone", "alpha", "alter", "among", "anger", "angle", "angry", "ankle", "apart", "apple", "april", "arena", "argue", "armed", "armor", "arrow", "asset", "audit", "avoid", "awake", "aware", "awful", "bacon", "badge", "basic", "beach", "begin", "below", "bench", "birth", "black", "blade", "blame", "blast", "bleak", "bless", "blind", "blood", "blush", "board", "bonus", "boost", "brain", "brand", "brass", "brave", "bread", "brick", "brief", "bring", "brisk", "broom", "brown", "brush", "buddy", "build", "burst", "buyer", "cabin", "cable", "canal", "candy", "canoe", "cargo", "carry", "catch", "cause", "chair", "chalk", "chaos", "chase", "cheap", "check", "chest", "chief", "child", "chunk", "churn", "cigar", "civil", "claim", "clean", "clerk", "click", "cliff", "climb", "clock", "close", "cloth", "cloud", "clown", "clump", "coach", "coast", "color", "comic", "coral", "couch", "cover", "crack", "craft", "crane", "crash", "crawl", "crazy", "cream", "creek", "crime", "crisp", "cross", "crowd", "cruel", "crush", "curve", "cycle", "dance", "delay", "depth", "diary", "dizzy", "donor", "draft", "drama", "dream", "dress", "drift", "drill", "drink", "drive", "dutch", "dwarf", "eager", "eagle", "early", "earth", "eight", "elbow", "elder", "elite", "empty", "enact", "enemy", "enjoy", "enter", "entry", "equal", "equip", "erase", "erode", "error", "erupt", "essay", "evoke", "exact", "exile", "exist", "extra", "faint", "faith", "false", "fancy", "fatal", "fault", "fence", "fetch", "fever", "fiber", "field", "final", "first", "flame", "flash", "float", "flock", "floor", "fluid", "flush", "focus", "force", "forum", "found", "frame", "fresh", "front", "frost", "frown", "fruit", "funny", "gauge", "genre", "ghost", "giant", "glare", "glass", "glide", "globe", "gloom", "glory", "glove", "goose", "grace", "grain", "grant", "grape", "grass", "great", "green", "grief", "group", "grunt", "guard", "guess", "guide", "guilt", "habit", "happy", "harsh", "heart", "heavy", "hello", "hobby", "honey", "horse", "hotel", "hover", "human", "humor", "hurry", "image", "index", "inner", "input", "issue", "ivory", "jeans", "jelly", "jewel", "judge", "juice", "knife", "knock", "label", "labor", "large", "later", "latin", "laugh", "layer", "learn", "leave", "legal", "lemon", "level", "light", "limit", "local", "logic", "loyal", "lucky", "lunar", "lunch", "magic", "major", "mango", "maple", "march", "match", "medal", "media", "mercy", "merge", "merit", "merry", "metal", "mimic", "minor", "mixed", "model", "month", "moral", "motor", "mouse", "movie", "music", "naive", "nasty", "nerve", "never", "night", "noble", "noise", "north", "novel", "nurse", "occur", "ocean", "offer", "often", "olive", "onion", "opera", "orbit", "order", "organ", "other", "outer", "owner", "ozone", "panda", "panel", "panic", "paper", "party", "about", "above", "abuse", "actor", "adapt", "admit", "adult", "again", "agent", "agree", "ahead", "aisle", "alarm", "album", "alert", "alien", "alley", "allow", "alone", "alpha", "alter", "among", "anger", "angle", "angry", "ankle", "apart", "apple", "april", "arena", "argue", "armed", "armor", "arrow", "asset", "audit", "avoid", "awake", "aware", "awful", "bacon", "badge", "basic", "beach", "begin", "below", "bench", "birth", "black", "blade", "blame", "blast", "bleak", "bless", "blind", "blood", "blush", "board", "bonus", "boost", "brain", "brand", "brass", "brave", "bread", "brick", "brief", "bring", "brisk", "broom", "brown", "brush", "buddy", "build", "burst", "buyer", "cabin", "cable", "canal", "candy", "canoe", "cargo", "carry", "catch", "cause", "chair", "chalk", "chaos", "chase", "cheap", "check", "chest", "chief", "child", "chunk", "churn", "cigar", "civil", "claim", "clean", "clerk", "click", "cliff", "climb", "clock", "close", "cloth", "cloud", "clown", "clump", "coach", "coast", "color", "comic", "coral", "couch", "cover", "crack", "craft", "crane", "crash", "crawl", "crazy", "cream", "creek", "crime", "crisp", "cross", "crowd", "cruel", "crush", "curve", "cycle", "dance", "delay", "depth", "diary", "dizzy", "donor", "draft", "drama", "dream", "dress", "drift", "drill", "drink", "drive", "dutch", "dwarf", "eager", "eagle", "early", "earth", "eight", "elbow", "elder", "elite", "empty", "enact", "enemy", "enjoy", "enter", "entry", "equal", "equip", "about", "above", "abuse", "actor", "adapt", "admit", "adult", "again", "agent", "agree", "ahead", "aisle", "alarm", "album", "alert", "alien", "alley", "allow", "alone", "alpha", "alter", "among", "anger", "angle", "angry", "ankle", "apart", "apple", "april", "arena", "argue", "armed", "armor", "arrow", "asset", "audit", "avoid", "awake", "aware", "awful", "bacon", "badge", "basic", "beach", "begin", "below", "bench", "birth", "black", "blade", "blame", "blast", "bleak", "bless", "blind", "blood", "blush", "board", "bonus", "boost", "brain", "brand", "brass", "brave", "bread", "brick", "brief", "bring", "brisk", "broom", "brown", "brush", "buddy", "build", "burst", "buyer", "cabin", "cable", "canal", "candy", "canoe", "cargo", "carry", "catch", "cause", "chair", "chalk", "chaos", "chase", "cheap", "check", "chest", "chief", "child", "chunk", "churn", "cigar", "civil", "claim", "clean", "clerk", "click", "cliff", "climb", "clock", "close", "cloth", "cloud", "clown", "clump", "coach", "coast", "color", "comic", "coral", "couch", "cover", "crack", "craft", "crane", "crash", "crawl", "crazy", "cream", "creek", "crime", "crisp", "cross", "crowd", "cruel", "crush", "curve", "cycle", "dance", "delay", "depth", "diary", "dizzy", "donor", "draft", "drama", "dream", "dress", "drift", "drill", "drink", "drive", "dutch", "dwarf", "eager", "eagle", "early", "earth", "eight", "elbow", "elder", "elite", "empty", "enact", "enemy", "enjoy", "enter", "entry", "equal", "equip", "about", "above", "abuse", "actor", "adapt", "admit", "adult", "again", "agent", "agree", "ahead", "aisle", "alarm", "album", "alert", "alien", "alley", "allow", "alone", "alpha", "alter", "among", "anger", "angle", "angry", "ankle", "apart", "apple", "april", "arena", "argue", "armed", "armor", "arrow", "asset", "audit", "avoid", "awake", "aware", "awful", "bacon", "badge", "basic", "beach", "begin", "below", "bench", "birth", "black", "blade", "blame", "blast", "bleak", "bless", "blind", "blood", "blush", "board", "bonus", "boost", "brain", "brand", "brass", "brave", "bread", "brick", "brief", "bring", "brisk", "broom", "brown", "brush", "buddy", "build", "burst", "buyer", "cabin", "cable", "canal", "candy", "canoe", "cargo", "carry", "catch", "cause", "chair", "chalk", "chaos", "chase", "cheap", "check", "chest", "chief", "child", "chunk", "churn", "cigar", "civil", "claim", "clean", "clerk", "click", "cliff", "climb", "clock", "close", "cloth", "cloud", "clown", "clump", "coach", "coast", "color", "comic", "coral", "couch", "cover", "crack", "craft", "crane", "crash", "crawl", "crazy", "cream", "creek", "crime", "crisp", "cross", "crowd", "cruel", "crush", "curve", "cycle", "dance", "delay", "depth", "diary", "dizzy", "donor", "draft", "drama", "dream", "dress", "drift", "drill", "drink", "drive", "dutch", "dwarf", "eager", "eagle", "early", "earth", "eight", "elbow", "elder", "elite", "empty", "enact", "enemy", "enjoy", "enter", "entry", "equal", "equip", "about", "above", "abuse", "actor", "adapt", "admit", "adult", "again", "agent", "agree", "ahead", "aisle", "alarm", "album", "alert", "alien", "alley", "allow", "alone", "alpha", "alter", "among", "anger", "angle", "angry", "ankle", "apart", "apple", "april", "arena", "argue", "armed", "armor", "arrow", "asset", "audit", "avoid", "awake", "aware", "awful", "bacon", "badge", "basic", "beach", "begin", "below", "bench", "birth", "black", "blade", "blame", "blast", "bleak", "bless", "blind", "blood", "blush", "board", "bonus", "boost", "brain", "brand", "brass", "brave", "bread", "brick", "brief", "bring", "brisk", "broom", "brown", "brush", "buddy", "build", "burst", "buyer", "cabin", "cable", "canal", "candy", "canoe", "cargo", "carry", "catch", "cause", "chair", "chalk", "chaos", "chase", "cheap", "check", "chest", "chief", "child", "chunk", "churn", "cigar", "civil", "claim", "clean", "clerk", "click", "cliff", "climb", "clock", "close", "cloth", "cloud", "clown", "clump", "coach", "coast", "color", "comic", "coral", "couch", "cover", "crack", "craft", "crane", "crash", "crawl", "crazy", "cream", "aaker", "aargh", "aaron", "aback", "abadi", "abase", "abate", "abbas", "abbey", "abbie", "abbot", "abdel", "abdul", "abeam", "abela", "abele", "abell", "abend", "abets", "abhor", "abide", "abled", "abler", "ables", "abner", "abode", "abort", "about", "above", "abram", "abreu", "abril", "abuja", "abuse", "abuts", "abuzz", "abyss", "accel", "accor", "accra", "ached", "aches", "acids", "acing", "acker", "acorn", "acres", "acrid", "acted", "actin", "acton", "actor", "actus", "acura", "acute", "adage", "adair", "adams", "adapt", "added", "adder", "addie", "addis", "addle", "adela", "adele", "adept", "adieu", "adige", "adios", "adlai", "adler", "adman", "admin", "admit", "adnan", "adobe", "adobo", "adolf", "adopt", "adore", "adorn", "adult", "aegis", "aegon", "aerie", "aeron", "aesop", "aetna", "affix", "afire", "afoot", "afore", "afoul", "afros", "after", "again", "agama", "agape", "agata", "agate", "agave", "agent", "agers", "agger", "aggie", "aggro", "agile", "aging", "agios", "aglow", "agnes", "agnew", "agony", "agood", "agora", "agree", "aguas", "ahead", "ahern", "ahmad", "ahmed", "ahold", "ahuja", "aichi", "aidan", "aided", "aider", "aides", "aiken", "ailed", "aimed", "aimee", "ain't", "aioli", "aired", "aires", "aisle", "ajami", "akbar", "akers", "akiba", "aking", "akins", "akira", "akita", "akron", "alain", "alamo", "alana", "aland", "alane", "alarm", "alban", "albee", "albie", "albin", "album", "albus", "alcan", "alcoa", "alcon", "alden", "alder", "aldis", "aldus", "aleck", "alene", "aleph", "alert", "aleut", "alexa", "alfie", "algae", "algal", "alger", "algol", "alias", "alibi", "alice", "alien", "align", "alike", "alina", "aline", "aliso", "alive", "alkyl", "allah", "allan", "allay", "allee", "allen", "aller", "alles", "alley", "allez", "allie", "allis", "allot", "allow", "alloy", "allyl", "allyn", "alman", "almon", "aloes", "aloft", "aloha", "alone", "along", "aloof", "aloud", "alpen", "alper", "alpha", "alroy", "alsop", "altar", "alter", "altho", "alton", "altos", "altus", "alums", "alves", "alvey", "alvin", "alvis", "alway", "alwin", "alwyn", "amana", "amani", "amara", "amaro", "amass", "amati", "amaya", "amaze", "amber", "ambit", "amble", "ambon", "ameen", "amend", "ament", "amgen", "amici", "amies", "amiga", "amigo", "amine", "amino", "amiri", "amish", "amiss", "amity", "amman", "ammar", "ammon", "amnio", "amoco", "among", "amory", "amour", "ample", "amply", "amuck", "amuse", "amway", "anand", "anaya", "ancon", "andel", "andes", "andor", "andre", "andry", "angel", "anger", "angie", "angle", "anglo", "angry", "angst", "angus", "anima", "anion", "anise", "anita", "anker", "ankle", "annal", "annan", "annas", "annex", "annie", "annoy", "annul", "annum", "anode", "anova", "ansel", "anson", "antal", "anted", "antes", "antic", "antis", "anton", "antsy", "anvil", "anwar", "anway", "anzac", "aorta", "apace", "apart", "aphid", "aphis", "aping", "apnea", "appal", "appel", "apple", "apply", "apres", "april", "apron", "apter", "aptly", "araba", "arabs", "araki", "arana", "arata", "arbor", "arced", "arche", "arcos", "arcus", "arden", "ardor", "areal", "areas", "areca", "arena", "arend", "arent", "arete", "argon", "argos", "argot", "argue", "argus", "arial", "arian", "arias", "ariel", "aries", "arise", "arjun", "arkan", "arkin", "arlen", "arles", "arlin", "arm's", "armas", "armco", "armed", "armer", "armes", "armin", "armor", "arnaz", "arndt", "arnie", "aroma", "arora", "arose", "arpin", "arran", "arras", "array", "arris", "arrow", "arses", "arson", "art's", "artel", "arter", "artic", "artie", "artis", "artsy", "aruba", "arvid", "arvin", "aryan", "asahi", "asaro", "ascap", "ascii", "ascot", "asean", "ashby", "ashed", "ashen", "asher", "ashes", "ashok", "asian", "asics", "aside", "asked", "asker", "askew", "askey", "askin", "aslan", "asmus", "asner", "aspen", "asper", "aspic", "assad", "assaf", "assai", "assam", "assay", "assed", "asses", "asset", "assis", "assoc", "aster", "astin", "astir", "aston", "astor", "astra", "astro", "atari", "ation", "atkin", "atlas", "atlee", "atmel", "atmos", "atoll", "atoms", "atone", "atria", "attar", "atthe", "attic", "aubin", "audax", "auden", "audio", "audit", "audry", "auger", "aught", "augur", "aunts", "aunty", "aural", "auras", "auric", "aurum", "autos", "autry", "avail", "avant", "avast", "avena", "avers", "avert", "avery", "avian", "avila", "avion", "aviva", "avnet", "avoid", "avoir", "avows", "avram", "avril", "awacs", "await", "awake", "award", "aware", "awash", "aways", "awful", "awoke", "axels", "axial", "axing", "axiom", "axles", "axons", "ayala", "ayers", "ayres", "azeri", "azhar", "aztec", "azure", "b'nai", "babas", "babby", "babel", "baber", "babes", "babka", "bache", "backs", "bacon", "baddy", "baden", "badge", "badly", "bafta", "bagby", "bagel", "baggs", "baggy", "bagot", "bahia", "baile", "bails", "baily", "bains", "baird", "baits", "baize", "bajan", "baked", "baker", "bakes", "bakke", "balan", "balas", "balch", "baldy", "baled", "baler", "bales", "balks", "balky", "balla", "balli", "ballo", "balls", "bally", "balms", "balmy", "baloo", "balsa", "bambi", "banal", "banca", "banco", "banda", "bands", "bandy", "banes", "banff", "bangs", "banjo", "banks", "banns", "bantu", "barak", "baran", "barba", "barbe", "barbs", "barco", "bardo", "bards", "bared", "barer", "bares", "barge", "barks", "barmy", "barns", "barny", "baron", "barra", "barre", "barro", "barry", "barta", "barth", "barto", "barts", "bartz", "basal", "based", "basel", "baser", "bases", "basha", "basic", "basie", "basil", "basin", "basis", "basks", "basle", "bason", "basra", "basse", "bassi", "basso", "basta", "baste", "batch", "bated", "bates", "bathe", "baths", "batik", "baton", "bator", "batts", "batty", "bauer", "baugh", "baume", "bawdy", "bawls", "bayed", "bayer", "bayly", "bayne", "bayou", "bazar", "beach", "beads", "beady", "beaks", "beaky", "beale", "beams", "beano", "beans", "beard", "bears", "beast", "beata", "beats", "beaty", "beaus", "beaut", "beaux", "bebop", "becca", "becht", "becki", "becks", "becky", "beebe", "beeby", "beech", "beefs", "beefy", "beene", "beens", "beeps", "beers", "beery", "beets", "befit", "befor", "began", "begat", "beget", "begin", "begot", "begum", "begun", "beige", "being", "beira", "belay", "belch", "belen", "belew", "belie", "belin", "bella", "belle", "belli", "bello", "bells", "belly", "below", "belts", "beman", "bemis", "bench", "benda", "bends", "benes", "benet", "bengt", "benin", "benji", "benjy", "benne", "benni", "benno", "benny", "bento", "bents", "benzo", "beret", "bergh", "bergs", "berke", "berko", "berks", "berle", "berms", "berne", "berra", "berri", "berry", "berth", "berti", "beryl", "beset", "besse", "bessy", "bests", "betas", "betel", "beter", "bethe", "betsy", "betta", "bette", "betts", "betty", "bevan", "bevel", "bever", "bevin", "bevis", "beyer", "bezel", "bhatt", "bialy", "bibby", "bible", "bicep", "biddy", "bided", "biden", "bides", "bidet", "biehn", "biers", "biggs", "biggy", "bight", "bigot", "bihar", "bijan", "bijou", "biked", "biker", "bikes", "bilbo", "bilby", "bildt", "biles", "bilge", "bille", "bills", "billy", "bimbo", "binds", "bines", "binge", "bingo", "binky", "binns", "biome", "biota", "biped", "birch", "birds", "birdy", "birks", "biron", "birth", "bison", "bitch", "biter", "bites", "bitsy", "bitte", "bitty", "bjorn", "black", "blade", "blaha", "blain", "blair", "blake", "blame", "blanc", "bland", "blank", "blare", "blase", "blass", "blast", "blaze", "bleak", "bleat", "blech", "bleed", "bleep", "blend", "bless", "blick", "bligh", "blimp", "blind", "blini", "blink", "blips", "bliss", "blitz", "bloat", "blobs", "bloch", "block", "blocs", "bloke", "blond", "blood", "bloom", "bloop", "bloor", "blore", "blots", "blown", "blows", "blued", "bluer", "blues", "bluey", "bluff", "blume", "blunk", "blunt", "blurb", "blurs", "blurt", "blush", "blyth", "board", "boars", "boase", "boast", "boats", "bob's", "bobbi", "bobby", "bocca", "bocce", "boche", "boded", "boden", "bodes", "bodhi", "bodie", "boehm", "boers", "boffo", "bogan", "bogey", "boggs", "boggy", "bogie", "bogle", "bogor", "bogue", "bogus", "boils", "boing", "boise", "boles", "bolin", "bolle", "bolls", "bolsa", "bolts", "bolus", "bomba", "bombs", "bondi", "bonds", "boned", "boner", "bones", "bonet", "boney", "bongo", "bongs", "bonin", "bonne", "bonny", "bonum", "bonus", "boobs", "booby", "boody", "booed", "books", "booms", "boone", "boons", "boors", "boose", "boost", "booth", "boots", "booty", "booze", "boozy", "borak", "boras", "borax", "bored", "borel", "boren", "borer", "bores", "boric", "boris", "borne", "borns", "boron", "bosch", "bosco", "bosom", "boson", "bossa", "bossi", "bossy", "bosun", "botas", "botch", "bothe", "botta", "botts", "bough", "boule", "bound", "bourg", "bourn", "bouse", "bouts", "bovey", "bowed", "bowel", "bowen", "bower", "bowes", "bowie", "bowls", "bowne", "boxed", "boxer", "boxes", "boy's", "boyar", "boyce", "boyer", "boyle", "bozos", "brace", "brach", "brack", "bracy", "brads", "brady", "braga", "bragg", "brags", "brahm", "braid", "brail", "brain", "brake", "brame", "brand", "brank", "brann", "brant", "brash", "brass", "brats", "bratt", "braun", "brave", "bravo", "brawl", "brawn", "brays", "bread", "break", "bream", "brean", "breck", "breda", "brede", "breed", "breen", "brees", "brent", "brest", "brett", "breve", "brews", "brian", "briar", "bribe", "brice", "brick", "bride", "brief", "brien", "brier", "brigs", "brill", "brims", "brine", "bring", "brink", "briny", "brion", "brisk", "brita", "brite", "brito", "brits", "britt", "broad", "brock", "broda", "brody", "broil", "broke", "brome", "bronc", "bronx", "brood", "brook", "broom", "brose", "broth", "brown", "brows", "bruce", "bruch", "bruck", "bruin", "bruit", "brune", "bruni", "bruno", "bruns", "brunt", "brush", "brust", "brute", "bryan", "bryce", "bryon", "bubba", "bubby", "bucci", "bucko", "bucks", "bucky", "budde", "buddy", "budge", "buena", "bueno", "buffo", "buffs", "buffy", "buggs", "buggy", "bugle", "buick", "build", "built", "bulbs", "bulge", "bulks", "bulky", "bulla", "bulls", "bully", "bumps", "bumpy", "bunce", "bunch", "bunco", "bunds", "bundy", "bunge", "bunko", "bunks", "bunny", "bunya", "buoys", "buran", "burbs", "burch", "burge", "burgh", "burin", "burka", "burke", "burks", "burly", "burma", "burns", "burnt", "burps", "burro", "burrs", "burry", "bursa", "burse", "burst", "burts", "busby", "busch", "bused", "buser", "buses", "bushy", "busta", "busto", "busts", "busty", "butch", "butte", "butts", "butyl", "buxom", "buyer", "buzzy", "bwana", "byard", "bybee", "byers", "bylaw", "bynum", "byrne", "byron", "bytes", "bythe", "byway", "c'est", "c'mon", "cabal", "caban", "cabby", "caber", "cabin", "cable", "cabot", "cacao", "cache", "cacti", "caddo", "caddy", "caden", "cades", "cadet", "cadge", "cadiz", "cadre", "cafes", "cagan", "caged", "cages", "cagey", "cairn", "cairo", "caixa", "cajon", "cajun", "caked", "cakes", "caleb", "calif", "calix", "calla", "calle", "calls", "calms", "calor", "calum", "calve", "calvo", "calyx", "camas", "camby", "camco", "camel", "cameo", "cames", "campa", "campi", "campo", "camps", "campy", "camry", "camus", "can't", "canal", "canas", "candi", "candy", "caned", "canes", "canid", "canna", "canny", "canoe", "canon", "canst", "canto", "canty", "cap'n", "cap's", "caped", "capel", "caper", "capes", "caple", "capon", "capps", "cappy", "capra", "capri", "car's", "carat", "carbo", "carbs", "carby", "cards", "cared", "carer", "cares", "caret", "carey", "cargo", "carib", "carin", "carla", "carle", "carli", "carlo", "carls", "carly", "carne", "carns", "carny", "carob", "carol", "caron", "carpe", "carps", "carri", "carry", "carse", "carta", "carte", "carts", "carty", "carus", "carve", "caryl", "caryn", "casal", "casas", "casco", "cased", "cases", "casey", "casio", "casks", "cason", "casta", "caste", "casts", "cat's", "catch", "cater", "cates", "cathi", "cathy", "catia", "caton", "catty", "caulk", "causa", "cause", "cavan", "caved", "caver", "caves", "cavey", "cavil", "cayce", "cdrom", "ceara", "cease", "cecil", "cedar", "ceded", "cedes", "ceiba", "celeb", "celia", "cella", "celle", "celli", "cello", "cells", "celso", "celts", "cento", "cents", "cerda", "ceres", "cerro", "certo", "certs", "cesar", "cetin", "cette", "cetus", "chace", "chack", "chaco", "chads", "chafe", "chaff", "chaim", "chain", "chair", "chaka", "chalk", "champ", "chana", "chane", "chang", "chant", "chaos", "chaps", "chard", "charm", "chars", "chart", "chary", "chase", "chasm", "chats", "cheap", "cheat", "check", "cheek", "cheep", "cheer", "chefs", "chemo", "cheng", "chere", "cheri", "chert", "chery", "chess", "chest", "chevy", "chews", "chewy", "chiao", "chiat", "chiba", "chica", "chick", "chico", "chide", "chief", "chien", "child", "chile", "chili", "chill", "chime", "chimp", "china", "chine", "ching", "chink", "chinn", "chino", "chins", "chips", "chirp", "chita", "chits", "chloe", "chock", "choco", "choir", "choke", "chola", "chomp", "chong", "chook", "choon", "chops", "chord", "chore", "chose", "chows", "chris", "chron", "chubb", "chuch", "chuck", "chuff", "chugs", "chula", "chump", "chums", "chung", "chunk", "churl", "churn", "chute", "ciara", "cider", "cigar", "cigna", "cilia", "cinch", "cinco", "cindy", "circa", "circe", "cisco", "cited", "cites", "civet", "civic", "civil", "clack", "claes", "claim", "clair", "clamp", "clams", "clang", "clank", "clans", "clapp", "claps", "clara", "clare", "clark", "claro", "clary", "clash", "clasp", "class", "claud", "claus", "clave", "claws", "clays", "clean", "clear", "cleat", "clefs", "cleft", "clegg", "clerk", "cleve", "clews", "click", "cliff", "clift", "climb", "clime", "cline", "cling", "clink", "clint", "clips", "clive", "cloak", "clock", "clods", "clogs", "cloke", "clone", "close", "cloth", "clots", "cloud", "clout", "clove", "clown", "clubs", "cluck", "clued", "clues", "cluff", "clump", "clung", "clunk", "clyde", "coach", "coale", "coals", "coast", "coats", "cobbs", "cobby", "coble", "cobol", "cobra", "cobre", "cocci", "cocco", "cocks", "cocky", "cocoa", "cocos", "codec", "coded", "coder", "codes", "codex", "codon", "coeds", "coeur", "cofer", "cogan", "cohan", "cohen", "coils", "coins", "coked", "coker", "cokes", "cokie", "colas", "colby", "colds", "colen", "coles", "coley", "colic", "colin", "colla", "colle", "colly", "colon", "color", "colts", "colum", "comas", "combe", "combi", "combo", "combs", "comer", "comes", "comet", "comex", "comfy", "comic", "comma", "comme", "compo", "comps", "conal", "conan", "conch", "conde", "condo", "coned", "cones", "coney", "conga", "congo", "conic", "conny", "conor", "const", "conte", "conti", "conus", "cooch", "cooed", "cooke", "cooks", "cools", "cooly", "coons", "coops", "coopt", "coors", "coots", "copal", "coped", "coper", "copes", "coppa", "copps", "copra", "copse", "copus", "coral", "coram", "coran", "corba", "corby", "corda", "cords", "cordy", "corea", "cored", "corel", "corer", "cores", "corey", "corgi", "coria", "corio", "corks", "corky", "corms", "corne", "corns", "corny", "corps", "corry", "corsa", "corse", "corsi", "corso", "corte", "corum", "corvo", "cosby", "cosey", "cosmo", "costa", "costs", "cotes", "cotta", "couch", "cough", "could", "cound", "count", "coupe", "coups", "cours", "court", "couse", "coven", "cover", "coves", "covet", "covey", "cowan", "cowed", "cowen", "cower", "cowie", "cowls", "coxed", "coxes", "coyle", "coyly", "coyne", "crabb", "crabs", "crack", "craft", "cragg", "crags", "craig", "crain", "cramp", "crams", "crane", "crank", "crans", "crape", "crapo", "craps", "crash", "crass", "crate", "crave", "crawl", "crays", "craze", "crazy", "creak", "cream", "crean", "crear", "creat", "credo", "creed", "creek", "creel", "creep", "crees", "crema", "creme", "crepe", "crept", "cress", "crest", "crete", "crewe", "crews", "cribs", "crick", "cried", "crier", "cries", "crime", "crimp", "crips", "crisp", "criss", "crist", "croak", "croat", "crock", "croft", "croix", "croke", "croll", "crome", "crone", "cronk", "crony", "crook", "croom", "croon", "crops", "crore", "cross", "croup", "crowd", "crowe", "crown", "crows", "crude", "cruel", "cruet", "crumb", "crump", "cruse", "crush", "crust", "crypt", "cuban", "cubby", "cubed", "cubes", "cubic", "cubit", "cuddy", "cuero", "cuffs", "culex", "culls", "cully", "culpa", "cults", "cumin", "cuneo", "cunha", "cuomo", "cuong", "cupid", "cuppa", "cuppy", "curbs", "curds", "cured", "cures", "curia", "curie", "curio", "curls", "curly", "curry", "curse", "curve", "curvy", "cushy", "cuter", "cutie", "cutty", "cuvee", "cyber", "cycle", "cyndi", "cynic", "cyril", "cyrix", "cyrus", "cysts", "czars", "czech", "dacha", "dacia", "dad's", "daddy", "daffy", "dagan", "dagon", "daiei", "daily", "dairy", "daisy", "daiwa", "dakar", "dakin", "dalai", "dales", "daley", "dalia", "dalla", "dally", "daman", "damas", "dames", "damme", "damns", "damon", "damps", "dance", "dancy", "dando", "dandy", "danes", "danke", "danna", "danny", "dansk", "dante", "daoud", "darby", "darcy", "dared", "dares", "daria", "darin", "dario", "darke", "darks", "darky", "darpa", "darst", "darth", "darts", "darya", "daryl", "datas", "dated", "dater", "dates", "datta", "datuk", "datum", "daube", "dauer", "daunt", "daves", "davey", "david", "davie", "davin", "davis", "davos", "dawes", "dawgs", "dawns", "day's", "dayal", "dayan", "dazed", "dbase", "deads", "deals", "dealt", "dealy", "deana", "deane", "deans", "dears", "deary", "death", "debar", "debby", "debit", "debra", "debts", "debug", "debut", "decaf", "decal", "decay", "decks", "decor", "decoy", "decry", "deeds", "deely", "deems", "deeps", "deere", "deery", "defer", "degas", "degen", "deify", "deign", "deion", "deism", "deist", "deity", "delay", "delco", "delfs", "delft", "delhi", "delia", "delis", "della", "delle", "dells", "delos", "delph", "delta", "delve", "demon", "demos", "demur", "denby", "deneb", "denim", "denis", "denny", "dense", "dente", "dents", "denys", "depot", "depth", "depts", "derby", "derek", "deren", "derma", "derry", "desai", "desch", "desks", "deter", "detox", "dette", "deuce", "deutz", "deval", "devas", "devel", "dever", "devil", "devin", "devon", "devos", "dewan", "dewar", "dewey", "dhabi", "dhaka", "dhoti", "dhows", "dials", "diana", "diane", "diann", "diary", "diazo", "diced", "dices", "dicey", "dicke", "dicks", "dicky", "dicta", "diddy", "didja", "didnt", "didst", "diego", "diets", "diety", "dietz", "diggs", "digit", "dijon", "dikes", "dildo", "dilip", "dills", "dilly", "dimas", "dimer", "dimes", "dimly", "dinah", "dinar", "dined", "diner", "dines", "dingo", "dings", "dingy", "dinka", "dinks", "dinky", "dinos", "diode", "dione", "dippy", "direc", "dirge", "dirks", "dirty", "disch", "disco", "discs", "dishy", "disks", "ditch", "ditsy", "ditto", "ditty", "divan", "divas", "dived", "diver", "dives", "divot", "divvy", "diwan", "dixie", "dixit", "dixon", "dizzy", "djinn", "doane", "dobbs", "dobby", "dobie", "dobra", "docks", "dodds", "dodge", "dodgy", "dodos", "doerr", "doers", "doesn", "doest", "doeth", "dog's", "dogan", "doges", "doggy", "dogma", "doily", "doin'", "doing", "dokey", "dolan", "dolby", "dolce", "doled", "doles", "dolls", "dolly", "dolor", "dolts", "domed", "domes", "domke", "don't", "donar", "donat", "donde", "donee", "doner", "doney", "dongs", "donis", "donna", "donne", "donny", "donor", "donut", "doody", "dooms", "doors", "doozy", "doped", "doper", "dopes", "dopey", "doral", "doran", "doren", "dorey", "doria", "doric", "dorie", "doris", "dorks", "dorky", "dorms", "doron", "dosed", "doser", "doses", "doted", "dotes", "dotty", "doubt", "dough", "douse", "dover", "doves", "dovey", "dowdy", "dowel", "dower", "dowie", "downe", "downs", "downy", "dowry", "dowse", "doyen", "doyle", "dozed", "dozen", "dozer", "dozes", "drabs", "draco", "draft", "drago", "drags", "drain", "drake", "drama", "drams", "drang", "drank", "drape", "drawl", "drawn", "draws", "dread", "dream", "drear", "dreck", "drees", "dregs", "dress", "drews", "dribs", "dried", "drier", "dries", "drift", "drill", "drily", "drina", "drink", "drips", "drive", "droid", "droit", "droll", "drone", "drool", "droop", "drops", "dross", "drove", "drown", "drugs", "druid", "drums", "drunk", "drury", "druse", "druze", "dryer", "dryly", "duals", "duane", "dubai", "dubey", "dubin", "ducal", "ducat", "duchy", "ducks", "ducky", "ducts", "duddy", "dudes", "duels", "duero", "duets", "duffs", "duffy", "dugan", "dukes", "dulce", "dulls", "dully", "duman", "dumas", "dumbo", "dummy", "dumps", "dumpy", "dunce", "dunes", "dungy", "dunks", "dunne", "dunno", "dunst", "duong", "duped", "duper", "dupes", "dupre", "dupuy", "duque", "duran", "durst", "durum", "dusky", "dusts", "dusty", "dutch", "dutra", "duval", "duvet", "dwarf", "dweeb", "dwell", "dwelt", "dwyer", "dyers", "dying", "dykes", "dylan", "dyson", "eadie", "eagan", "eager", "eagle", "eakin", "eames", "eamon", "eared", "earle", "earls", "early", "earns", "earth", "eased", "easel", "easer", "eases", "eason", "eaten", "eater", "eaton", "eaves", "ebbed", "ebert", "ebola", "ebony", "echos", "ecker", "eclat", "ecole", "econo", "eddie", "edema", "edgar", "edged", "edger", "edges", "edict", "edify", "edith", "edits", "edney", "edsel", "edson", "edwin", "eelam", "eerie", "effet", "effie", "efron", "egads", "egged", "egger", "egham", "egret", "egypt", "ehret", "eider", "eigen", "eight", "einar", "einem", "einer", "eisen", "eject", "eking", "ekman", "eland", "elate", "elbow", "elden", "elder", "eldon", "elect", "elegy", "elena", "elfin", "elgar", "elgin", "elias", "eliot", "elisa", "elise", "elite", "eliza", "elkin", "ellen", "eller", "elles", "ellie", "ellis", "elmer", "elope", "elroy", "elses", "elsie", "elson", "elton", "elude", "elves", "elvin", "elvis", "elway", "elyse", "emacs", "email", "embed", "ember", "emcee", "emden", "emery", "emile", "emily", "emits", "emmer", "emmet", "emmie", "emmys", "emory", "emote", "empty", "enact", "ended", "ender", "endow", "enema", "enemy", "engel", "engle", "eniac", "enjoy", "ennis", "ennui", "enoch", "enrol", "enron", "ensor", "ensue", "enter", "entre", "entry", "enuff", "envoy", "epcot", "epics", "epoch", "epoxy", "epsom", "epson", "equal", "equip", "erase", "erato", "erect", "ergot", "erica", "erich", "erick", "erika", "erkki", "ernie", "ernst", "erode", "erred", "errol", "error", "erupt", "ervin", "erwin", "esque", "essay", "essen", "esser", "esses", "essex", "essie", "estas", "estee", "ester", "estes", "ethan", "ethel", "ether", "ethic", "ethos", "ethyl", "etter", "etude", "euler", "euros", "evade", "evans", "evens", "event", "evers", "evert", "every", "evian", "evict", "evils", "evita", "evoke", "evren", "ewart", "ewers", "ewing", "exact", "exalt", "exams", "excel", "execs", "exert", "exile", "exist", "exits", "exley", "expat", "expel", "expos", "extol", "extra", "exude", "exult", "exxon", "eying", "eyler", "eyrie", "faber", "fabio", "fable", "faced", "facer", "faces", "facet", "facey", "facia", "facie", "facto", "facts", "faded", "fadel", "fader", "fades", "fagan", "fagin", "fagot", "fahey", "fahmy", "fails", "faine", "faint", "faire", "fairs", "fairy", "faith", "faked", "faker", "fakes", "fakir", "falla", "falls", "false", "falta", "falun", "famed", "fancy", "fangs", "fanny", "fanta", "fante", "faqir", "farah", "farce", "fared", "fares", "fargo", "farms", "farsi", "farts", "fasts", "fatah", "fatal", "fated", "fates", "fatso", "fatty", "fatwa", "fauci", "faulk", "fault", "fauna", "fauns", "faure", "faust", "favor", "favre", "fawns", "faxed", "faxes", "fayed", "fazed", "fazio", "fears", "feast", "feats", "fecal", "feces", "feder", "fedex", "feeds", "feels", "feely", "feeny", "feets", "feign", "feild", "feint", "feist", "feith", "feldt", "felis", "felix", "fella", "fells", "felon", "felts", "felty", "femme", "femur", "fence", "fends", "feral", "feria", "ferme", "fermi", "ferns", "ferny", "ferri", "ferro", "ferry", "festa", "fests", "fetal", "fetch", "feted", "fetes", "fetid", "fetus", "feuds", "feuer", "fever", "fewer", "fiala", "fiats", "fiber", "fibre", "fiche", "ficus", "fidel", "fides", "fiefs", "field", "fiend", "fiery", "fifer", "fifes", "fifth", "fifty", "fight", "filch", "filed", "filer", "files", "filet", "fills", "filly", "films", "filmy", "filth", "final", "finan", "finch", "finds", "fined", "finer", "fines", "finis", "finks", "finns", "finny", "fiona", "fiord", "fired", "fires", "firma", "firms", "first", "firth", "fishy", "fiske", "fists", "fitch", "fitts", "fiver", "fives", "fixed", "fixer", "fixes", "fizzy", "fjord", "flack", "flagg", "flags", "flail", "flair", "flake", "flaky", "flame", "flamm", "flank", "flans", "flaps", "flare", "flash", "flask", "flats", "flaws", "fleas", "fleck", "fleer", "flees", "fleet", "flesh", "fleur", "flexi", "flick", "flied", "flier", "flies", "fling", "flink", "flinn", "flint", "flips", "flirt", "flits", "float", "flock", "floes", "flogs", "flood", "floor", "flops", "flora", "flore", "flory", "floss", "flour", "flout", "flown", "flows", "floyd", "flubs", "flues", "fluff", "fluid", "fluke", "flume", "flung", "flunk", "fluor", "flush", "flute", "flyby", "flyer", "flynn", "foals", "foams", "foamy", "focal", "focus", "fogel", "fogey", "foggy", "fogle", "foils", "foist", "folds", "foley", "folha", "folic", "folie", "folio", "folks", "folky", "folly", "fonda", "fonds", "fonte", "fonts", "foods", "fools", "foote", "foots", "foray", "force", "forde", "fords", "foret", "forex", "forge", "forgo", "forks", "forli", "forma", "forme", "forms", "forst", "forte", "forth", "forts", "forty", "forum", "fossa", "fosse", "fouls", "found", "fount", "fours", "foust", "fouts", "fovea", "fowls", "fox's", "foxed", "foxes", "foyer", "foyle", "fraga", "frahm", "frail", "frame", "franc", "frank", "frans", "franz", "frase", "frats", "fraud", "frayn", "frays", "fraze", "freak", "freda", "freed", "freel", "freer", "frees", "freon", "frere", "fresh", "frets", "freud", "freya", "friar", "frick", "frida", "fried", "friel", "frier", "fries", "frill", "frisk", "frist", "frith", "frito", "frits", "fritz", "frizz", "frock", "frogs", "fromm", "frond", "front", "froom", "frosh", "frost", "froth", "frown", "froze", "fruit", "frump", "fryer", "fuchs", "fucks", "fuddy", "fudge", "fudgy", "fuego", "fuels", "fugue", "fukui", "fulls", "fully", "fumed", "fumes", "fundi", "funds", "fungi", "funks", "funky", "funny", "fuqua", "furby", "furor", "furry", "furse", "furst", "furth", "fusco", "fused", "fuses", "fussy", "fusty", "futch", "futon", "fuzes", "fuzzy", "g'day", "gabby", "gabel", "gable", "gabon", "gaels", "gaffe", "gaffs", "gages", "gagne", "gahan", "gaily", "gains", "gaits", "galan", "galas", "galax", "galea", "galen", "gales", "galla", "galle", "galli", "gallo", "galls", "gamal", "gamba", "gamer", "games", "gamey", "gamez", "gamin", "gamma", "gamut", "ganas", "ganda", "gandy", "ganga", "gange", "gangs", "ganja", "gantt", "gap's", "gaped", "gapes", "garbo", "garda", "garde", "garon", "garry", "garth", "garza", "gases", "gasps", "gassy", "gated", "gates", "gator", "gatos", "gaudy", "gauge", "gauls", "gault", "gaunt", "gauss", "gauze", "gauzy", "gavel", "gavin", "gawky", "gayer", "gayle", "gazan", "gazed", "gazer", "gazes", "gears", "geary", "gecko", "geeks", "geeky", "geese", "geest", "gehry", "geier", "geist", "gelee", "gemma", "genco", "gener", "genes", "genet", "genie", "genin", "genoa", "genre", "gente", "gents", "genus", "geode", "geoff", "geoid", "georg", "geral", "gerda", "germs", "gerri", "gerry", "gerth", "gertz", "gesso", "getty", "getup", "ghali", "ghana", "ghats", "ghazi", "ghent", "ghose", "ghosh", "ghost", "ghoul", "giant", "gibbs", "gibby", "gibes", "giddy", "gifts", "gigot", "gilda", "giles", "gills", "gilly", "gilts", "gimli", "gimme", "gimpy", "ginny", "ginty", "gipsy", "girds", "girls", "girly", "girod", "giron", "girth", "given", "giver", "gives", "givin", "gizmo", "glace", "glade", "gland", "glare", "glass", "glatt", "glaxo", "glaze", "gleam", "glean", "glebe", "glenn", "glens", "glial", "glick", "glide", "glint", "glitz", "gloat", "globe", "globo", "globs", "glock", "gloom", "glory", "gloss", "glove", "glows", "gluck", "glued", "glues", "gluey", "gluon", "gluts", "glynn", "glyph", "gnash", "gnats", "gnaws", "gnome", "goads", "goals", "goats", "goble", "god's", "godel", "godin", "godly", "godoy", "goers", "goeth", "goetz", "gofer", "going", "golda", "golde", "golds", "goldy", "golem", "golfs", "golly", "goltz", "golub", "gomer", "gomes", "gomez", "goner", "gongs", "gonna", "gonzo", "gooch", "goode", "goods", "goody", "gooey", "goofs", "goofy", "gooks", "goons", "goose", "gopal", "goral", "goran", "gorda", "gordo", "gored", "gores", "gorge", "gorki", "gorky", "gorse", "gotch", "goths", "gotta", "gouda", "gouge", "gough", "gould", "gourd", "gouty", "gowan", "gowdy", "gowen", "gowns", "goyal", "goyim", "grabe", "grabs", "grace", "graco", "grade", "grads", "grady", "graff", "graft", "grail", "grain", "grama", "gramm", "grams", "grana", "grand", "grano", "grant", "grape", "graph", "grasp", "grass", "grata", "grate", "gratz", "grave", "gravy", "grays", "graze", "great", "grebe", "greco", "greed", "greek", "green", "greer", "greet", "gregg", "greif", "greig", "greta", "grete", "greve", "greys", "grice", "grids", "grief", "grier", "griff", "grigg", "grill", "grime", "grimm", "grimy", "grind", "grins", "gripe", "grips", "grise", "grist", "grits", "groan", "groat", "grobe", "groce", "groep", "groff", "groin", "groom", "groot", "grope", "gross", "grosz", "grote", "groth", "group", "grout", "grove", "growl", "grown", "grows", "grubb", "grubs", "gruel", "gruen", "gruff", "grump", "grund", "grunt", "grupo", "gruss", "guage", "guano", "guard", "guava", "gucci", "guess", "guest", "guide", "guido", "guild", "guile", "guilt", "guise", "gulag", "gulch", "gulfs", "gulls", "gully", "gulps", "gumbo", "gummy", "gundy", "gunky", "gunny", "guppy", "gupta", "gurus", "gushy", "gusto", "gusts", "gusty", "guten", "gutsy", "gutta", "guy's", "guyer", "guyot", "gwinn", "gwynn", "gypsy", "gyros", "gyrus", "haack", "haase", "haber", "habit", "hacer", "hache", "hacks", "hacky", "haden", "hader", "hades", "hadji", "hafez", "hafiz", "hafta", "hagan", "hagar", "hagel", "hagen", "hager", "hagia", "hague", "haifa", "haigh", "haiku", "haile", "hails", "haire", "hairs", "hairy", "haiti", "hajji", "hakan", "hakes", "hakim", "hakon", "halal", "halas", "halen", "hales", "haley", "halle", "hallo", "halls", "hally", "halon", "halos", "halts", "halva", "halve", "hamad", "haman", "hamas", "hamby", "hamel", "hames", "hamid", "hamil", "hammy", "hamza", "hance", "handa", "hands", "handy", "hanes", "haney", "hangs", "hanif", "hanja", "hanko", "hanks", "hanky", "hanna", "hanoi", "hansa", "hanse", "haole", "happy", "haque", "haram", "haran", "hards", "hardy", "harem", "hares", "harks", "harle", "harms", "harpo", "harps", "harpy", "harri", "harry", "harsh", "harte", "harts", "hartt", "hasan", "hasse", "hasta", "haste", "hasty", "hat's", "hatch", "hated", "hater", "hates", "hauck", "hauer", "haugh", "hauls", "haunt", "hausa", "hause", "haute", "havas", "havea", "haved", "havel", "haven", "haver", "haves", "havin", "havoc", "hawed", "hawes", "hawke", "hawks", "haydn", "hayek", "hayes", "hayne", "hazan", "hazed", "hazel", "hazen", "he'll", "heads", "heady", "heald", "heals", "healy", "heaps", "heard", "hearn", "hears", "heart", "heath", "heats", "heave", "heavy", "hebei", "heber", "hecht", "hedda", "hedge", "heeds", "heels", "hefei", "hefty", "heidi", "heine", "heinz", "heirs", "heise", "heist", "heitz", "helds", "helen", "helga", "helix", "helle", "hello", "hells", "helly", "helms", "helps", "heman", "henan", "hence", "hendy", "henna", "henny", "henri", "henry", "herba", "herbs", "herby", "herds", "herms", "herne", "herod", "heron", "heros", "herre", "hersh", "hertz", "herve", "hesse", "hetty", "heuer", "hewed", "hewer", "hewes", "hexed", "hexes", "hiatt", "hibbs", "hicks", "hideo", "hider", "hides", "higgs", "highs", "hight", "hijab", "hijra", "hiked", "hiker", "hikes", "hilda", "hills", "hilly", "hilts", "himes", "hinch", "hindi", "hinds", "hindu", "hines", "hiney", "hinge", "hints", "hippo", "hippy", "hiram", "hired", "hirer", "hires", "hirsh", "hirst", "hissy", "hitch", "hived", "hives", "hiway", "hixon", "hjelm", "hmmmm", "hmong", "hoagy", "hoang", "hoard", "hoare", "hoary", "hoban", "hobbs", "hobby", "hobos", "hocks", "hocus", "hodel", "hodge", "hoehn", "hofer", "hoffa", "hogan", "hogue", "hoist", "hokey", "hokum", "holds", "holed", "holes", "holey", "holly", "holme", "holst", "holts", "homan", "homed", "homer", "homes", "homey", "homme", "homos", "honan", "honda", "hondo", "honed", "honer", "hones", "honey", "honig", "honks", "honky", "honor", "hooch", "hoods", "hooey", "hoofs", "hooke", "hooks", "hooky", "hoops", "hoose", "hoots", "hoped", "hoper", "hopes", "hoppe", "hoppy", "horan", "horas", "horde", "horne", "horns", "horny", "horse", "horst", "horus", "hosea", "hosed", "hoses", "hosni", "hosta", "hosts", "hotel", "hotly", "houck", "hough", "hould", "hound", "hours", "house", "hovel", "hoven", "hover", "hovis", "how'd", "how's", "howdy", "hower", "howes", "howie", "howls", "hoxie", "hoyer", "hoyle", "hoyos", "hsieh", "hsien", "huang", "hubby", "hubei", "huber", "hucks", "huddy", "huffs", "huffy", "hugel", "huger", "huggy", "huish", "hulks", "hulls", "hulme", "hulse", "human", "humid", "humor", "humph", "humps", "humpy", "humus", "hunan", "hunch", "hundt", "hunks", "hunky", "hunts", "hurls", "hurly", "huron", "hurry", "hurst", "hurts", "husks", "husky", "huson", "hussy", "hutch", "huynh", "hwang", "hyatt", "hyder", "hydra", "hydro", "hyena", "hyman", "hymen", "hymie", "hymns", "hynes", "hyogo", "hyoid", "hyped", "hyper", "hypes", "hyson", "ibiza", "icahn", "icily", "icing", "icons", "idaho", "ideal", "ideas", "ident", "idiom", "idiot", "idled", "idler", "idles", "idols", "idyll", "iftar", "igloo", "ikeda", "ilene", "iliac", "iliad", "ilion", "ilkka", "ilyas", "image", "imago", "imams", "imbed", "imber", "imbue", "imlay", "immer", "impel", "imply", "imput", "imrie", "inane", "inapt", "incas", "incur", "index", "india", "indic", "indie", "indra", "indri", "indus", "inept", "inert", "infer", "infra", "inger", "ingle", "ingot", "inked", "inker", "inlaw", "inlay", "inlet", "inman", "inner", "innes", "innit", "input", "insee", "inset", "int'l", "intel", "inter", "inthe", "intra", "intro", "inuit", "inure", "ionic", "iorio", "iowan", "ipsos", "irani", "iraqi", "irate", "irena", "irene", "irian", "irina", "irish", "irked", "irons", "irony", "irvin", "irwin", "isaac", "ishaq", "ishii", "islam", "isles", "islet", "islip", "isn't", "issac", "issue", "isuzu", "it'll", "italy", "itchy", "items", "itwas", "ivana", "ivies", "ivins", "ivory", "iwate", "ixion", "izard", "izumi", "izzat", "jaber", "jabot", "jacek", "jacki", "jacko", "jacks", "jacky", "jacob", "jaded", "jades", "jaffa", "jaffe", "jager", "jails", "jaime", "jakes", "jakob", "jamal", "jambs", "james", "jamie", "jammu", "jammy", "janak", "janes", "janet", "janey", "janie", "janik", "janis", "janna", "janos", "janus", "japan", "jared", "jason", "jaunt", "javan", "jawad", "jawed", "jayne", "jazzy", "jeane", "jeans", "jebel", "jeeps", "jeers", "jeffs", "jehad", "jello", "jelly", "jenin", "jenks", "jenna", "jenni", "jenny", "jerez", "jerks", "jerky", "jerri", "jerry", "jerzy", "jesse", "jessy", "jests", "jesus", "jeter", "jetta", "jetty", "jewel", "jewry", "jiang", "jibes", "jiffy", "jihad", "jilin", "jills", "jilly", "jimbo", "jimmy", "jingo", "jinks", "jinny", "jirga", "jives", "joann", "job's", "jocks", "jodel", "jodie", "joe's", "joerg", "joffe", "johan", "johns", "johny", "joins", "joint", "joist", "joked", "joker", "jokes", "jokey", "jolla", "jolly", "jolts", "jonah", "jonas", "jones", "jonny", "joram", "jorge", "josef", "josey", "joshi", "josie", "joule", "jours", "joust", "jovan", "jowls", "joyce", "jozef", "judah", "judas", "judea", "judeo", "judge", "judie", "jugal", "juice", "juicy", "jukes", "julep", "jules", "julia", "julie", "julio", "jumbo", "jumps", "jumpy", "junco", "junes", "junge", "junks", "junky", "junta", "junto", "jurek", "juris", "juror", "justo", "justs", "kaaba", "kabat", "kabel", "kabul", "kaden", "kader", "kafka", "kagan", "kahan", "kalam", "kalan", "kaler", "kaley", "kalis", "kalla", "kamal", "kamel", "kamen", "kanak", "kanga", "kanji", "kapok", "kappa", "kapur", "kaput", "karan", "karas", "karat", "karel", "karen", "karim", "karin", "karla", "karma", "karns", "karol", "karon", "karoo", "karry", "karsh", "karst", "kasey", "kasha", "kashi", "kates", "katha", "kathi", "kathy", "katia", "katie", "katja", "katya", "kauai", "kauri", "kayak", "kayan", "kayla", "kazan", "kazoo", "kazuo", "keach", "keane", "keanu", "keast", "keats", "kebab", "keech", "keefe", "keele", "keels", "keely", "keene", "keeps", "keese", "kegel", "kehoe", "keiko", "keita", "keith", "kelli", "kelly", "kelso", "kelty", "kemal", "kempt", "kenaf", "kenan", "kendo", "kenji", "kenna", "kenny", "kente", "kenya", "keogh", "keran", "kerbs", "kerby", "kerns", "kerri", "kerry", "ketch", "kevan", "keven", "kevin", "keyed", "keyes", "khair", "khaki", "khana", "khans", "khmer", "khost", "kiang", "kicks", "kid's", "kiddo", "kiddy", "kiley", "kills", "kilns", "kilos", "kilts", "kimmy", "kinch", "kinda", "kinds", "kindy", "kings", "kinks", "kinky", "kiosk", "kiran", "kirby", "kirch", "kirks", "kirov", "kirst", "kisan", "kissy", "kitch", "kites", "kitts", "kitty", "kiwis", "kjell", "klaas", "klare", "klatt", "klaus", "klein", "klemm", "klerk", "klett", "klick", "klieg", "kline", "kling", "klopp", "klose", "klotz", "kluck", "kluge", "klutz", "kmart", "knack", "knapp", "knave", "knead", "kneed", "kneel", "knees", "knell", "knelt", "knick", "knife", "knits", "knobs", "knock", "knoll", "knoop", "knopf", "knorr", "knots", "knott", "known", "knows", "knuth", "koala", "kochi", "kodak", "kogan", "kogut", "kohen", "kohli", "kohls", "kohut", "kolar", "kolbe", "komar", "kondo", "kongo", "kooks", "kooky", "koons", "koran", "korea", "koren", "koury", "kozma", "kraal", "kraft", "krall", "kraus", "kraut", "krebs", "kreis", "krell", "kress", "krieg", "krill", "kriss", "krist", "krock", "krohn", "kroll", "krona", "krone", "kroon", "krupp", "kruse", "kuala", "kuban", "kubik", "kudos", "kudus", "kudzu", "kuehn", "kugel", "kukri", "kulak", "kumar", "kunst", "kuntz", "kunze", "kuper", "kurds", "kursk", "kurtz", "kutch", "kwame", "kwang", "kyats", "kylie", "kylix", "kyodo", "kyoto", "kyrie", "kyung", "lab's", "laban", "labbe", "label", "labia", "labor", "laced", "laces", "lacey", "lacks", "laden", "lader", "ladin", "ladle", "lafon", "lagan", "lager", "lagos", "lahar", "lahey", "laine", "laing", "laird", "lairs", "laity", "laker", "lakes", "lakey", "lakhs", "lakin", "lally", "lamar", "lamas", "lambs", "lamda", "lamed", "lamer", "lamia", "lamin", "lampe", "lamps", "lanai", "lance", "landa", "lande", "lando", "lands", "landy", "lanes", "laney", "lange", "lanka", "lanky", "lanny", "lanza", "lapel", "lapin", "lapis", "lapps", "lapse", "larch", "lardy", "lares", "large", "largo", "larks", "larry", "larva", "laser", "laski", "lasso", "lasts", "latch", "lated", "later", "lates", "latex", "lathe", "latin", "latta", "latte", "latus", "lauch", "laude", "lauds", "lauer", "laugh", "laura", "laure", "lauri", "laval", "lavan", "laver", "lavin", "law's", "lawal", "lawes", "lawns", "laxer", "laxmi", "layed", "layer", "layne", "layup", "lazar", "lazed", "leach", "leads", "leafs", "leafy", "leahy", "leake", "leaks", "leaky", "leans", "leant", "leaps", "leapt", "learn", "leary", "lease", "leash", "least", "leave", "leavy", "leben", "leber", "lebow", "leche", "ledge", "leech", "leeds", "leeks", "leela", "leers", "leery", "leese", "lefts", "lefty", "legal", "leger", "legge", "leggy", "legit", "leigh", "leila", "leith", "leman", "lemay", "lemke", "lemma", "lemme", "lemon", "lemur", "lendl", "lends", "lenin", "lenis", "lenny", "lenox", "lense", "lento", "lentz", "leona", "leone", "leora", "leper", "leroy", "let's", "lethe", "letts", "letty", "letup", "leumi", "leung", "leval", "levee", "level", "leven", "lever", "levey", "levin", "levis", "lewin", "lewis", "lexie", "lexis", "lexus", "lhasa", "liana", "liane", "liang", "liars", "libby", "libel", "liber", "libor", "libra", "libre", "libri", "libya", "licht", "licit", "licks", "liddy", "lidia", "liebe", "liege", "liens", "lifer", "lifes", "liffe", "lifts", "light", "ligne", "ligon", "liked", "liken", "likes", "likud", "lilac", "liles", "lilia", "lille", "lilly", "liman", "limas", "limbo", "limbs", "limed", "limes", "limey", "limit", "limon", "limos", "limps", "linch", "linda", "linde", "lindh", "lindo", "lindy", "linea", "lined", "linen", "liner", "lines", "lingo", "lings", "linke", "links", "linus", "lions", "lipid", "lippy", "lisle", "lisps", "lissa", "lista", "lists", "liszt", "litem", "liter", "lites", "lithe", "litho", "litle", "litre", "litte", "lived", "liven", "liver", "lives", "livid", "livre", "lizzy", "llama", "llano", "lloyd", "loach", "loads", "loafs", "loamy", "loans", "loath", "lobby", "lobed", "lobel", "lobes", "lobos", "local", "lochs", "locke", "locks", "locos", "locus", "loden", "lodes", "lodge", "loess", "loews", "lofts", "lofty", "logan", "logic", "logie", "login", "logon", "logos", "logue", "loins", "loire", "lolly", "lomas", "lomax", "loner", "longe", "longo", "longs", "lonny", "looby", "looks", "looms", "loons", "loony", "loops", "loopy", "loose", "loots", "loper", "lopes", "lopez", "loral", "loran", "lords", "lordy", "loren", "loria", "lorie", "lorin", "loris", "lorna", "lorne", "lorry", "loser", "loses", "lot's", "lotta", "lotte", "lotto", "lotus", "lough", "louie", "louis", "loupe", "louse", "lousy", "louth", "louts", "loved", "lover", "loves", "lovey", "lovin", "lowed", "lower", "lowes", "lowly", "lowry", "loyal", "luaus", "lubes", "lubin", "lucas", "lucca", "lucey", "lucia", "lucid", "lucie", "lucio", "lucks", "lucky", "lucre", "lugar", "luger", "luigi", "luisa", "lujan", "lukas", "lukes", "lulls", "lumen", "lumps", "lumpy", "lunar", "lunch", "lundy", "lunes", "lunge", "lungi", "lungs", "luong", "lupin", "lupus", "luque", "lurch", "lured", "lures", "lurgi", "lurid", "lurie", "lurks", "lusby", "lusts", "lusty", "lutes", "luton", "luxor", "luzon", "lyall", "lycra", "lydia", "lying", "lyles", "lyman", "lymph", "lynch", "lynda", "lynne", "lyons", "lyres", "lyric", "lysis", "lysol", "lytle", "ma'am", "maass", "mabel", "mable", "macao", "macau", "macaw", "macey", "macha", "mache", "machi", "macho", "macht", "macie", "macks", "macon", "macro", "madam", "madan", "maddy", "maden", "mader", "madge", "madly", "madre", "maeda", "maeve", "mafia", "magar", "magee", "mager", "mages", "maggi", "maggs", "magic", "magid", "magma", "magna", "magus", "mahal", "mahan", "mahar", "mahdi", "maher", "mahon", "maida", "maids", "maile", "mails", "maims", "maine", "mains", "mainz", "maire", "maisy", "maize", "major", "makar", "maker", "makes", "malam", "malan", "malar", "malay", "malek", "maler", "males", "maley", "malia", "malik", "malin", "malle", "malls", "mally", "maloy", "malta", "malts", "malty", "mamas", "mamba", "mambo", "mamie", "mamma", "mammy", "mamta", "man's", "manal", "manas", "manda", "mandi", "mandy", "maned", "maner", "manes", "manet", "maney", "manga", "mange", "mango", "mangy", "mania", "manic", "manis", "manly", "manna", "manne", "manny", "manoj", "manor", "manos", "manse", "manta", "manus", "maori", "mapes", "maple", "marah", "maran", "maras", "marat", "march", "marci", "marco", "marcy", "mardi", "mardy", "marek", "mares", "marfa", "marga", "marge", "margo", "margy", "maria", "marie", "marin", "mario", "maris", "marja", "marke", "marko", "marks", "markt", "marky", "marla", "marly", "maron", "marra", "marry", "marsh", "marta", "marti", "marts", "marty", "martz", "marys", "masai", "maser", "masha", "masks", "mason", "masri", "massa", "masse", "massy", "masts", "match", "mated", "mateo", "mater", "mates", "matey", "mathe", "maths", "matic", "matra", "matta", "matte", "matts", "matty", "matus", "matza", "matzo", "maude", "mauer", "mauls", "mauna", "maung", "maura", "mauro", "maury", "mauve", "maven", "mavis", "maxed", "maxes", "maxey", "maxie", "maxim", "maxis", "mayan", "mayas", "maybe", "mayer", "mayes", "mayon", "mayor", "mazda", "mazel", "mazer", "mazes", "mazur", "mazza", "mbeki", "mccaw", "mccoy", "mccue", "mcgee", "mckay", "mckee", "mcnay", "mcnee", "mcrae", "mcvay", "mcvey", "meade", "meads", "meals", "mealy", "means", "meant", "meany", "mears", "meath", "meats", "meaty", "mecca", "medal", "medan", "medea", "media", "medic", "medio", "medoc", "meech", "meeds", "meeks", "meers", "meese", "meets", "megan", "mehdi", "mehta", "meier", "meiji", "meine", "mejor", "melba", "melby", "melds", "melee", "melfi", "melia", "melly", "melon", "melts", "memos", "men's", "mende", "mends", "menem", "menil", "menke", "menlo", "menon", "mensa", "mente", "ments", "menus", "meows", "merce", "merch", "merci", "merck", "mercy", "merge", "merit", "merle", "merry", "mertz", "meryl", "mesas", "meson", "messy", "metal", "metas", "meted", "meter", "metes", "metis", "metra", "metre", "metro", "meuse", "meyer", "mezzo", "miami", "micah", "micky", "micro", "midas", "middy", "midge", "midst", "miers", "might", "miked", "mikes", "mikey", "mikie", "mikva", "milam", "milan", "milch", "miler", "miles", "milko", "milks", "milky", "milla", "mille", "milli", "mills", "milly", "milne", "milos", "mimed", "mimes", "mimic", "mimsy", "minar", "minas", "mince", "minds", "mindy", "mined", "miner", "mines", "minge", "mingo", "minim", "minis", "minix", "minke", "minks", "minna", "minns", "minny", "minor", "minos", "minot", "minow", "minsk", "minto", "mints", "minty", "mintz", "minus", "mired", "mires", "mirna", "miron", "mirth", "mirza", "misch", "miser", "mises", "misha", "mismo", "missa", "missy", "mists", "misty", "mitch", "miter", "mites", "mitra", "mitre", "mitts", "mitzi", "mixed", "mixer", "mixes", "mixon", "mixup", "mizar", "mizen", "moans", "moats", "mobil", "mocha", "mocks", "modal", "model", "modem", "moder", "modes", "modus", "mogul", "mohan", "moira", "moire", "moise", "moist", "molar", "molds", "moldy", "moler", "moles", "molex", "molin", "molly", "molto", "mom's", "momma", "mommy", "monad", "monde", "mondo", "mones", "monet", "money", "monie", "monks", "monte", "month", "monti", "monty", "mooch", "moods", "moody", "moone", "moons", "moony", "moore", "moors", "moosa", "moose", "moots", "moped", "moral", "moran", "moray", "morel", "mores", "morey", "moria", "morin", "moris", "morne", "moron", "morph", "morra", "morro", "morse", "mosel", "moser", "moses", "mosey", "moshe", "mossy", "mosul", "motel", "motes", "motet", "moths", "motif", "moton", "motor", "motte", "motto", "motts", "mould", "moult", "mound", "mount", "mourn", "mouse", "mousy", "mouth", "moved", "mover", "moves", "movie", "mowed", "mower", "moxie", "moyen", "moyer", "moyle", "mssrs", "mucha", "mucho", "mucin", "mucks", "mucky", "mucus", "muddy", "mudge", "mudra", "muffs", "muffy", "mufti", "muggy", "mukti", "mulch", "mules", "mulla", "mulls", "multi", "mumbo", "mummy", "mumps", "munch", "mundi", "mundo", "munge", "mungo", "munis", "munoz", "munro", "muntz", "muons", "murad", "mural", "mures", "murex", "murky", "murry", "mused", "muses", "mushy", "music", "musil", "musky", "musts", "musty", "mutch", "muted", "mutes", "mutts", "muzak", "muzzy", "myers", "mylar", "myles", "mynah", "myrna", "myron", "myrrh", "myths", "myung", "n'est", "naber", "nabil", "nabob", "nacho", "nadal", "nadel", "nader", "nadia", "nadir", "nadja", "nafta", "nagar", "nagel", "nagle", "nahum", "naiad", "nails", "naira", "naish", "naive", "najib", "naked", "nalco", "named", "namer", "names", "namur", "nanas", "nance", "nancy", "nandi", "nanna", "nanny", "naomi", "nappa", "nappy", "narco", "narcs", "nares", "nasal", "nasty", "natal", "natch", "natty", "nauru", "naval", "navas", "navel", "naves", "navid", "navin", "navis", "nawab", "nawaz", "naxos", "nazar", "nazis", "ne'er", "neale", "nears", "neary", "neath", "neave", "nebel", "necks", "needs", "needy", "neela", "neely", "neese", "negro", "negus", "nehru", "neice", "neigh", "neill", "nella", "nelle", "nelly", "nemec", "neons", "nepal", "nerds", "nerdy", "nerve", "nervy", "nesta", "neste", "nests", "netto", "netty", "neuer", "neuro", "neven", "never", "neves", "nevil", "nevin", "nevis", "newby", "newel", "newer", "newly", "newsy", "newts", "nexis", "nexus", "ngaio", "niall", "nicer", "niche", "nicht", "nicki", "nicks", "nicky", "nicol", "nidal", "niece", "niels", "nieto", "nieve", "nifty", "nigel", "niger", "nigga", "night", "nihon", "nikes", "nikki", "nikko", "nikon", "nikos", "niles", "nilly", "nimby", "nimmo", "niner", "nines", "ninja", "ninny", "ninos", "ninth", "nippy", "nisan", "nisei", "nishi", "nisus", "nitro", "nitty", "niven", "nixed", "nixes", "nixie", "nixon", "nobby", "nobel", "nobis", "noble", "nobly", "nodal", "nodes", "noirs", "noise", "noisy", "nokes", "nokia", "nolan", "nolte", "nomad", "nonce", "nonny", "nooks", "noone", "noose", "norah", "norge", "norma", "norms", "norse", "norsk", "norte", "north", "nosed", "noses", "nosey", "notch", "noted", "notes", "notre", "nouns", "novak", "novas", "novel", "novia", "novum", "novus", "nowak", "nubia", "nucor", "nudes", "nudge", "nudie", "nuevo", "nuked", "nukem", "nukes", "nulls", "numbs", "nunes", "nunez", "nuova", "nuovo", "nurse", "nutty", "nylon", "nyman", "nymex", "nymph", "nynex", "nyssa", "oaken", "oakes", "oared", "oases", "oasis", "oates", "oaths", "oberg", "obese", "obeys", "obits", "objet", "oboes", "occur", "ocean", "ochre", "ocker", "octal", "octet", "odder", "oddly", "odell", "odeon", "odium", "odors", "offal", "offed", "offen", "offer", "ofice", "often", "ofthe", "ogata", "ogden", "ogled", "ogles", "ogres", "ohana", "oiled", "oiler", "okabe", "okapi", "okays", "okies", "okuda", "okura", "olden", "older", "oldie", "oleic", "oliva", "olive", "oller", "ollie", "olmos", "olney", "ology", "olsen", "olson", "olver", "omagh", "omaha", "omani", "omega", "omens", "omits", "omron", "one's", "oneof", "onion", "onset", "onthe", "oomph", "ooops", "oozed", "oozes", "opals", "opens", "opera", "ophir", "opine", "opium", "opper", "oprah", "opted", "optic", "optus", "orals", "orang", "orate", "orban", "orbis", "orbit", "orcas", "order", "oreos", "organ", "orion", "orman", "orrin", "orris", "orsay", "ortho", "ortiz", "orton", "orvis", "osage", "osaka", "osama", "oscar", "osier", "osler", "osman", "osten", "oster", "ostia", "otago", "otani", "otero", "other", "otmar", "otten", "otter", "ought", "ouija", "ounce", "ouput", "ousts", "outdo", "outed", "outer", "outgo", "outre", "outro", "outta", "ovals", "ovary", "ovate", "ovens", "overs", "overt", "overy", "ovitz", "ovoid", "ovule", "owens", "owing", "owlet", "owned", "owner", "oxbow", "oxfam", "oxide", "oxley", "ozark", "ozawa", "ozone", "ozzie", "pablo", "paced", "pacer", "paces", "pacey", "packs", "pacts", "paddy", "padre", "padua", "paean", "pagan", "pagar", "paged", "pager", "pages", "paget", "paige", "pails", "paine", "pains", "paint", "pairs", "paise", "pakis", "palas", "palau", "paled", "paler", "pales", "paley", "palma", "palme", "palms", "palmy", "palsy", "pampa", "panay", "panda", "pando", "pandy", "panel", "panes", "panga", "pangs", "panic", "panky", "panne", "pansy", "panto", "pants", "panty", "paola", "paoli", "paolo", "papal", "papas", "papaw", "paper", "pappa", "pappy", "papua", "paras", "parch", "pardo", "pared", "paree", "pares", "paris", "parka", "parke", "parks", "parle", "parma", "parol", "parra", "parry", "parse", "parte", "parti", "parto", "parts", "party", "parvo", "pasco", "paseo", "pasha", "pasok", "passe", "pasta", "paste", "pasts", "pasty", "patch", "patel", "pater", "pates", "paths", "patil", "patio", "patna", "patsy", "patti", "patty", "paula", "pauli", "paull", "paulo", "pauls", "pause", "pavan", "paved", "pavel", "paver", "paves", "pavia", "pawed", "pawns", "payed", "payee", "payer", "payne", "pdvsa", "peace", "peach", "peaks", "peaky", "peals", "pearl", "pears", "peart", "peary", "pease", "peaty", "peavy", "pecan", "pecks", "pedal", "peden", "pedro", "peeks", "peele", "peels", "peeps", "peers", "peeve", "peggy", "peine", "pekin", "pekoe", "pella", "pelts", "peltz", "pemex", "penal", "pence", "penis", "penna", "penny", "penry", "pense", "penta", "penza", "peole", "peons", "peony", "peopl", "peper", "peppy", "pepsi", "perch", "percy", "peres", "perez", "peril", "perin", "perks", "perky", "perla", "perle", "perms", "perot", "perri", "perro", "perry", "perse", "perth", "pesce", "pesky", "pesos", "pesto", "pests", "petal", "peter", "petey", "petit", "petra", "petre", "petri", "petro", "petry", "petti", "petty", "pfaff", "phage", "phair", "pharm", "phase", "phebe", "phill", "philo", "philp", "phlox", "phone", "phony", "photo", "phyla", "piano", "picas", "picks", "picky", "picot", "picts", "piece", "piero", "piers", "piety", "piezo", "piggy", "pigmy", "piker", "pikes", "pilaf", "pilar", "piled", "piles", "pills", "pilon", "pilot", "pimps", "pinch", "pined", "pines", "piney", "pings", "pinko", "pinks", "pinky", "pinna", "pinon", "pinot", "pinta", "pinto", "pints", "pinup", "pinus", "pious", "piped", "piper", "pipes", "pipit", "pippa", "pique", "pirie", "pisco", "piste", "pitch", "pithy", "piton", "pitta", "pitts", "pitty", "pivot", "pixar", "pixel", "pixie", "pizza", "place", "plaid", "plain", "plait", "plana", "plane", "plank", "plano", "plans", "plant", "plasm", "plass", "plata", "plate", "plath", "plato", "plats", "platt", "platy", "platz", "playa", "plays", "plaza", "plead", "pleas", "pleat", "plein", "plena", "plese", "plied", "plies", "plink", "pliny", "plock", "plods", "plonk", "plops", "plots", "plott", "plotz", "plows", "ploys", "pluck", "plugs", "plumb", "plume", "plump", "plums", "plunk", "plush", "pluto", "poach", "poche", "pocus", "podge", "poems", "poesy", "poets", "pogue", "point", "poise", "poked", "poker", "pokes", "pokey", "polak", "polar", "poled", "polen", "poles", "poley", "polio", "polis", "polje", "polka", "polls", "polly", "polos", "polyp", "pombo", "pompa", "ponce", "ponds", "pongo", "ponte", "ponti", "ponto", "ponzi", "pooch", "poole", "pools", "poops", "poore", "poors", "popes", "poppa", "poppy", "popup", "porch", "porco", "pored", "pores", "porgy", "porky", "porno", "poros", "porta", "porte", "porto", "ports", "posed", "poser", "poses", "posey", "posit", "posse", "poste", "posts", "potts", "potty", "pouch", "pound", "pours", "pouts", "pouty", "power", "prada", "prado", "prams", "prang", "prank", "prato", "prats", "pratt", "prawn", "prays", "preen", "preis", "premo", "preps", "press", "prest", "preys", "priam", "price", "prick", "pricy", "pride", "pried", "prier", "pries", "prima", "prime", "primo", "primp", "prine", "pring", "prins", "print", "prinz", "prion", "prior", "prise", "prism", "priss", "pritt", "privy", "prize", "pro's", "probe", "probs", "prodi", "prods", "profs", "prole", "promo", "proms", "prone", "prong", "pronk", "proof", "props", "prose", "prost", "proto", "proud", "prove", "provo", "prowl", "prows", "proxy", "prude", "prune", "pryce", "pryde", "pryor", "psalm", "pshaw", "psion", "psych", "pubic", "pudgy", "puede", "puffs", "puffy", "puget", "puked", "pukes", "pukka", "pulls", "pulps", "pulpy", "pulse", "pumas", "pumps", "punch", "punic", "punks", "punky", "punny", "punta", "punto", "punts", "pupae", "pupil", "puppy", "purdy", "puree", "purer", "purge", "purim", "purrs", "purse", "purty", "pusan", "pushy", "pussy", "putti", "putts", "putty", "pygmy", "pylon", "pylos", "pyres", "pyrex", "pyxis", "qatar", "qu'il", "quack", "quade", "quads", "quaff", "quaid", "quail", "quake", "quale", "qualm", "quant", "quark", "quart", "quash", "quasi", "quays", "queen", "queer", "quell", "query", "quest", "queue", "quick", "quiet", "quigg", "quill", "quilt", "quina", "quine", "quinn", "quint", "quips", "quire", "quirk", "quist", "quite", "quito", "quits", "quoin", "quota", "quote", "quoth", "qwest", "raabe", "rabat", "rabbi", "rabid", "rabin", "raced", "racer", "races", "racks", "radar", "radha", "radio", "radix", "radon", "raffi", "rafik", "rafts", "ragan", "ragas", "raged", "rages", "ragin", "rahal", "rahim", "rahul", "raids", "rails", "raine", "rains", "rainy", "raise", "raitt", "rajab", "rajah", "rajiv", "raked", "raker", "rakes", "rales", "rally", "ralph", "raman", "ramat", "rambo", "ramen", "ramey", "ramie", "ramon", "ramos", "ramps", "ramus", "ramzi", "rance", "ranch", "randa", "randi", "rands", "randy", "range", "rangy", "rania", "ranks", "rants", "raoul", "raped", "raper", "rapes", "rapid", "rappe", "rarer", "rasch", "rasps", "raspy", "rasta", "rat's", "ratan", "rated", "rater", "rates", "rathe", "ratio", "raton", "ratty", "rauch", "raved", "ravel", "raven", "raver", "raves", "ravin", "rawer", "rawls", "ray's", "rayed", "rayne", "rayon", "razed", "razor", "reach", "react", "reade", "reads", "ready", "realm", "reals", "realy", "reams", "reaps", "rearm", "rears", "rebar", "rebbe", "rebel", "reber", "rebid", "rebus", "rebut", "recap", "recce", "recht", "recon", "recto", "recur", "recut", "reddy", "redid", "redux", "reece", "reeds", "reedy", "reefs", "reeks", "reels", "reese", "reeve", "refer", "refit", "regal", "regan", "regas", "regen", "regie", "regis", "rehab", "reich", "reign", "reiki", "reina", "reine", "reins", "reiss", "reisz", "rejig", "relax", "relay", "relic", "relit", "reman", "remap", "remit", "remix", "remus", "renal", "renda", "renee", "renew", "renin", "renne", "rents", "renzi", "repay", "repel", "repin", "reply", "repos", "repot", "repro", "reran", "rerun", "reset", "resin", "resto", "rests", "retch", "retro", "retry", "reuse", "reuss", "revco", "revel", "revue", "reyes", "rhein", "rhett", "rhine", "rhino", "rhoda", "rhode", "rhone", "rhyme", "rhyne", "rials", "rican", "ricci", "rices", "riche", "ricin", "ricki", "ricks", "ricky", "ricoh", "rider", "rides", "ridge", "riffs", "rifle", "rifts", "rigby", "rigel", "riggs", "right", "rigid", "rigor", "rikki", "riled", "riles", "riley", "rimer", "rimes", "rinds", "ringe", "ringo", "rings", "rinks", "rinse", "rioja", "riots", "ripen", "riper", "risen", "riser", "rises", "rishi", "risks", "risky", "rites", "ritzy", "rival", "rivas", "riven", "river", "rives", "rivet", "riyal", "rizzi", "rizzo", "roach", "roads", "roams", "roars", "roast", "robbi", "robby", "robed", "rober", "robes", "robey", "robin", "roble", "robot", "robyn", "rocca", "rocco", "rocha", "roche", "rocks", "rocky", "roddy", "rodeo", "rodin", "rogan", "roger", "rogue", "rohan", "rohde", "rohit", "roils", "rojas", "roles", "rolex", "rolfe", "rolla", "rolle", "rollo", "rolls", "rolly", "roman", "romeo", "romer", "romps", "ronan", "ronco", "ronda", "ronde", "rondo", "ronin", "ronny", "roofs", "rooks", "roome", "rooms", "roomy", "roosa", "roose", "roost", "roots", "roped", "roper", "ropes", "ropey", "roque", "rosas", "rosen", "roser", "roses", "rosey", "rosie", "rosin", "rossi", "rosso", "rotan", "rotor", "rouen", "rouge", "rough", "round", "rouse", "roush", "roust", "route", "routh", "routs", "roved", "rover", "roves", "rowan", "rowdy", "rowed", "rowen", "rower", "royal", "royce", "royer", "royle", "rozen", "rozsa", "ruane", "rubel", "ruben", "rubes", "rubin", "rubio", "ruble", "rucks", "ruddy", "rudel", "ruder", "ruffs", "rufus", "rugby", "ruger", "ruing", "ruins", "ruled", "ruler", "rules", "rumba", "rumen", "rummy", "rumor", "rumps", "runes", "rungs", "runic", "runny", "runts", "runup", "rupee", "rural", "rusch", "ruses", "russe", "russo", "rusts", "rusty", "ryall", "ryans", "ryder", "ryman", "saale", "sabah", "saber", "sabha", "sabia", "sabin", "sabir", "sable", "sabra", "sabre", "sachs", "sacks", "sacra", "sacre", "sadat", "sadia", "sadie", "sadly", "saeed", "saenz", "safar", "safer", "safes", "safir", "safra", "sagan", "sagar", "sagas", "sager", "sages", "saggy", "sahib", "sails", "saint", "saith", "saito", "sakai", "saker", "sakes", "salad", "salah", "salam", "salas", "salat", "saleh", "salem", "sales", "salim", "salis", "salle", "sally", "salma", "salmi", "salon", "salsa", "salta", "salto", "salts", "salty", "salud", "salus", "salut", "salva", "salve", "salvo", "samar", "samba", "sambo", "samir", "sammy", "samoa", "samos", "sanaa", "sanda", "sande", "sandi", "sando", "sands", "sandy", "saner", "sangh", "sanka", "sanko", "sanna", "santa", "sante", "santo", "santy", "sanwa", "sanyo", "saone", "sappy", "sarah", "sarai", "saran", "sarge", "sarin", "saris", "sarma", "sarna", "saros", "sarum", "sasha", "sasse", "sassy", "satan", "sated", "sates", "satin", "satyr", "sauce", "saucy", "saudi", "sauer", "sauls", "sault", "sauna", "saute", "sauve", "savas", "saved", "saver", "saves", "savin", "savor", "savoy", "savvy", "sawed", "saxby", "saxes", "saxon", "sayed", "sayer", "sayre", "scabs", "scads", "scala", "scald", "scale", "scalp", "scaly", "scamp", "scams", "scans", "scant", "scape", "scare", "scarf", "scarp", "scars", "scary", "scats", "scene", "scent", "schon", "schuh", "scion", "scoff", "scold", "scone", "scoop", "scoot", "scope", "score", "scorn", "scots", "scott", "scour", "scout", "scowl", "scram", "scrap", "scree", "screw", "scrim", "scrip", "scrod", "scrub", "scrum", "scuba", "scuds", "scuff", "scull", "scuse", "scutt", "seale", "seals", "sealy", "seams", "seamy", "sears", "seats", "sebum", "secon", "secor", "sects", "sedan", "seder", "sedge", "sedum", "seeds", "seedy", "seeks", "seely", "seema", "seems", "seeps", "seers", "segal", "segar", "seger", "segue", "segun", "seidl", "seige", "seiji", "seiko", "seine", "seitz", "seize", "selby", "seles", "selig", "selim", "sella", "selle", "sells", "selma", "selva", "semel", "semen", "semis", "sence", "sends", "senft", "senna", "senor", "sense", "senso", "senza", "seoul", "sepia", "seppo", "septa", "serai", "serbs", "seres", "serfs", "serge", "seria", "serie", "serif", "serio", "serpa", "serra", "serum", "serve", "servo", "sessa", "seton", "setup", "seuss", "seven", "sever", "sevin", "sewed", "sewer", "sexed", "sexes", "shack", "shade", "shady", "shafi", "shaft", "shags", "shahi", "shahs", "shaka", "shake", "shaky", "shale", "shall", "shalt", "shame", "shams", "shamu", "shana", "shane", "shank", "shape", "shard", "share", "shari", "shark", "sharp", "shatt", "shaul", "shaun", "shave", "shawl", "shawn", "shaye", "shays", "she'd", "she's", "sheaf", "shear", "shedd", "sheds", "sheen", "sheep", "sheer", "sheet", "sheik", "sheil", "shelf", "shell", "shema", "sheng", "sheri", "sheth", "shi'a", "shied", "shiel", "shier", "shies", "shift", "shiga", "shill", "shims", "shine", "shing", "shins", "shiny", "shipp", "ships", "shira", "shire", "shirk", "shirl", "shirt", "shish", "shite", "shiva", "shive", "shoaf", "shoah", "shoal", "shock", "shoed", "shoes", "shoji", "shoko", "shold", "shona", "shone", "shook", "shoop", "shoos", "shoot", "shope", "shops", "shore", "shorn", "short", "shots", "shott", "shoud", "shoul", "shoup", "shout", "shove", "showa", "shown", "shows", "showy", "shred", "shrew", "shrub", "shrug", "shuck", "shuns", "shunt", "shure", "shush", "shute", "shuts", "shutt", "shyer", "shyly", "sibyl", "sicko", "sided", "sider", "sides", "sidhu", "sidle", "sidon", "siege", "siena", "sieve", "sifts", "sighs", "sight", "sigma", "signa", "signs", "sikes", "sikhs", "silas", "silex", "silks", "silky", "sills", "silly", "silos", "silty", "silva", "simba", "simms", "simon", "simul", "sinai", "sinar", "since", "sinew", "singe", "singh", "sings", "sinha", "sinks", "sinus", "sioux", "sired", "siren", "sires", "siris", "sirri", "sisal", "sissy", "sisto", "sitar", "sited", "sites", "situs", "six's", "sixer", "sixes", "sixth", "sixty", "sized", "sizer", "sizes", "skate", "skeet", "skein", "skene", "skews", "skids", "skied", "skier", "skies", "skiff", "skill", "skimp", "skims", "skins", "skips", "skirt", "skits", "sklar", "skoal", "skuas", "skulk", "skull", "skunk", "sky's", "slabs", "slack", "slade", "slags", "slain", "slake", "slams", "slane", "slang", "slant", "slaps", "slash", "slate", "slats", "slava", "slave", "slavs", "slays", "sleds", "sleek", "sleep", "sleet", "slept", "slews", "slice", "slick", "slide", "sligo", "slime", "slims", "slimy", "sling", "slink", "slips", "slits", "sloan", "sloat", "slobs", "slone", "sloop", "slope", "slops", "slosh", "sloth", "slots", "slows", "slugs", "slump", "slums", "slung", "slunk", "slurp", "slurs", "slush", "sluts", "slyly", "smack", "small", "smart", "smash", "smeal", "smear", "smell", "smelt", "smile", "smirk", "smite", "smith", "smits", "smock", "smoke", "smoky", "smoot", "smote", "smurf", "smuts", "smyth", "snack", "snafu", "snags", "snail", "snake", "snaky", "snape", "snaps", "snare", "snarf", "snark", "snarl", "snead", "sneak", "sneed", "sneer", "snell", "snick", "snide", "sniff", "snipe", "snips", "snobs", "snood", "snook", "snoop", "snoot", "snore", "snort", "snout", "snowe", "snows", "snowy", "snubs", "snuck", "snuff", "soaks", "soaps", "soapy", "soars", "soave", "sobek", "sobel", "sober", "sobre", "sochi", "socio", "socks", "sodas", "sodom", "sofar", "sofas", "sofer", "sofia", "sofie", "softy", "soggy", "soils", "sokol", "solan", "solar", "soled", "soler", "soles", "soley", "solid", "solis", "solly", "solon", "solos", "solow", "solve", "somer", "somes", "somma", "son's", "sonar", "sones", "sonet", "songs", "songy", "sonia", "sonic", "sonja", "sonne", "sonny", "sonya", "soong", "soooo", "sooth", "sooty", "soper", "sophy", "soppy", "sorel", "sores", "soria", "sorin", "soros", "sorry", "sorta", "sorts", "sough", "soule", "souls", "sound", "soups", "soupy", "sours", "sousa", "south", "souza", "sowed", "sower", "space", "spacy", "spade", "spahn", "spain", "spake", "spall", "spang", "spank", "spann", "spano", "spans", "sparc", "spare", "spark", "spars", "spasm", "spate", "spats", "spawn", "speak", "spear", "speck", "specs", "spect", "speed", "speer", "speke", "spell", "spelt", "spend", "spent", "sperm", "spero", "spews", "spica", "spice", "spick", "spicy", "spied", "spiel", "spier", "spies", "spiff", "spike", "spiky", "spill", "spilt", "spina", "spine", "spink", "spins", "spiny", "spire", "spiro", "spite", "spits", "spitz", "splat", "splay", "split", "spock", "spoil", "spoke", "spong", "spoof", "spook", "spool", "spoon", "spoor", "spore", "sport", "spots", "spout", "sprat", "spray", "spree", "sprig", "sprit", "sprue", "spuds", "spunk", "spurn", "spurr", "spurs", "spurt", "squab", "squad", "squat", "squaw", "squib", "squid", "staab", "staat", "stabs", "stace", "stack", "stacy", "stade", "stadt", "staff", "stage", "stagg", "stags", "staid", "stain", "stair", "stake", "stale", "stalk", "stall", "stamm", "stamp", "stand", "stang", "stank", "staph", "stapp", "stare", "stark", "starr", "stars", "start", "stary", "stash", "stasi", "state", "stats", "staub", "stave", "stays", "stead", "steak", "steal", "steam", "stear", "steed", "steel", "steen", "steep", "steer", "steet", "stein", "stela", "stele", "stell", "stems", "stena", "steno", "stent", "steny", "steph", "stepp", "steps", "stern", "steve", "stews", "steyn", "stich", "stick", "sties", "stiff", "stile", "still", "stilt", "stine", "sting", "stink", "stint", "stipe", "stirs", "stith", "stock", "stoic", "stoke", "stole", "stoll", "stomp", "stone", "stong", "stony", "stood", "stool", "stoop", "stops", "store", "stork", "storm", "story", "stott", "stout", "stove", "stowe", "stows", "strap", "straw", "stray", "strep", "strew", "strip", "strom", "strop", "strub", "strum", "strut", "stubs", "stuck", "stude", "studs", "study", "stuff", "stull", "stump", "stung", "stunk", "stuns", "stunt", "stupa", "sturm", "style", "styli", "suave", "suber", "subic", "sucks", "sucky", "sucre", "sudan", "sudsy", "suede", "suess", "sugar", "suggs", "suing", "suite", "suits", "sulfa", "sulks", "sulky", "sulla", "sully", "sumac", "sumer", "summa", "sumps", "sun's", "sunde", "sunil", "sunna", "sunni", "sunny", "sunup", "super", "supra", "surat", "surer", "surfs", "surge", "surly", "surma", "surry", "surya", "susan", "sushi", "susie", "sutor", "sutra", "sutro", "suzie", "swabs", "swags", "swain", "swale", "swami", "swamp", "swank", "swann", "swans", "swaps", "sward", "swarm", "swart", "swash", "swath", "swats", "sways", "swazi", "swear", "sweat", "swede", "sweep", "sweet", "swell", "swept", "swick", "swift", "swigs", "swill", "swims", "swine", "swing", "swipe", "swire", "swirl", "swish", "swiss", "swith", "swoon", "swoop", "swope", "sword", "swore", "sworn", "swung", "sybil", "sykes", "sylla", "sylph", "sylva", "symes", "synch", "syncs", "synod", "synth", "syrah", "syria", "syrup", "sytem", "szabo", "tabby", "tabla", "table", "taboo", "tabor", "tache", "tacit", "tacks", "tacky", "tacos", "taffy", "tagle", "tagus", "taher", "tahoe", "taiga", "taiko", "tails", "taint", "tajik", "takao", "taken", "taker", "takes", "takin", "talal", "taler", "tales", "talia", "talks", "talky", "tally", "talon", "talus", "tamar", "tamas", "tambo", "tamed", "tamer", "tames", "tamez", "tamil", "tamim", "tammy", "tampa", "tange", "tango", "tangs", "tangy", "tania", "tanka", "tanks", "tanto", "tanya", "tapas", "taped", "taper", "tapes", "tapia", "tapir", "tapis", "taras", "tarde", "tardy", "targe", "tarin", "tariq", "tarot", "tarps", "tarry", "tarte", "tarts", "tasca", "taser", "tasha", "tasks", "tasso", "taste", "tasty", "tatar", "tater", "tatoo", "tatra", "tatty", "tatum", "taube", "taunt", "taupe", "tawny", "taxed", "taxes", "taxis", "taxol", "teach", "teale", "teams", "tears", "teary", "tease", "teats", "techs", "techy", "teddy", "teems", "teena", "teens", "teeny", "teeth", "tejas", "tejon", "telco", "teles", "telex", "tells", "telly", "telos", "tempe", "tempi", "tempo", "temps", "tempt", "ten's", "tench", "tends", "tenet", "tenor", "tense", "tenth", "tents", "tepee", "tepid", "terai", "terex", "terje", "terme", "terms", "terns", "terra", "terre", "terri", "terry", "terse", "tesco", "tesla", "tessa", "testa", "tests", "testy", "teton", "tetra", "texan", "texas", "texts", "thabo", "thais", "thane", "thang", "thanh", "thank", "thanx", "tharp", "thats", "thaws", "theat", "theft", "thein", "their", "theis", "thema", "theme", "there", "therm", "these", "theta", "thick", "thief", "thiel", "thier", "thigh", "thine", "thing", "think", "thins", "third", "thole", "thome", "thoms", "thone", "thong", "thora", "thorn", "thorp", "those", "thous", "three", "threw", "thrid", "throb", "throw", "thuds", "thugs", "thule", "thumb", "thump", "thunk", "thurs", "thyme", "tiara", "tibbs", "tiber", "tibet", "tibia", "tichy", "ticks", "ticky", "tidal", "tided", "tides", "tiene", "tiers", "tiffs", "tiger", "tighe", "tight", "tikes", "tikka", "tilak", "tilda", "tilde", "tiled", "tiles", "tills", "tilly", "tilth", "tilts", "timed", "timer", "times", "timet", "timex", "timid", "timmy", "timon", "timor", "tiner", "tines", "tinge", "tings", "tinny", "tinto", "tints", "tions", "tippy", "tipsy", "tired", "tires", "tirol", "tisch", "titan", "tithe", "title", "titus", "tizzy", "toads", "toady", "toast", "tobey", "tobin", "todas", "today", "toddy", "todos", "togas", "toils", "toity", "tokai", "tokay", "token", "tokes", "tokio", "tokyo", "tolan", "tolar", "tolls", "toman", "tomas", "tombs", "tomei", "tomes", "tommy", "tomsk", "tonal", "tondo", "toned", "toner", "tones", "toney", "tonga", "tongs", "tonia", "tonic", "tonka", "tonks", "tonne", "tonto", "tonya", "tonys", "toole", "tools", "toons", "tooth", "toots", "topaz", "topic", "topix", "topps", "toppy", "topsy", "toque", "torah", "toral", "torch", "toros", "torre", "torri", "torso", "torta", "torte", "torts", "torus", "tosca", "total", "toted", "totem", "totes", "tothe", "totty", "touch", "tough", "tours", "touse", "touts", "tovar", "towed", "towel", "tower", "towne", "towns", "toxic", "toxin", "toyed", "tozer", "tozzi", "trace", "traci", "track", "tract", "tracy", "trade", "trail", "train", "trait", "tramp", "trams", "trang", "trani", "trans", "trapp", "traps", "trash", "trask", "traub", "trawl", "trays", "tread", "treas", "treat", "treed", "treen", "trees", "trejo", "treks", "trend", "trent", "tress", "treys", "triad", "trial", "tribe", "trice", "trick", "tried", "trier", "tries", "trigg", "trigo", "trill", "trims", "trina", "trine", "tring", "trios", "tripe", "tripp", "trips", "trish", "trist", "trite", "tritt", "trois", "troll", "tromp", "trone", "troon", "troop", "trope", "trost", "troth", "trots", "trott", "trout", "trove", "truce", "truck", "trudy", "truer", "trull", "truly", "trump", "trunk", "truro", "truss", "trust", "truth", "tryon", "tryst", "tubal", "tubas", "tubbs", "tubby", "tubed", "tuber", "tubes", "tucks", "tudor", "tufte", "tufts", "tulip", "tulle", "tully", "tulsa", "tummy", "tumor", "tunas", "tunde", "tuned", "tuner", "tunes", "tunic", "tunis", "tuohy", "tupac", "turbo", "turco", "turds", "turfs", "turin", "turki", "turks", "turns", "turow", "turvy", "tusks", "tutor", "tutsi", "tutti", "tutto", "tutus", "tuzla", "twain", "twang", "tweak", "tweed", "tween", "tweet", "twerp", "twice", "twigs", "twill", "twine", "twins", "twirl", "twist", "twits", "twixt", "two's", "tyger", "tying", "tykes", "tyler", "tynes", "typed", "types", "typos", "tyree", "tyres", "tyros", "tyson", "udder", "uddin", "udell", "udine", "ueber", "ugric", "ulcer", "ulema", "ulman", "ulnar", "ulric", "ultra", "umber", "umbra", "uncle", "uncut", "under", "undid", "undue", "unfed", "unfit", "ungar", "unger", "unhip", "unico", "unify", "union", "unita", "unite", "units", "unity", "unlit", "unmet", "unruh", "unser", "unset", "untie", "until", "unwed", "unzip", "upend", "upham", "upped", "upper", "upset", "upson", "upton", "urals", "urban", "urged", "urges", "uribe", "urich", "uriel", "urine", "ursus", "usage", "usaid", "users", "usher", "using", "usman", "usted", "usual", "usurp", "usury", "uteri", "utero", "utica", "utils", "utley", "utter", "uvula", "uzbek", "vader", "vadim", "vague", "vajra", "valeo", "vales", "valet", "valid", "valle", "valor", "value", "valve", "vamos", "vamps", "vance", "vanda", "vanek", "vanes", "vanya", "vapid", "vapor", "varga", "vargo", "varna", "vasco", "vases", "vasey", "vault", "veale", "vedic", "veers", "vegan", "vegas", "veiga", "veils", "veins", "veldt", "velez", "velma", "venal", "venom", "venta", "venti", "vento", "vents", "venue", "venus", "verbs", "verde", "verdi", "verge", "verma", "verna", "verne", "veron", "verry", "versa", "verse", "verso", "verts", "verve", "vesey", "vespa", "vesta", "vests", "vetch", "vette", "veuve", "vexed", "vexes", "vials", "vibes", "vicar", "vices", "vichy", "vicki", "vicks", "vicky", "vidal", "video", "vidor", "viens", "views", "vigil", "vigna", "vigor", "vikas", "vikki", "vilas", "viles", "villa", "ville", "villi", "vinal", "vinay", "vinca", "vince", "vinci", "viner", "vines", "vinny", "vinyl", "viola", "viper", "viral", "vires", "virga", "virgo", "virus", "visas", "visio", "visit", "visor", "vista", "vitae", "vital", "vitro", "vitry", "vivas", "vives", "vivid", "vixen", "vocal", "vodka", "vogel", "vogue", "voice", "voids", "voigt", "voila", "voile", "voles", "volga", "volpe", "volpi", "volta", "volte", "volts", "volvo", "vomit", "voted", "voter", "votes", "votre", "vouch", "vowed", "vowel", "vries", "vroom", "vulva", "vying", "wachs", "wacko", "wacks", "wacky", "waddy", "waded", "wader", "wades", "wafer", "wafts", "waged", "wager", "wages", "wagga", "wagon", "wahid", "wahoo", "waifs", "wails", "waist", "waite", "waits", "waive", "waked", "waken", "wakes", "walde", "waldo", "wales", "walke", "walks", "walla", "walls", "wally", "walsh", "waltz", "wanda", "wands", "waned", "wanes", "wanna", "wants", "wards", "wares", "warms", "warns", "warps", "warts", "warty", "washy", "wasnt", "wason", "wasps", "waste", "watch", "water", "watts", "waugh", "waved", "waver", "waves", "waxed", "waxen", "waxer", "waxes", "wayne", "wazir", "wazoo", "we'll", "we're", "we've", "weans", "weare", "wears", "weary", "weave", "webby", "weber", "wedel", "wedge", "weeds", "weedy", "weeks", "weems", "weeny", "weeps", "weepy", "weigh", "weill", "weird", "weirs", "weise", "weiss", "weith", "weitz", "welby", "welch", "welds", "welle", "wells", "welsh", "welts", "welty", "wench", "wende", "wends", "wendt", "wendy", "wente", "werke", "wests", "whack", "whale", "whang", "wharf", "whats", "wheat", "wheel", "whelp", "where", "whets", "which", "whiff", "whigs", "while", "whims", "whine", "whiny", "whips", "whirl", "whish", "whisk", "whist", "white", "whitt", "whizz", "who'd", "who's", "whole", "whoop", "whore", "whorl", "whose", "whump", "why's", "whyte", "wicca", "wicks", "widen", "wider", "wides", "widow", "width", "wieck", "wield", "wierd", "wiest", "wigan", "wiggs", "wiggy", "wight", "wilco", "wilde", "wilds", "wiles", "wiley", "wilke", "wilks", "willa", "willi", "willl", "wills", "willy", "wilma", "wilts", "wimps", "wimpy", "wince", "winch", "winds", "windy", "wined", "winer", "wines", "winey", "wings", "winks", "winos", "wiped", "wiper", "wipes", "wired", "wires", "wirth", "wirtz", "wised", "wiser", "wishy", "wisps", "wispy", "witch", "witha", "withe", "witty", "wives", "wogan", "woken", "wolds", "wolfe", "wolff", "woman", "wombs", "women", "won't", "wonks", "wonky", "woods", "woody", "wooed", "woolf", "wools", "wooly", "woops", "woozy", "words", "wordy", "works", "world", "worms", "wormy", "worry", "worse", "worst", "worth", "worts", "would", "wound", "woven", "wowed", "wrack", "wraps", "wrath", "wreak", "wreck", "wrens", "wrest", "wring", "wrist", "write", "writs", "wrong", "wrote", "wrung", "wryly", "wuhan", "wulff", "wurst", "wurtz", "wyatt", "wyche", "wyden", "wyeth", "wylie", "wyman", "wynne", "wynns", "wythe", "xenia", "xenon", "xerox", "y'all", "ya'll", "yacht", "yager", "yahoo", "yalta", "yanbu", "yanks", "yards", "yarns", "yaron", "yarra", "yasin", "yasir", "yates", "yawns", "yazoo", "yearn", "years", "yeast", "yeats", "yells", "yelps", "yemen", "yenta", "yerba", "yeung", "yield", "yikes", "yodel", "yoder", "yogic", "yogis", "yoked", "yokel", "yokes", "yolks", "yonge", "yoram", "yorke", "yorks", "yoshi", "yossi", "you'd", "young", "youre", "yours", "youse", "youth", "yucca", "yucky", "yukon", "yummy", "yurts", "yuval", "zacks", "zaher", "zahir", "zaire", "zakat", "zaman", "zandt", "zappa", "zayed", "zebra", "zeiss", "zeitz", "zelda", "zelma", "zeman", "zemin", "zemke", "zeros", "zesty", "zhang", "zheng", "zilch", "zines", "zingy", "zippo", "zippy", "zloty", "zogby", "zonal", "zoned", "zones", "zoo's", "zooms", "zorba", "zorro", "zowie", "zuber", "zulus", "zweig", "zwick"];

function deleteRow1() {
    xStart = 0;
    yStart = 0;
    rowDeleting = 1;

    console.log(xStart)
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    console.log(xStart)
    letterPlace_Y += 70;

    mainEnter();
}


function deleteRow2() {
    xStart = 0;
    yStart = 70;
    rowDeleting = 2;

    console.log(xStart)
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    console.log(xStart)
    letterPlace_Y += 70;

    mainEnter();
}

function deleteRow3() {
    xStart = 0;
    yStart = 140;
    rowDeleting = 3;

    console.log(xStart)
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    console.log(xStart)
    letterPlace_Y += 70;

    mainEnter();
}

function deleteRow4() {
    xStart = 0;
    yStart = 210;
    rowDeleting = 4;

    console.log(xStart)
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    console.log(xStart)
    letterPlace_Y += 70;

    mainEnter();
}

function deleteRow5() {
    xStart = 0;
    yStart = 280;
    rowDeleting = 5;

    console.log(xStart)
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    console.log(xStart)
    letterPlace_Y += 70;

    mainEnter();
}


function getLettersInAnswer() {
    do {
        lettersInAnswerHelp2 = wordAnswer.slice(lettersInAnswerHelp - 1, lettersInAnswerHelp)
        lettersInAnswer.push(lettersInAnswerHelp2)
        lettersInAnswerHelp += 1;
    }
    while (lettersInAnswerHelp < 6)

}

function popUpf() {
    var popup = document.getElementById("myPopup");
    popup.classList.toggle("show");
}

getLettersInAnswer();


function squares() {

    do {

        xStart = 0;

        console.log(xStart)
        c.fillStyle = "gainsboro";
        c.fillRect(xStart, yStart, 50, 50)
        xStart += 60;
        c.fillStyle = "gainsboro";
        c.fillRect(xStart, yStart, 50, 50)
        console.log(xStart)
        xStart += 60;
        c.fillStyle = "gainsboro";
        c.fillRect(xStart, yStart, 50, 50)
        console.log(xStart)
        xStart += 60;
        c.fillStyle = "gainsboro";
        c.fillRect(xStart, yStart, 50, 50)
        console.log(xStart)
        xStart += 60;
        c.fillStyle = "gainsboro";
        c.fillRect(xStart, yStart, 50, 50)
        console.log(xStart)
        yStart += 70;

    }
    while (yStart < 350);
}

squares();


console.log(letterPlace_X)

function x_place() {
    console.log(letterNum)
    letterNum += 1;
    if (letterNum == 1) {
        letterPlace_X = 25;
        console.log(letterPlace_X);

    } else if (letterNum == 2) {
        letterPlace_X = 85;
    } else if (letterNum == 3) {
        letterPlace_X = 145;
    } else if (letterNum == 4) {
        letterPlace_X = 205;
    } else if (letterNum == 5) {
        letterPlace_X = 265;
    }
    console.log(letterPlace_X);
    lettersTyped += 1;
}

function x_placeBackspace() {
    if (letterNum == 1) {
        letterPlace_X = 25;
        console.log(letterPlace_X);

    } else if (letterNum == 2) {
        letterPlace_X = 85;
    } else if (letterNum == 3) {
        letterPlace_X = 145;
    } else if (letterNum == 4) {
        letterPlace_X = 205;
    } else if (letterNum == 5) {
        letterPlace_X = 265;
    }
    console.log(letterPlace_X);
}

function findDate() {
    do {
        dateNumbers.push(date.charAt(dateFinder))
        dateFinder += 1;
    }
    while (dateFinder < 11)
}

function mainEnter() {
    mainEnterHelp = "";
    mainEnterHelp2 = 0;
    mainEnterHelp3 = 1;
    stringTypedHelp = 0;
    stringTyped = lettersPutIn.join("");
    if (allWords.includes(stringTyped)) {

        do {
            console.log("mainEnter")
            mainEnterHelp = lettersPutIn[mainEnterHelp2];
            if (lettersInAnswer.includes(mainEnterHelp)) {
                if (lettersPutIn[mainEnterHelp2] == lettersInAnswer[mainEnterHelp2]) {
                    colorsInRow.push("green")
                } else {
                    colorsInRow.push("yellow")
                }
            } else {
                colorsInRow.push("red")
            }
            mainEnterHelp2 += 1;
        }
        while (mainEnterHelp2 < 5)
        coloredRewrite();
    } else {
        error();
        letterNum = 1;
        lettersTyped = 0;
        letterPlace_X = 25;
        lettersPutIn = [];
        colorsInRow = [];
        letterPlace_Y -= 70;
    }
}

function coloredRewrite() {
  tries += 1;
  console.log("coloredRewrite")
  coloredRewriteHelp2 = 0;
  coloredRewriteHelp = "";
  coloredRewriteHelp3 = "";
  coloredRewriteHelp4 = "";
  letterPlace_XSave = 25;
  do {
      coloredRewriteHelp = colorsInRow[coloredRewriteHelp2];
      coloredRewriteHelp3 = lettersPutIn[coloredRewriteHelp2];
      coloredRewriteHelp4 = coloredRewriteHelp3.toUpperCase();
      c.font = "30px Roboto";
      c.fillStyle = coloredRewriteHelp;
      c.textAlign = "center";
      c.fillText(coloredRewriteHelp4, letterPlace_XSave, letterPlace_YSave);
      coloredRewriteHelp2 += 1;
      letterPlace_XSave += 60;
      colorsInAll.push(coloredRewriteHelp)
  }
  while (coloredRewriteHelp2 < 5)

  gameFinished();
}

function nextRow() {
    letterNum = 1;
    lettersTyped = 0;
    letterPlace_X = 25;
    lettersPutIn = [];
    colorsInRow = [];
}

function gameFinished() {
    if (colorsInRow.includes("red")) {
        nextRow();
        if (tries == 5) {
            youLost();
        }
    } else if (colorsInRow.includes("yellow")) {
        nextRow();
        if (tries == 5) {
            youLost();
        }
    } else {
        clearCanvas();
    }

}

function youWin() {
    c.fillStyle = "gainsboro";
    c.fillRect(25, 0, 250, 300)
    c.font = "35px Quicksand";
    c.fillStyle = "green";
    c.textAlign = "center";
    c.fillText("You Win", 150, 35);
    c.font = "15px Roboto";
    c.fillStyle = "black";
    c.textAlign = "center";
    c.fillText("Number of tries: " + tries, 100, 75);
    // localStorage.setItem("try", tries); 
    c.fillText("Everyday there is a new word,", 150, 250);
    c.fillText("check in daily", 150, 280);
    playedToday = date2;
    streak += 1;
    gamesPlayed += 1;
    c.fillText("Scroll All The Way Down To Share", 150, 150);
    c.fillText("Streak: " + streak, 75, 100);
    c.fillText("Games Played: " + gamesPlayed, 100, 125);
    setCookie("streak", streak, 365);
    setCookie("gamesplayed", gamesPlayed, 365);
    setCookie("playedtoday", playedToday, 365);
}

function youLost() {
    c.fillStyle = "gainsboro";
    c.fillRect(0, 0, 400, 400)
    c.font = "35px Quicksand";
    c.fillStyle = "red";
    c.textAlign = "center";
    c.fillText("You Lost", 150, 35);
    c.font = "15px Roboto";
    c.fillStyle = "black";
    c.textAlign = "center";
    c.fillText("Number of tries: " + tries, 100, 75);
    c.fillText("Everyday there is a new word, check in daily", 150, 250);
    playedToday = date2;
    streak = 0;
    gamesPlayed += 1;
    c.fillText("Scroll All The Way Down To Share", 150, 150);
    c.fillText("Streak", 75, 75);
    setCookie("gamesplayed", gamesPlayed, 365);
    setCookie("streak", streak, 365);
    setCookie("playedtoday", playedToday, 365);
}

function clearCanvas() {
    window.setTimeout(nothing, 2500)
    c.fillStyle = "white";
    c.fillRect(0, 0, 400, 400)
    youWin();
}

function share() {
    colorEmojis();
    console.log('--->>> share blah');
}

function addStr(str, index, stringToAdd) {
    return str.substring(0, index) + stringToAdd + str.substring(index, str.length);
}

function colorEmojis() {
    colorEmojisHelp = 0;
    resultString = "";
    do {
        var nextChar = "";
        if (colorsInAll[colorEmojisHelp] == "green") {
            nextChar = "🟩";
        } else if (colorsInAll[colorEmojisHelp] == "yellow") {
            nextChar = "🟨";
        } else {
            nextChar = "🟥";
        }
        if (colorEmojisHelp % 5 == 0) {
            resultString += "\n \n";
        } else {
            resultString += " ";
        }
        resultString += nextChar;
        colorEmojisHelp += 1;
    } while (colorEmojisHelp < (tries * 5))
    colorEmojisHelp = 0;

    navigator.clipboard.writeText("I won on normal mode: \n" + resultString + "\n https://iamibrahim510.repl.co/ \n Tries:" + tries + "/5" + "\n Wordier")
    alert("Copied to Clipboard");
}

function alreadyPlayed() {
  c.fillStyle = "gainsboro";
    c.fillRect(0, 0, 400, 400)
    c.font = "25px Quicksand";
    c.fillStyle = "green";
    c.textAlign = "center";
    c.fillText("You've already played today", 200, 35);
    c.font = "20px Quicksand";
    c.fillStyle = "black";
    c.textAlign = "center";
    // localStorage.setItem("try", tries); 
    c.fillText("Everyday there is a new word,", 150, 250);
    c.fillText("check in daily", 150, 280);
}

// keyboard:

function q() {
    if (lettersTyped < 5) {
        c.globalCompositeOperation = 'source-over';
        c.font = "30px Roboto";
        c.fillStyle = letterColor;
        c.textAlign = "center";
        c.fillText("Q", letterPlace_X, letterPlace_Y);
        x_place();
        lettersPutIn.push(letter)
        console.log("534")
    }
}

function w() {
    if (lettersTyped < 5) {
        c.globalCompositeOperation = 'source-over';
        c.font = "30px Roboto";
        c.fillStyle = letterColor;
        c.textAlign = "center";
        c.fillText("W", letterPlace_X, letterPlace_Y);
        x_place();
        lettersPutIn.push("w")
    }
}

function e() {
    if (lettersTyped < 5) {
        c.globalCompositeOperation = 'source-over';
        c.font = "30px Roboto";
        c.fillStyle = letterColor;
        c.textAlign = "center";
        c.fillText("E", letterPlace_X, letterPlace_Y);
        x_place();
        lettersPutIn.push("e")
    }
}

function r() {
    if (lettersTyped < 5) {
        c.globalCompositeOperation = 'source-over';
        c.font = "30px Roboto";
        c.fillStyle = letterColor;
        c.textAlign = "center";
        c.fillText("R", letterPlace_X, letterPlace_Y);
        x_place();
        lettersPutIn.push("r")
    }
}

function t() {
    if (lettersTyped < 5) {
        c.globalCompositeOperation = 'source-over';
        c.font = "30px Roboto";
        c.fillStyle = letterColor;
        c.textAlign = "center";
        c.fillText("T", letterPlace_X, letterPlace_Y);
        console.log("t")
        x_place();
        lettersPutIn.push("t")
    }
}

function y() {
    if (lettersTyped < 5) {
        c.globalCompositeOperation = 'source-over';
        c.font = "30px Roboto";
        c.fillStyle = letterColor;
        c.textAlign = "center";
        c.fillText("Y", letterPlace_X, letterPlace_Y);
        x_place();
        lettersPutIn.push("y")
    }
}

function u() {
    if (lettersTyped < 5) {
        c.globalCompositeOperation = 'source-over';
        c.font = "30px Roboto";
        c.fillStyle = letterColor;
        c.textAlign = "center";
        c.fillText("U", letterPlace_X, letterPlace_Y);
        x_place();
        lettersPutIn.push("u")
    }
}

function i() {
    if (lettersTyped < 5) {
        c.globalCompositeOperation = 'source-over';
        c.font = "30px Roboto";
        c.fillStyle = letterColor;
        c.textAlign = "center";
        c.fillText("I", letterPlace_X, letterPlace_Y);
        x_place();
        lettersPutIn.push("i")
    }
}

function o() {
    if (lettersTyped < 5) {
        c.globalCompositeOperation = 'source-over';
        c.font = "30px Roboto";
        c.fillStyle = letterColor;
        c.textAlign = "center";
        c.fillText("O", letterPlace_X, letterPlace_Y);
        x_place();
        lettersPutIn.push("o")
    }
}

function p() {
    if (lettersTyped < 5) {
        c.globalCompositeOperation = 'source-over';
        c.font = "30px Roboto";
        c.fillStyle = letterColor;
        c.textAlign = "center";
        c.fillText("P", letterPlace_X, letterPlace_Y);
        x_place();
        lettersPutIn.push("p")
    }
}

function a() {
    if (lettersTyped < 5) {
        c.globalCompositeOperation = 'source-over';
        c.font = "30px Roboto";
        c.fillStyle = letterColor;
        c.textAlign = "center";
        c.fillText("A", letterPlace_X, letterPlace_Y);
        x_place();
        lettersPutIn.push("a");
    }
}

function s() {
    if (lettersTyped < 5) {
        c.globalCompositeOperation = 'source-over';
        c.font = "30px Roboto";
        c.fillStyle = letterColor;
        c.textAlign = "center";
        c.fillText("S", letterPlace_X, letterPlace_Y);
        x_place();
        lettersPutIn.push("s")
    }
}

function d() {
    if (lettersTyped < 5) {
        c.globalCompositeOperation = 'source-over';
        c.font = "30px Roboto";
        c.fillStyle = letterColor;
        c.textAlign = "center";
        c.fillText("D", letterPlace_X, letterPlace_Y);
        x_place();
        lettersPutIn.push("d")
    }
}

function f() {
    if (lettersTyped < 5) {
        c.globalCompositeOperation = 'source-over';
        c.font = "30px Roboto";
        c.fillStyle = letterColor;
        c.textAlign = "center";
        c.fillText("F", letterPlace_X, letterPlace_Y);
        x_place();
        lettersPutIn.push("f")
    }
}

function g() {
    if (lettersTyped < 5) {
        c.globalCompositeOperation = 'source-over';
        c.font = "30px Roboto";
        c.fillStyle = letterColor;
        c.textAlign = "center";
        c.fillText("G", letterPlace_X, letterPlace_Y);
        x_place();
        lettersPutIn.push("g")
    }
}

function h() {
    if (lettersTyped < 5) {
        c.globalCompositeOperation = 'source-over';
        c.font = "30px Roboto";
        c.fillStyle = letterColor;
        c.textAlign = "center";
        c.fillText("H", letterPlace_X, letterPlace_Y);
        x_place();
        lettersPutIn.push("h")
    }
}


function j() {
    if (lettersTyped < 5) {
        c.globalCompositeOperation = 'source-over';
        c.font = "30px Roboto";
        c.fillStyle = letterColor;
        c.textAlign = "center";
        c.fillText("J", letterPlace_X, letterPlace_Y);
        x_place();
        lettersPutIn.push("j")
    }
}


function k() {
    if (lettersTyped < 5) {
        c.globalCompositeOperation = 'source-over';
        c.font = "30px Roboto";
        c.fillStyle = letterColor;
        c.textAlign = "center";
        c.fillText("K", letterPlace_X, letterPlace_Y);
        x_place();
        lettersPutIn.push("k")
    }
}


function l() {
    if (lettersTyped < 5) {
        c.globalCompositeOperation = 'source-over';
        c.font = "30px Roboto";
        c.fillStyle = letterColor;
        c.textAlign = "center";
        c.fillText("L", letterPlace_X, letterPlace_Y);
        x_place();
        lettersPutIn.push("l")
    }
}

function backspace() {
    console.log(lettersTyped)
    if (lettersTyped >= 1) {
        backspaceX = ((letterNum * 60) - 120)
        c.fillStyle = "gainsboro";
        c.fillRect(backspaceX, letterPlace_Y - 35, 50, 50);
        lettersPutIn.pop();
        letterNum = letterNum - 1;
        lettersTyped -= 1;
        x_placeBackspace();
    }
}


function z() {
    if (lettersTyped < 5) {
        c.globalCompositeOperation = 'source-over';
        c.font = "30px Roboto";
        c.fillStyle = letterColor;
        c.textAlign = "center";
        c.fillText("Z", letterPlace_X, letterPlace_Y);
        x_place();
        lettersPutIn.push("z")
    }
}


function x() {
    if (lettersTyped < 5) {
        c.globalCompositeOperation = 'source-over';
        c.font = "30px Roboto";
        c.fillStyle = letterColor;
        c.textAlign = "center";
        c.fillText("X", letterPlace_X, letterPlace_Y);
        x_place();
        lettersPutIn.push("x")
    }
}


function cT() {
    if (lettersTyped < 5) {
        c.globalCompositeOperation = 'source-over';
        c.font = "30px Roboto";
        c.fillStyle = letterColor;
        c.textAlign = "center";
        c.fillText("C", letterPlace_X, letterPlace_Y);
        x_place();
        lettersPutIn.push("c")
    }
}


function v() {
    if (lettersTyped < 5) {
        c.globalCompositeOperation = 'source-over';
        c.font = "30px Roboto";
        c.fillStyle = letterColor;
        c.textAlign = "center";
        c.fillText("V", letterPlace_X, letterPlace_Y);
        x_place();
        lettersPutIn.push("v")
    }
}


function b() {
    if (lettersTyped < 5) {
        c.globalCompositeOperation = 'source-over';
        c.font = "30px Roboto";
        c.fillStyle = letterColor;
        c.textAlign = "center";
        c.fillText("B", letterPlace_X, letterPlace_Y);
        x_place();
        lettersPutIn.push("b")
    }
}


function n() {
    if (lettersTyped < 5) {
        c.globalCompositeOperation = 'source-over';
        c.font = "30px Roboto";
        c.fillStyle = letterColor;
        c.textAlign = "center";
        c.fillText("N", letterPlace_X, letterPlace_Y);
        x_place();
        lettersPutIn.push("n")
    }
}


function m() {
    if (lettersTyped < 5) {
        c.globalCompositeOperation = 'source-over';
        c.font = "30px Roboto";
        c.fillStyle = letterColor;
        c.textAlign = "center";
        c.fillText("M", letterPlace_X, letterPlace_Y);
        x_place();
        lettersPutIn.push("m")
    }
}

function enter() {
    if (lettersTyped != 5) {
        error();
    } else {
        letterPlace_XSave = letterPlace_X;
        letterPlace_YSave = letterPlace_Y;
        if (letterPlace_Y == 35) {
            deleteRow1();
        } else if (letterPlace_Y == 105) {
            deleteRow2();
        } else if (letterPlace_Y == 175) {
            deleteRow3();
        } else if (letterPlace_Y == 245) {
            deleteRow4();
        } else if (letterPlace_Y == 315) {
            deleteRow5();
        }
    }
    window.setTimeout(nothing, 2500);
}

function error() {
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Roboto";
    c.fillStyle = 'red';
    c.textAlign = "center";
    c.fillText("Error", 350, 175);
    window.setTimeout(eraseError, 2500);
}

function eraseError() {
    c.fillStyle = "white";
    c.fillRect(300, 100, 150, 150)
}

function nothing() {

}


// cookie Junk:


function setCookie(name, value, days) {
    var expires = "";
    if (days) {
        var date5 = new Date();
        date5.setTime(date5.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date5.toUTCString();
    }
    document.cookie = name + "=" + (value || "") + expires + "; path=/";
}

function getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' '){ c = c.substring(1, c.length);}
        if (c.indexOf(nameEQ) == 0) {return c.substring(nameEQ.length, c.length);}
    }
    return "";
}

function checkCookie() {
  let checkCode = getCookie("streak");
  let checkCode2 = getCookie("gamesPlayed");
  let checkCode3 = getCookie("playedtoday");
  if (getCookie("streak") === "") {
      console.log(checkCode)
      // alert("new")
      streak = 0;
      // setCookie("streak", "0", 365);
  } else {
    // reading the cookie
    streak = parseInt(checkCode);
  }
  if (getCookie("gamesplayed") === "") {
    
    console.log(checkCode2)
    // alert("new")
    gamesPlayed = 0;
    window.setTimeout(popUpf, 1000)
    // setCookie("gamesplayed", 0, 365);
  } else {
    // reading the cookie
    checkCode2 = getCookie("gamesplayed");
    console.log(checkCode2);
    gamesPlayed = parseInt(checkCode2);
  }
  if (getCookie("playedtoday") === "") {
    
    console.log(checkCode3)
    // alert("new")
    gamesPlayed = 0;
    // setCookie("playedtoday", "0", 365);
  } else {
    // reading the cookie
    checkCode3 = getCookie("playedtoday");
    console.log(checkCode3)
    playedToday = parseInt(checkCode3);
  }
  if (parseInt(getCookie("playedtoday")) == date2) {
    alreadyPlayed();
    lettersTyped = 5;
  }
}

checkCookie();
// var code = getCookie("code");