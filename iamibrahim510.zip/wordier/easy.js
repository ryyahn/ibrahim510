var canvas = document.getElementById("canvas")

var c = canvas.getContext("2d");
var img = new Image();

canvas.width = 400;
canvas.height = 350;

var xStart = 0;
var yStart = 0;

var letterPlace_X = 25;
var letterPlace_Y = 35;
var letterPlace_XSave = 25;
var letterPlace_YSave = 35;
var letterNumber = 1;
var letterNum = 1;

var letterColor = "black";

var backspaceX = 0;

var dateFinder = 1;
var dateFinder2 = 0;
const dateNumbers = []
let date = new Date();
date = String(date)
let date2 = date.slice(8, 11);

const xs = [25, 75, 125, 175, 225];
let x1 = 25;
let x2 = 75;
let x3 = 125;
let x4 = 175;
let x5 = 225;

const words = ["are", "the", "and", "are", "for", "not", "but", "had", "has", "was", "all", "any", "one", "man", "out", "you", "his", "her", "and", "can", "new", "all", "mad", "old", "any", "but", "nor", "two", "yes"]

var wordAnswer = String(words.slice(date2 - 1 , date2))

let lettersPutIn = []

let lettersInAnswer = []
var lettersInAnswerHelp = 1;
let lettersInAnswerHelp2 = "";

var lettersTyped = 0;

var mainEnterHelp = "";
var mainEnterHelp2 = 0;
var mainEnterHelp3 = 1;
var coloredRewriteHelp = "";
var coloredRewriteHelp2 = 0;
var coloredRewriteHelp3 = "";
let coloredRewriteHelp4 = "";

console.log("---->>> mt def");
let colorsInRow = []
let colorsInAll = [];

var tries = 0;

var colorEmojisHelp = 0;
let coloredEmojis = []
var colorEmojisHelp2 = "";

var stringTyped = "";
var stringTypedHelp = 0;

var streak = 0;
var gamesPlayed = 0;
var playedToday = date2;

var sendCode = 0;

var streakRead = 0;
var gamesPlayedRead = 0;
var playedTodayRead = 0;

var rowDeleting = 0;

let allWords = ["aaa", "aad", "aah", "aal", "aam", "aan", "aas", "aat", "aba", "abb", "abc", "abd", "abe", "abi", "abl", "abo", "abp", "abs", "abt", "abu", "aby", "aca", "acb", "acc", "ace", "ach", "ack", "acl", "acn", "acr", "acs", "act", "ada", "add", "ade", "adf", "adi", "adj", "adl", "adm", "adn", "ado", "ads", "adv", "ady", "aer", "aes", "afb", "aff", "afr", "afs", "aft", "aga", "age", "ago", "agr", "aha", "ahd", "ahh", "ahi", "ahn", "aho", "ahs", "aia", "aib", "aid", "ail", "aim", "ain", "air", "ais", "ait", "aka", "akc", "ake", "aki", "ako", "aku", "ala", "alb", "ald", "ale", "alf", "alg", "ali", "all", "alm", "alo", "alp", "als", "alt", "alu", "aly", "ama", "amb", "amd", "ame", "ami", "amp", "amr", "ams", "amt", "amu", "amy", "ana", "anc", "and", "ane", "anf", "ang", "ani", "ann", "ano", "ans", "ant", "any", "aol", "apc", "ape", "aph", "api", "apo", "app", "apr", "aps", "apt", "ara", "arb", "arc", "ard", "are", "arf", "arg", "ari", "ark", "arm", "arn", "arp", "ars", "art", "ary", "asa", "asd", "ase", "asg", "ash", "asi", "ask", "asl", "asn", "aso", "asp", "asr", "ass", "ast", "asu", "asv", "asw", "ata", "ate", "atg", "atk", "atl", "atm", "ato", "atp", "atr", "att", "atx", "aud", "auf", "aug", "auk", "aul", "aus", "aux", "ava", "ave", "avg", "avi", "avo", "avp", "awe", "awk", "awl", "awn", "aws", "aww", "axa", "axe", "aye", "ayn", "ayr", "aza", "azo", "baa", "bab", "bac", "bad", "bae", "bag", "bah", "bai", "bal", "bam", "ban", "bao", "bap", "bar", "bas", "bat", "bau", "baw", "bax", "bay", "baz", "bbl", "bbq", "bbs", "bcc", "bcd", "bcf", "bcp", "bde", "bdi", "bds", "bea", "bec", "bed", "bee", "beg", "bei", "bel", "bem", "ben", "ber", "bes", "bet", "bev", "bey", "bgp", "bhp", "bib", "bic", "bid", "big", "bil", "bim", "bin", "bio", "bir", "bis", "bit", "biz", "ble", "blk", "blp", "blt", "blu", "bly", "bms", "bnc", "boa", "bob", "boc", "bod", "boe", "bog", "bok", "bol", "bom", "bon", "boo", "bop", "bor", "bos", "bot", "bow", "box", "boy", "bpa", "bps", "bpt", "bra", "bri", "brl", "bro", "brr", "bsa", "bsc", "bsh", "bta", "btg", "bto", "btu", "btw", "bub", "buc", "bud", "buf", "bug", "bui", "bul", "bum", "bun", "bur", "bus", "but", "buy", "bye", "bys", "byu", "cab", "cad", "caf", "cag", "cah", "cai", "cal", "cam", "can", "cao", "cap", "car", "cas", "cat", "caw", "cay", "cba", "cbd", "ccf", "cci", "ccm", "cco", "ccs", "cde", "cdm", "cdr", "cds", "cea", "cee", "cel", "cen", "cep", "cer", "ces", "cet", "cfb", "cfd", "cfe", "cfi", "cfm", "cgi", "cha", "che", "chi", "chm", "cho", "chr", "chs", "chu", "cia", "cid", "cie", "cif", "cig", "cii", "cil", "cin", "cir", "cis", "cit", "civ", "cle", "cli", "clo", "clr", "cmd", "cmg", "cmh", "cmp", "cms", "cmt", "cmu", "cnc", "cni", "cnl", "cnn", "cns", "cnt", "cob", "cod", "coe", "cog", "col", "com", "con", "coo", "cop", "cor", "cos", "cot", "cou", "cow", "cox", "coy", "coz", "cpl", "cpo", "cps", "cpt", "cpu", "cre", "crg", "crm", "cro", "crp", "cru", "cry", "cse", "csl", "csp", "cst", "csw", "ctl", "ctn", "cto", "ctr", "cts", "cua", "cub", "cud", "cue", "cui", "cul", "cum", "cun", "cup", "cur", "cus", "cut", "cuu", "cuz", "cvs", "cwd", "cwm", "cyc", "cyn", "cyr", "dab", "dac", "dad", "dae", "dag", "dah", "dai", "dak", "dal", "dam", "dan", "dao", "dap", "dar", "das", "dat", "dau", "daw", "dax", "day", "dba", "dca", "dce", "ddd", "dde", "dea", "deb", "dec", "ded", "dee", "def", "deg", "dei", "dek", "del", "dem", "den", "deo", "dep", "der", "des", "det", "dev", "dew", "dex", "dey", "dfl", "dfw", "dia", "dib", "dic", "did", "die", "dig", "dik", "dim", "din", "dip", "dir", "dis", "dit", "div", "dix", "diy", "diz", "dlr", "dml", "dmt", "dmx", "dnb", "doa", "dob", "doc", "dod", "doe", "dog", "doh", "doi", "dol", "dom", "don", "doo", "dop", "dor", "dos", "dot", "dou", "dov", "dow", "dpa", "dpi", "dpr", "dra", "drc", "dre", "dro", "drp", "drs", "dry", "dsd", "dso", "dsr", "dss", "dts", "dtt", "dua", "dub", "duc", "dud", "due", "dug", "duh", "dui", "duk", "dum", "dun", "duo", "dup", "dur", "dux", "dvi", "dye", "dyk", "dyn", "ead", "ean", "eap", "ear", "eas", "eat", "eau", "eba", "ebb", "ebi", "ebt", "ebv", "eca", "ece", "eck", "ecn", "eco", "ecp", "ecs", "ect", "ecu", "eda", "edd", "edf", "edi", "edo", "eds", "edu", "eea", "eed", "eee", "eeg", "eek", "eel", "een", "eeo", "eep", "ees", "eet", "efe", "eff", "efl", "efs", "eft", "efx", "ege", "egg", "ego", "egs", "eid", "eif", "ein", "eir", "eis", "eke", "eko", "ela", "eld", "ele", "elf", "eli", "elk", "ell", "elm", "elp", "els", "elt", "ely", "ema", "eme", "emf", "emm", "emp", "ems", "emu", "ena", "enc", "end", "ene", "eng", "eno", "enr", "ens", "ent", "env", "eod", "eof", "eon", "eos", "epg", "epi", "epp", "eps", "ept", "era", "erb", "ere", "erg", "erk", "erl", "erm", "ern", "ero", "erp", "err", "ers", "ert", "esc", "ese", "esh", "eso", "esp", "esq", "ess", "est", "eta", "etc", "eth", "eti", "eto", "ets", "eur", "eva", "eve", "ewe", "ews", "exc", "exe", "exp", "ext", "eye", "fab", "fac", "fad", "fae", "fag", "fam", "fan", "fap", "faq", "far", "fas", "fat", "fav", "faw", "fax", "fay", "faz", "fcs", "fea", "feb", "fed", "fee", "fei", "fem", "fen", "fer", "fet", "feu", "few", "fey", "fez", "ffl", "fib", "fic", "fid", "fie", "fig", "fil", "fim", "fin", "fir", "fis", "fit", "fix", "flo", "flu", "fly", "fma", "fob", "foe", "fog", "foi", "fol", "fon", "foo", "fop", "for", "fos", "fot", "fou", "fox", "foy", "fpo", "fps", "fra", "fre", "fri", "fro", "frs", "fry", "fsi", "fte", "ftp", "fud", "fue", "ful", "fun", "fur", "fwd", "gab", "gad", "gae", "gag", "gah", "gak", "gal", "gam", "gan", "gap", "gar", "gas", "gat", "gau", "gaw", "gay", "gaz", "gbc", "gcr", "gdc", "gdi", "gds", "ged", "gee", "gei", "gel", "gem", "gen", "geo", "ger", "ges", "get", "ghi", "ghz", "gia", "gib", "gid", "gie", "gif", "gig", "gii", "gil", "gim", "gin", "gio", "gip", "gis", "git", "giv", "glb", "gld", "glo", "glx", "gnc", "gns", "gnu", "goa", "gob", "god", "goe", "gog", "goi", "gon", "goo", "gop", "gor", "gos", "got", "gov", "gow", "goy", "gra", "gro", "grp", "grs", "gru", "gry", "gsf", "gsm", "gtd", "gud", "gue", "gui", "gul", "gum", "gun", "gur", "gus", "gut", "guv", "guy", "gym", "gyn", "gyp",  "hab", "had", "hae", "hag", "hah", "hai", "haj", "hal", "ham", "han", "hao", "hap", "haq", "har", "has", "hat", "hau", "hav", "haw", "hay", "hbr", "hcl", "hcr", "hdd", "hdr", "hed", "hee", "heh", "hei", "hel", "hem", "hen", "hep", "her", "hes", "het", "hew", "hex", "hey", "hgh", "hid", "hie", "him", "hin", "hip", "hir", "his", "hit", "hix", "hls", "hmc", "hmi", "hmm", "hnc", "hob", "hoc", "hod", "hoe", "hof", "hog", "hoh", "hoi", "hok", "hol", "hom", "hon", "hoo", "hop", "hor", "hos", "hot", "hou", "how", "hoy", "hrc", "hrh", "hrm", "hrs", "hsu", "hta", "hte", "hts", "hub", "hud", "hue", "hug", "huh", "hui", "hum", "hun", "hup", "hur", "hut", "hve", "hwa", "hwy", "hye", "ial", "ian", "ias", "iba", "ibm", "ibn", "ibo", "ice", "ich", "ici", "ick", "icp", "ics", "ict", "icu", "icy", "ida", "ide", "ido", "ids", "idt", "ies", "iet", "ife", "iff", "ifs", "ige", "ign", "igo", "igs", "ihr", "ihs", "iia", "iie", "iif", "iii", "ike", "ila", "ile", "ili", "ilk", "ill", "ilo", "ilp", "imo", "imp", "imr", "ina", "inc", "ind", "ine", "inf", "ing", "ink", "inn", "ins", "int", "inv", "iof", "ion", "ios", "ipa", "ipi", "ipl", "ipp", "ipr", "ipx", "ira", "irb", "irc", "ire", "irg", "irk", "irl", "irr", "irv", "isa", "isd", "ise", "ish", "ism", "isn", "iso", "isp", "ist", "isu", "ita", "ite", "itf", "ith", "itm", "ito", "itp", "its", "itt", "itu", "iva", "ive", "ivo", "ivy", "iwo", "jab", "jac", "jad", "jae", "jag", "jah", "jai", "jak", "jam", "jan", "jap", "jar", "jas", "jat", "jaw", "jax", "jay", "jbl", "jeb", "jed", "jee", "jeg", "jem", "jen", "jer", "jet", "jeu", "jew", "jia", "jib", "jie", "jif", "jig", "jil", "jim", "jin", "jit", "job", "joe", "jog", "joh", "jon", "jos", "jot", "jow", "joy", "jps", "jsc", "jss", "jst", "jud", "jug", "jul", "jun", "jur", "jus", "jut", "kaf", "kai", "kal", "kam", "kan", "kao", "kat", "kaw", "kay", "kaz", "kde", "kea", "keb", "kee", "kef", "keg", "kem", "ken", "keo", "ker", "ket", "kew", "key", "khi", "khu", "kia", "kid", "kif", "kim", "kin", "kip", "kis", "kit", "kkk", "kmi", "koa", "koh", "koi", "kom", "kon", "koo", "kop", "kor", "kos", "kot", "kou", "kow", "krs", "kua", "kum", "kun", "kuo", "kva", "kwh", "kyd", "kye", "kyi", "kym", "kyu", "lab", "lac", "lad", "lag", "lah", "lai", "lak", "lal", "lam", "lan", "lao", "lap", "lar", "las", "lat", "lau", "lav", "law", "lax", "lay", "lbs", "lcc", "lcs", "lda", "lds", "lea", "lec", "led", "lee", "leg", "leh", "lei", "lek", "lem", "len", "leo", "lep", "ler", "les", "let", "leu", "lev", "lew", "lex", "ley", "lia", "lib", "lid", "lie", "lif", "lil", "lim", "lin", "lip", "lis", "lit", "liu", "liv", "liz", "lke", "llb", "llp", "lms", "loa", "lob", "loc", "lod", "loe", "lof", "log", "loh", "loi", "lok", "lom", "lon", "loo", "lop", "lor", "los", "lot", "lou", "low", "lox", "loy", "lpd", "lpg", "lst", "ltc", "ltd", "lte", "ltm", "ltr", "lua", "luc", "lue", "lug", "lui", "luk", "lum", "lun", "luo", "luu", "luv", "lux", "luz", "lye", "lyn", "lys", "maa", "mab", "mac", "mad", "mae", "mag", "mah", "mai", "maj", "mak", "mal", "mam", "man", "mao", "map", "mar", "mas", "mat", "mau", "maw", "max", "may", "mbd", "mcf", "mcg", "mcl", "mcq", "mea", "mec", "med", "mee", "meg", "mei", "mel", "mem", "men", "meo", "mer", "mes", "met", "meu", "mew", "mex", "mey", "mfc", "mfg", "mga", "mgr", "mgs", "mgt", "mho", "mhz", "mia", "mib", "mic", "mid", "mif", "mig", "mil", "mim", "min", "mio", "mir", "mis", "mit", "mix", "mks", "mkt", "mln", "mmb", "mme", "mmm", "mmu", "moa", "mob", "mod", "moe", "mof", "mog", "moi", "mok", "mol", "mom", "mon", "moo", "mop", "mor", "mos", "mot", "mou", "mow", "moy", "mpa", "mpg", "mph", "mpl", "mpr", "mre", "mrk", "mrm", "mro", "mrs", "msb", "msc", "msg", "mso", "mss", "mst", "mtd", "mtg", "mth", "mtn", "mts", "mua", "mud", "mug", "mum", "mun", "mus", "mut", "mux", "muy", "mvc", "mya", "myc", "naa", "nab", "nad", "nae", "naf", "nag", "nah", "nam", "nan", "nao", "nap", "nar", "nas", "nat", "nau", "nav", "naw", "nay", "nce", "nco", "ncs", "nda", "nds", "nea", "neb", "nec", "ned", "nee", "nef", "neg", "nei", "nel", "neo", "nep", "ner", "nes", "net", "neu", "nev", "new", "ney", "ngo", "ngs", "nib", "nic", "nie", "nig", "nik", "nil", "nim", "nip", "nir", "nis", "nit", "nix", "nla", "nlp", "nma", "noa", "nob", "noc", "nod", "noe", "nog", "noh", "noi", "nok", "nol", "nom", "non", "noo", "nop", "nor", "nos", "not", "nov", "now", "nox", "noy", "npo", "npr", "nss", "nsw", "nth", "ntp", "nts", "nub", "nul", "num", "nun", "nur", "nut", "nwe", "nyc", "nye", "oad", "oaf", "oak", "oar", "oas", "oat", "oba", "obe", "obi", "obj", "obs", "oca", "och", "oct", "oda", "odd", "ode", "odp", "ods", "oep", "oes", "ofa", "ofc", "off", "ofr", "ofs", "oft", "ogg", "ohm", "oho", "ohs", "oie", "oif", "oil", "oji", "oka", "oke", "oki", "oko", "ola", "old", "ole", "ols", "olt", "oma", "ome", "omo", "oms", "ona", "ond", "one", "ong", "oni", "onl", "ono", "ons", "ont", "ony", "oof", "ooh", "ook", "oop", "oos", "oot", "ope", "opp", "ops", "opt", "ora", "orb", "orc", "ord", "ore", "orf", "org", "ori", "orn", "orr", "ors", "ort", "ory", "osc", "ose", "oss", "ost", "osu", "ota", "oth", "ott", "oud", "ouf", "oui", "our", "ous", "out", "ova", "owe", "owl", "own", "oxo", "oxy", "paa", "pac", "pad", "pah", "pai", "pak", "pal", "pam", "pan", "pao", "pap", "par", "pas", "pat", "paw", "pax", "pay", "paz", "pcd", "pcf", "pct", "pdl", "pdm", "pdp", "pdq", "pds", "pea", "pec", "ped", "pee", "peg", "pei", "pel", "pem", "pen", "peo", "pep", "per", "pes", "pet", "pew", "pez", "pfs", "pge", "pgi", "pgm", "pgp", "pgs", "phd", "phi", "pho", "phs", "phu", "phy", "pia", "pic", "pid", "pie", "pif", "pig", "pik", "pil", "pim", "pin", "pio", "pip", "pis", "pit", "piu", "pix", "pkg", "pki", "pla", "plc", "plf", "pli", "pls", "ply", "poa", "pod", "poe", "poh", "poi", "pol", "pom", "pon", "poo", "pop", "por", "pos", "pot", "pou", "pov", "pow", "pox", "ppa", "ppb", "ppi", "ppl", "ppm", "ppr", "pps", "ppt", "pre", "pri", "prl", "prn", "pro", "prs", "pru", "pry", "psd", "psf", "psi", "psl", "pso", "pst", "psu", "psv", "ptc", "pte", "pto", "ptr", "pts", "pty", "pub", "pud", "pug", "pui", "pul", "pun", "pup", "pur", "pus", "put", "puy", "pwr", "pye", "qat", "qed", "qin", "qom", "qrs", "qua", "que", "qui", "quo", "rab", "rad", "rae", "rag", "rah", "rai", "raj", "ral", "ram", "ran", "rao", "rap", "ras", "rat", "rau", "raw", "rax", "ray", "raz", "rbi", "rbs", "rcc", "rcd", "rcs", "rdc", "rds", "rea", "reb", "rec", "red", "ree", "ref", "reg", "reh", "rei", "rel", "rem", "ren", "reo", "rep", "rer", "res", "ret", "rev", "rew", "rex", "rey", "rfp", "rha", "rho", "ria", "rib", "ric", "rid", "rif", "rig", "rim", "rin", "rio", "rip", "rit", "riv", "rix", "rmp", "rmt", "rob", "roc", "rod", "roe", "rog", "roh", "roi", "rol", "rom", "ron", "roo", "ros", "rot", "row", "rox", "roy", "roz", "rpf", "rpg", "rpi", "rpm", "rps", "rsa", "rsp", "rss", "rst", "rtd", "rti", "rtp", "rua", "rub", "rud", "rue", "ruf", "rug", "rui", "rum", "run", "rus", "rut", "rya", "rye", "sab", "sac", "sad", "sae", "saf", "sag", "sah", "sai", "sal", "sam", "san", "sao", "sap", "sar", "sas", "sat", "sav", "saw", "sax", "say", "scc", "sch", "sci", "scl", "sco", "scp", "scr", "scs", "sct", "sde", "sdf", "sdl", "sdn", "sea", "seb", "sec", "sed", "see", "seg", "sei", "sel", "sem", "sen", "seo", "sep", "ser", "ses", "set", "sew", "sex", "sez", "sfs", "sha", "she", "shh", "shi", "sho", "shu", "shy", "sib", "sic", "sid", "sie", "sig", "sil", "sim", "sin", "sip", "sir", "sis", "sit", "six", "ska", "ski", "sky", "slc", "sld", "slt", "sly", "sma", "smd", "sms", "sna", "sob", "soc", "sod", "soe", "sof", "soh", "soi", "sok", "sol", "som", "son", "soo", "sop", "sor", "sos", "sot", "sou", "sow", "sox", "soy", "spa", "spl", "spo", "spp", "spr", "spy", "srb", "src", "sri", "srp", "sse", "ssh", "sss", "sta", "stb", "std", "stg", "sti", "stk", "stm", "sto", "stp", "str", "sts", "stu", "sty", "sub", "sud", "sue", "suh", "sui", "sul", "sum", "sun", "sup", "sur", "sus", "suu", "svc", "swa", "swt", "syd", "sym", "syn", "syr", "sys", "taa", "tab", "tac", "tad", "tae", "tag", "tai", "taj", "tak", "tal", "tam", "tan", "tao", "tap", "tar", "tas", "tat", "tau", "taw", "tax", "tay", "tbl", "tce", "tch", "tea", "tec", "ted", "tee", "teg", "teh", "tei", "tek", "tel", "tem", "ten", "ter", "tes", "tet", "tew", "tex", "tey", "tha", "the", "thi", "tho", "thr", "ths", "tht", "thu", "thw", "thx", "thy", "tia", "tib", "tic", "tid", "tie", "tif", "tig", "til", "tim", "tin", "tip", "tis", "tit", "tiu", "tix", "tme", "tmg", "tmp", "tms", "tne", "tni", "toa", "toc", "tod", "toe", "tog", "toi", "tok", "tol", "tom", "ton", "too", "top", "tor", "tos", "tot", "tou", "tov", "tow", "toy", "tra", "tre", "tri", "trm", "tru", "try", "tse", "tsk", "tso", "tsp", "tss", "tsu", "ttc", "ttl", "tts", "tty", "tua", "tub", "tue", "tug", "tui", "tum", "tun", "tup", "tur", "tus", "tut", "tux", "twi", "two", "twp", "txt", "tye", "tyo", "ubc", "ubi", "ucb", "ucc", "ucd", "uci", "ucs", "udi", "udo", "ues", "ufa", "ugh", "ugo", "uhh", "uhl", "ula", "ulf", "uli", "ulm", "uma", "umm", "ump", "una", "und", "une", "ung", "uni", "uno", "unp", "uns", "upa", "upm", "upn", "upp", "ups", "ura", "urc", "ure", "uri", "urn", "urs", "ury", "usa", "usb", "usd", "use", "usp", "ust", "usu", "uta", "ute", "uti", "uts", "utu", "utz", "uva", "uwe", "uys", "uzi", "vac", "vag", "vai", "val", "vam", "van", "vas", "vat", "vaw", "vax", "vaz", "vee", "veg", "ven", "ver", "ves", "vet", "vew", "vex", "vey", "vez", "via", "vic", "vid", "vie", "vig", "vii", "vik", "vil", "vim", "vin", "vis", "viv", "viz", "vmc", "voc", "voe", "vol", "vom", "von", "vos", "vow", "vox", "vse", "vts", "vue", "wac", "wad", "wag", "wah", "wai", "wal", "wan", "wap", "war", "was", "wat", "waw", "wax", "way", "wca", "wcg", "web", "wed", "wee", "wef", "weg", "wei", "wel", "wem", "wen", "wer", "wes", "wet", "wey", "wfs", "wha", "whe", "who", "whr", "wht", "why", "wid", "wie", "wig", "wil", "wim", "win", "wir", "wis", "wit", "wiz", "wjc", "wll", "woe", "wok", "won", "woo", "wop", "wor", "wot", "wow", "wpc", "wri", "wrt", "wry", "wth", "wuz", "www", "wye", "wyn", "xer", "xie", "xin", "xxx", "yad", "yah", "yak", "yam", "yan", "yao", "yap", "yar", "yat", "yaw", "yay", "yds", "yea", "yee", "yeh", "yen", "yeo", "yep", "yer", "yes", "yet", "yew", "yid", "yin", "yip", "yob", "yok", "yom", "yon", "yoo", "yor", "you", "yow", "yoy", "ypf", "yrs", "yuh", "yuk", "yum", "yun", "yup", "zac", "zag", "zak", "zap", "zax", "zea", "zed", "zee", "zel", "zen", "zep", "zev", "zhu", "zia", "zig", "zim", "zip", "zit", "ziv", "zoe", "zoo", "zug", "zur"];

function deleteRow1() {
  xStart = 0;
  yStart = 0;

    // console.log(xStart)
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    letterPlace_Y += 70;

    mainEnter();
}

function deleteRow2() {
  xStart = 0;
  yStart = 70;

    // console.log(xStart)
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    letterPlace_Y += 70;

    mainEnter();
}

function deleteRow3() {
  xStart = 0;
  yStart = 140;

    // console.log(xStart)
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    letterPlace_Y += 70;
    mainEnter();
}

function deleteRow4() {
  xStart = 0;
  yStart = 210;

    // console.log(xStart)
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    letterPlace_Y += 70;

    mainEnter();
}

function deleteRow5() {
  xStart = 0;
  yStart = 280;

    // console.log(xStart)
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    letterPlace_Y += 70;

    mainEnter();
}


function getLettersInAnswer() {
  do {
    lettersInAnswerHelp2 = wordAnswer.slice(lettersInAnswerHelp - 1, lettersInAnswerHelp)
    lettersInAnswer.push(lettersInAnswerHelp2)
    lettersInAnswerHelp += 1;
  }
  while (lettersInAnswerHelp < 4)

}


getLettersInAnswer();


function squares() {

  do {

    xStart = 0;

    // console.log(xStart)
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    xStart += 60;
    c.fillStyle = "gainsboro";
    c.fillRect(xStart, yStart, 50, 50)
    // console.log(xStart)
    yStart += 70;

  }
  while (yStart < 350);
}

squares();


// console.log(letterPlace_X)

function x_place() {
  // console.log(letterNum)
  letterNum += 1;
  if (letterNum == 1) {
    letterPlace_X = 25;
    // console.log(letterPlace_X);

  }
  else if (letterNum == 2) {
    letterPlace_X = 85;
  }
  else if (letterNum == 3) {
    letterPlace_X = 145;
  }
  else if (letterNum == 4) {
    letterPlace_X = 205;
  }
  else if (letterNum == 5) {
    letterPlace_X = 265;
  }
  // console.log(letterPlace_X);
  lettersTyped += 1;
}

function x_placeBackspace() {
  if (letterNum == 1) {
    letterPlace_X = 25;
    // console.log(letterPlace_X);

  }
  else if (letterNum == 2) {
    letterPlace_X = 85;
  }
  else if (letterNum == 3) {
    letterPlace_X = 145;
  }
  else if (letterNum == 4) {
    letterPlace_X = 205;
  }
  else if (letterNum == 5) {
    letterPlace_X = 265;
  }
  // console.log(letterPlace_X);
}

function findDate() {
  do{
      dateNumbers.push(date.charAt(dateFinder))
      dateFinder += 1;
  }
  while (dateFinder < 11)
}

function mainEnter() {
  mainEnterHelp = "";
  mainEnterHelp2 = 0;
  mainEnterHelp3 = 1;
  stringTypedHelp = 0;
  // console.log("mainEnter")
  stringTyped = lettersPutIn.join("");
  if (allWords.includes(stringTyped)) {

    do {
        // console.log("mainEnter")
        mainEnterHelp = lettersPutIn[mainEnterHelp2];
      if (lettersInAnswer.includes(mainEnterHelp)){
        if (lettersPutIn[mainEnterHelp2] == lettersInAnswer[mainEnterHelp2]){
          colorsInRow.push("green")
        } else {
          colorsInRow.push("yellow")
        }
      }else {
        colorsInRow.push("red")
      }
      mainEnterHelp2 += 1;
    }
    while (mainEnterHelp2 < 3)
    coloredRewrite();
  } else {
    error();
    letterNum = 1;
    lettersTyped = 0;
    letterPlace_X = 25;
    lettersPutIn = [];
    console.log("---->>> mt");
    colorsInRow = [];
    letterPlace_Y -= 70;
  }
}

function coloredRewrite() {
  tries += 1;
  coloredRewriteHelp2 = 0;
  coloredRewriteHelp = "";
  coloredRewriteHelp3 = "";
  coloredRewriteHelp4 = "";
  letterPlace_XSave = 25;
  do {
    coloredRewriteHelp = colorsInRow[coloredRewriteHelp2];
    coloredRewriteHelp3 = lettersPutIn[coloredRewriteHelp2];
    coloredRewriteHelp4 = coloredRewriteHelp3.toUpperCase();
    c.font = "30px Arial";
    c.fillStyle = coloredRewriteHelp;
    c.textAlign = "center";
    c.fillText(coloredRewriteHelp4, letterPlace_XSave, letterPlace_YSave);
    coloredRewriteHelp2 += 1;
    letterPlace_XSave += 60;
    colorsInAll.push(coloredRewriteHelp)
  }
  while(coloredRewriteHelp2 < 3);

  gameFinished();
}

function popUpf() {
  var popup = document.getElementById("myPopup");
  popup.classList.toggle("show");
}

function nextRow() {
  letterNum = 1;
  lettersTyped = 0;
  letterPlace_X = 25;
  lettersPutIn = [];
  console.log("---->>> mt nextrow");
  colorsInRow = [];
  // console.log("next_row");
}

function gameFinished() {
  if(colorsInRow.includes("red")) {
    nextRow();
    if (tries == 5) {
      youLost();
    }
  }else if (colorsInRow.includes("yellow")) {
    nextRow();
    if (tries == 5) {
      youLost();
    }
  } else {
    clearCanvas();
  }
  
}

function youWin() {
  c.fillStyle = "gainsboro";
  c.fillRect(25, 0, 250, 300)
  c.font = "35px Arial";
  c.fillStyle = "green";
  c.textAlign = "center";
  c.fillText("You Win", 150, 35);
  c.font = "15px Arial";
  c.fillStyle = "black";
  c.textAlign = "center";
  c.fillText("Number of tries: " + tries, 100, 75);
  c.fillText("Scroll All The Way Down To Share", 150, 150);
  playedToday = date2;
  streak += 1;
  gamesPlayed += 1;
  c.fillText("Streak: " + streak, 75, 100);
  c.fillText("Games Played: " + gamesPlayed, 100, 125);
  setCookie("easystreak", streak, 365);
  setCookie("easygamesplayed", gamesPlayed, 365);
  setCookie("easyplayedtoday", playedToday, 365);
}

function youLost() {
  c.fillStyle = "gainsboro";
  c.fillRect(0, 0, 400, 400)
  c.font = "35px Arial";
  c.fillStyle = "red";
  c.textAlign = "center";
  c.fillText("You Lost", 150, 35);
  c.font = "15px Arial";
  c.fillStyle = "black";
  c.textAlign = "center";
  c.fillText("Number of tries: " + tries, 100, 75);
  c.fillText("Scroll All The Way Down To Share", 150, 150);
  playedToday = date2;
  streak = 0;
  gamesPlayed += 1;
}

function clearCanvas() {
  window.setTimeout(nothing, 2500)
  c.fillStyle = "white";
  c.fillRect(0, 0, 400, 400)
  youWin();
}

function share() {
  colorEmojis();
  // console.log('--->>> share blah');
}

function addStr(str, index, stringToAdd){
  return str.substring(0, index) + stringToAdd + str.substring(index, str.length);
}

function colorEmojis() {
  colorEmojisHelp = 0;
  resultString = "";
  do {
    var nextChar = "";
    if (colorsInAll[colorEmojisHelp] == "green"){
      nextChar = "🟩";
    } else if (colorsInAll[colorEmojisHelp] == "yellow") {
      nextChar = "🟨";
    } else{
      nextChar = "🟥";
    }
    if (colorEmojisHelp % 3 == 0) {
      resultString += "\n";
    } else {
      resultString += " ";
    }
    resultString += nextChar;
    colorEmojisHelp += 1;
  } while (colorEmojisHelp < (tries * 3))
  colorEmojisHelp = 0;
  navigator.clipboard.writeText("I won on easy mode: \n" + resultString + "\n https://iamibrahim510.repl.co/easy.html \n Tries: " + tries + "/5" + "\n Wordier")
  alert("Copied to Clipboard");
}

function alreadyPlayed() {
  c.fillStyle = "gainsboro";
    c.fillRect(0, 0, 400, 400)
    c.font = "25px Quicksand";
    c.fillStyle = "green";
    c.textAlign = "center";
    c.fillText("You've already played today", 200, 35);
    c.font = "20px Quicksand";
    c.fillStyle = "black";
    c.textAlign = "center";
    // localStorage.setItem("try", tries); 
    c.fillText("Everyday there is a new word,", 150, 250);
    c.fillText("check in daily", 150, 280);
}


// keyboard:

function q() {
  if (lettersTyped < 3){  
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("Q", letterPlace_X, letterPlace_Y);
    x_place();
    lettersPutIn.push("q")
    // console.log("534")
  }  
}

function w() {
  if (lettersTyped < 3){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("W", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("w")
  }
}

function e() {
  if (lettersTyped < 3){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("E", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("e")
  }
}

function r() {
  if (lettersTyped < 3){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("R", letterPlace_X, letterPlace_Y);
    x_place();  
   lettersPutIn.push("r")
  }
}

function t() {
  if (lettersTyped < 3){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("T", letterPlace_X, letterPlace_Y);
    // console.log("t")
    x_place(); 
    lettersPutIn.push("t")
  }
}

function y() {
  if (lettersTyped < 3){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("Y", letterPlace_X, letterPlace_Y);
    x_place();  
    lettersPutIn.push("y")
  }
}

function u() {
  if (lettersTyped < 3){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("U", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("u")
  }
}

function i() {
  if (lettersTyped < 3){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("I", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("i")
  }
}

function o() {
  if (lettersTyped < 3){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("O", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("o")
  }
}

function p() {
  if (lettersTyped < 3){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("P", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("p")
  }
}

function a() {
  if (lettersTyped < 3){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("A", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("a");
  }
}

function s() {
  if (lettersTyped < 3){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("S", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("s")
  }
}

function d() {
  if (lettersTyped < 3){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("D", letterPlace_X, letterPlace_Y);
      x_place();   
    lettersPutIn.push("d")
  }
}

function f() {
  if (lettersTyped < 3){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("F", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("f")
  }
}

function g() {
  if (lettersTyped < 3){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("G", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("g")
  }
}

function h() {
  if (lettersTyped < 3){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("H", letterPlace_X, letterPlace_Y);
      x_place();   
      lettersPutIn.push("h")
  }
}


function j() {
  if (lettersTyped < 3){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("J", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("j")
  }
}


function k() {
  if (lettersTyped < 3){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("K", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("k")
  }
}


function l() {
  if (lettersTyped < 3){   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("L", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("l")
  }
}

function backspace() {
  console.log (lettersTyped)
  if (lettersTyped >= 1) {
    backspaceX = ((letterNum * 60) - 120)
    c.fillStyle = "gainsboro";
    c.fillRect(backspaceX, letterPlace_Y - 35, 50, 50);
    lettersPutIn.pop();
    letterNum = letterNum - 1;
    lettersTyped -= 1;
    x_placeBackspace();
  }
}


function z() {
  if (lettersTyped < 3){     
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("Z", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("z")
  }
}


function x() {
  if (lettersTyped < 3){     
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("X", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("x")
  }
}


function cT() {
  if (lettersTyped < 3){     
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("C", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("c")
  }
}


function v() {
  if (lettersTyped < 3){     
    c.globalCompositeOperation = 'source-over';  
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("V", letterPlace_X, letterPlace_Y);
    x_place();   
    lettersPutIn.push("v")
  }
}


function b() {
  if (lettersTyped < 3){     
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("B", letterPlace_X, letterPlace_Y);
      x_place();   
      lettersPutIn.push("b")
  }
}


function n() {
  if (lettersTyped < 3){     
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("N", letterPlace_X, letterPlace_Y);
      x_place();   
      lettersPutIn.push("n")
  }
}


function m() {
  if (lettersTyped < 3){     
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = letterColor;
    c.textAlign = "center";
    c.fillText("M", letterPlace_X, letterPlace_Y);
      x_place();   
      lettersPutIn.push("m")
  }
}

function enter() {
  if (lettersTyped != 3) {
    error();
  } else {
      letterPlace_XSave = letterPlace_X;
      letterPlace_YSave = letterPlace_Y;
      if (letterPlace_Y == 35){
          deleteRow1();
      } else if (letterPlace_Y == 105) {
          deleteRow2();
      } else if (letterPlace_Y == 175) {
          deleteRow3();
      } else if (letterPlace_Y == 245) {
          deleteRow4();
      } else if (letterPlace_Y == 315) {
          deleteRow5();
        }
  }
}

function error() {   
    c.globalCompositeOperation = 'source-over';
    c.font = "30px Arial";
    c.fillStyle = 'red';
    c.textAlign = "center";
    c.fillText("Error", 350, 175);  
    window.setTimeout(eraseError, 2500);
}

function eraseError() {
    c.fillStyle = "white";
    c.fillRect(300, 100, 150, 150)
}

function nothing() {
  
}


// cookie Junk:


function setCookie(name, value, days) {
    var expires = "";
    if (days) {
        var date5 = new Date();
        date5.setTime(date5.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date5.toUTCString();
    }
    document.cookie = name + "=" + (value || "") + expires + "; path=/";
}

function getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' '){ c = c.substring(1, c.length);}
        if (c.indexOf(nameEQ) == 0) {return c.substring(nameEQ.length, c.length);}
    }
    return "";
}

function checkCookie() {
  console.log("checkcooikie");
  let checkCode = getCookie("easystreak");
  let checkCode2 = getCookie("easygamesPlayed");
  let checkCode3 = getCookie("easyplayedtoday");
  if (getCookie("easystreak") === "") {
      console.log(checkCode)
      // alert("new")
      streak = 0;
      // setCookie("streak", "0", 365);
  } else {
    // reading the cookie
    streak = parseInt(checkCode);
  }
  if (getCookie("easygamesplayed") === "") {
    
    console.log(checkCode2)
    // alert("new")
    gamesPlayed = 0;
    // window.setTimeout(popUpf, 1000)
    // setCookie("gamesplayed", 0, 365);
  } else {
    // reading the cookie
    checkCode2 = getCookie("easygamesplayed");
    console.log(checkCode2);
    gamesPlayed = parseInt(checkCode2);
  }
  if (getCookie("easyplayedtoday") === "") {
    
    console.log(checkCode3)
    // alert("new")
    gamesPlayed = 0;
    // setCookie("playedtoday", "0", 365);
  } else {
    // reading the cookie
    checkCode3 = getCookie("easyplayedtoday");
    console.log(checkCode3)
    playedToday = parseInt(checkCode3);
  }
  if (parseInt(getCookie("easyplayedtoday")) == date2) {
    alreadyPlayed();
    lettersTyped = 3;
  }
}



checkCookie();
// var code = getCookie("code");